package Duree; // cf TestDuree.java


/** classe de manipulation des heures
 */

public class Conversion {

public	static int duree2seconde( int h, int m, int s)
	  {
	    int duree;
	    duree = 3600 * h + 60 * m + s;
	    return duree;
	  }
	  // il faut tester si dur�e >= 0 ...
public	static String Seconde2dureeHMS(int duree)
	  {
	    int heures, minutes, secondes;
	    heures = duree/3600;
	    minutes = duree/60 - 60 * heures;
	    secondes = duree%60 ;
	    return heures+"h"+minutes+"m"+secondes+"s";
	  }
	}


