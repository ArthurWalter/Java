import java.util.*;

public class Statistique  {
	static double Tab[]; //
	static int nb;
	
	public static  void main(String[] args){
	LireNotes();
	System.out.println("La moyenne est :" + moyenne());
	System.out.println("Le minimum est :" + min());
	System.out.println("Le maximum est :" + max());
	System.out.println("L'ecart type est :" + Ecart());
	}

	public static void LireNotes()  {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Entrez le nombre de notes");
		nb=sc.nextInt();
	    Tab=new double[nb];
		for(int i= 0; i<Tab.length; i++)
		{  
			System.out.println(" Entrez la"+i+ "�me notes");
			Tab[i]=sc.nextDouble();
		}
			
    }

	public static double moyenne() {
		double somme = 0;
		for(int i= 0; i<nb; i++)
		{
			somme= somme+Tab[i];
		}
		return somme/nb;
	}

	public static double max() {
		double max=Tab[0];
		for(int i= 1; i<nb; i++)
		{
			if (Tab[i]>max) max=Tab[i];
		}
		return max;
		
	}

	public static double min() { 	
	double min=Tab[0];
	for(int i= 1; i<nb; i++)
	{
		if (Tab[i]<min) min=Tab[i];
	}
	return min;
	}
	
	public static double Ecart() {
		double sigma;
		double s=0;
		for(int i= 0; i<nb; i++)
		{
			s=s+Math.pow(Tab[i], 2);
		}
		sigma=Math.sqrt(s/nb-Math.pow(moyenne(),2));
		return sigma;
	}

}
