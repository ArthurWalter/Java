import java.util.*;
package EXO1;

public class duree {

	public static void main(String[] args) {
	  
	    int h, m, s, duree;
	    String hor;
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Saisie d'un horaire");

		do{
	    System.out.println("Donnez les heures");
	    h = sc.nextInt();
		}while(h<0);
		
		do{
	    System.out.println("Donnez les minutes");
	    m = sc.nextInt();
		}while(m<0 || m>59);
		
		do{
	    System.out.println(" Donnez les secondes");
	    s =sc.nextInt();
		}while(s<0 || s>59);
		
	    duree = duree2seconde(h,m,s);
	    System.out.println(" Cet horaire dure" + duree + " secondes.");
	    hor = Seconde2dureeHMS(duree);
	    System.out.println(" L'horaire de d�part est" + hor);
	  }
	  
	 public	static int duree2seconde( int h, int m, int s)
	  {
	    int duree;
	    duree = 3600 * h + 60 * m + s;
	    return duree;
	  }
	  
	 public	static String Seconde2dureeHMS(int duree)
	  {
	    int heures, minutes, secondes;
	    heures = duree/3600;
	    minutes = duree/60 - 60 * heures;
	    secondes = duree%60 ;
	    return heures+"h"+minutes+"m"+secondes+"s";
	  }
	}
