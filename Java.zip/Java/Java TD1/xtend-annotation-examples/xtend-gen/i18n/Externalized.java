package i18n;

import i18n.ExternalizedProcessor;
import org.eclipse.xtend.lib.macro.Active;

@Active(ExternalizedProcessor.class)
public @interface Externalized {
}
