
import java.util.*;


public class TriTableau {

	public static void main(String[] args) {
		int [] Tab ; 
		int nb ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Entrer la valeur de n");
		nb=sc.nextInt();
		Tab=Lire(nb);
		afficher(Tab); 
		TriTableau(Tab);
		afficher(Tab); 
	}
		
	public static int [] Lire (int n)
	{
		Scanner sc= new Scanner(System.in);
		int [] T=new int[n];
		for(int i=0; i<n; i++)
			T[i]=sc.nextInt();
		return T;
	}

	
	
	public static void TriTableau(int [] T)
	{ 
	  for(int i=0; i<T.length-1; i++)
		  for(int j=i+1;j<T.length;j++)
			  if (T[i]>T[j]) 
				  echange (T,i,j); 
	}
	
	
	public static void echange(int T[], int i , int j)
	{
		int temp=T[i];
		    T[i]=T[j];
            T[j]=temp;
	}
	
    public static void afficher(int [] T)
    {
    	for(int i=0; i<T.length; i++)
			System.out.println("T["+i+"]="+T[i]);
    }	
	
}


