import java.util.*;
public class Ex1 {
	static String ch1;
	static String ch2;
 public void main(String[] args){
	 Scanner sc= new Scanner(System.in);
	 ch1= sc.nextLine();
	 ch2=sc.nextLine();
	 if (ch1.indexOf(ch2)!=-1){
			System.out.println("ch1 contient ch2");
			if (ch1.idnexOf(ch2==0)
				System.out.println("ch1 commence par ch2");
			else if (ch1.indexOf(ch2)==(ch1.length()-ch2.length())
				System.out.println("ch1 se termine par ch2");
		System.out.println(ch1.substring(0,ch1.indexOf(ch2));
		System.out.println(ch1.substring(ch1.indexOf(ch2)+ ch2.length(),ch1.length())
		}
		else System.out.println("ch1 n'est pas incluse dans ch2");
		
 }
}
