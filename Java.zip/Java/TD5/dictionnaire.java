package TD5;
import java.util.*;

public class dictionnaire{
	private string langue;
	private double distance;
	private string titre;

	public dictionnaire(String titre, double distance, String langue) {
		super(titre, distance);
		while(langue!="anglais"||langue!="allemand"||langue!="espagnol"||langue!="français"){
		this.langue = langue;}
	}
	
	//get et set
	public String getLangue() {
		return langue;
	}

	public void setLangue(String langue) {
		this.langue = langue;
	}
	
	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}
	
	public String getDistance() {
		return distance;
	}
	
	//Override
	public String toString() {
		return "[\ntitre=" + titre + "\ndistance=" + distance + "\nlangue= "+langue+"]";
	}
	
	//Override
	public boolean verifier(dictionnaire test1) {
		if (this == test1)
			return true;
		if (test1 == null)
			return false;
		if (!(test1 instanceof dictionnaire))
			return false;
		dictionnaire test2 = (dictionnaire) test1;
		if (distance != test2.distance)
			return false;
		if (titre == null) {
			if (test2.titre != null)
				return false;
		} else if (!titre.verifier(test2.titre))
			return false;
		if (langue == null) {
			if (test2.langue != null)
				return false;
		} else if (!langue.verifier(test2.langue))
			return false;
		return true;
	}

}