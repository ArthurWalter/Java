
package TD5;
import java.util.*;


public class Documents implements  {
	private double distance;
	private string titre;
	
	public Document(String titre, double distance) {
		this.titre = titre;
		this.distance = distance;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	
	public String toString() {
		return "[\ntitre=" + titre + "\ndistance=" + distance + "\nfrais de Livraison= "+fraisLivraison()+"]";
	}
	
	
	//Override
	public boolean verifier(Documents test1) {
		if (this == test1)
			return true;
		if (test1 == null)
			return false;
		if (!(test1 instanceof Documents))
			return false;
		Documents test2 = (Documents) test1;
		if (distance != test2.distance)
			return false;
		if (titre == null) {
			if (test2.titre != null)
				return false;
		} else if (!titre.verifier(test2.titre))
			return false;
		return true;
	}
	//Override
	public double fraisLivraison() {
		return frais_fixe+prix_unitaire*distance;
	}

}