package Unit1;

import java.awt.GridLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelDeplacer implements MouseListener{
	private JPanel pf=new JPanel();//panel de font
	private JPanel p1=new JPanel();
	private JPanel p2=new JPanel();
	private JPanel p3=new JPanel();
    private JLabel l1 = new JLabel();
    private JTextField tf1=new JTextField();
	private JTextField tf2=new JTextField();
	private JButton bdeplace=new JButton("D�placer");
	
	public PanelDeplacer(){
		Accueil.ClearAdd3(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
		p2.setLayout(new GridLayout(1,4));
		
		JLabel l1=new JLabel("D�placer: ");
		p2.add(l1);
		l1.setHorizontalAlignment(l1.CENTER);
		
		p2.add(tf1);
		p2.add(tf2);
		p2.add(bdeplace);
		bdeplace.addMouseListener(this);
		
	}
//mouse Listener
	public void mouseClicked(MouseEvent arg0) {
		
		ObjetDeBase odb=(ObjetDeBase)Gest.odb;
		odb.pointref.x=odb.pointref.x+ Integer.parseInt(tf1.getText());
		odb.pointref.y=odb.pointref.y+ Integer.parseInt(tf2.getText());
		if(odb instanceof Rectangle){
			Rectangle r=(Rectangle) odb;
			r.point2.x=r.point2.x+ Integer.parseInt(tf1.getText());
			r.point2.y=r.point2.y+ Integer.parseInt(tf2.getText());
			PanelDraw pd=new PanelDraw(r);
		}
		else if(odb instanceof Quadrilatere){
			Quadrilatere q=(Quadrilatere) odb;
			q.point2.x=q.point2.x+ Integer.parseInt(tf1.getText());
			q.point2.y=q.point2.y+ Integer.parseInt(tf2.getText());
			q.point3.x=q.point3.x+ Integer.parseInt(tf1.getText());
			q.point3.y=q.point3.y+ Integer.parseInt(tf2.getText());
			q.point4.x=q.point4.x+ Integer.parseInt(tf1.getText());
			q.point4.y=q.point4.y+ Integer.parseInt(tf2.getText());
			PanelDraw pd=new PanelDraw(q);
		}
		else{
		PanelDraw pd=new PanelDraw(odb);
		}
			
		
	}
	public void mouseEntered(MouseEvent arg0) {
		
	}
	public void mouseExited(MouseEvent arg0) {
		
	}
	public void mousePressed(MouseEvent arg0) {
		
	}
	public void mouseReleased(MouseEvent arg0) {
		
	}
}
