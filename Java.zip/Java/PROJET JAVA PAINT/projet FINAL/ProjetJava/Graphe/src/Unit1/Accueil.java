package Unit1;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;

public class Accueil{
	public static JFrame f1=new JFrame("Accueil");
	private static JPanel pc=new JPanel();	//pc:panel centre
	private static JPanel pd=new JPanel(); 	//pd:panel droit
	private static JPanel pb=new JPanel();	//pb:panel bas
//constructeur	
public Accueil(){
//configuration frame 
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		f1.setExtendedState(f1.MAXIMIZED_BOTH);	//mettre en plein ecran
		f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
//config panel de font qui contient panels haut, centre, droit et bas	
		//config BorderLayout pour mettre les panels en ordre
		BorderLayout bl=new BorderLayout();
		f1.setLayout(bl);
		//config panel center
		f1.add(pc,BorderLayout.CENTER);
		pc.setPreferredSize(new Dimension(100,100));
		//config panel droit					
		f1.add(pd, BorderLayout.EAST);
		pd.setPreferredSize(new Dimension(350,100));
		//config panel bas
		f1.add(pb, BorderLayout.SOUTH);
		pb.setPreferredSize(new Dimension(100,130));
		//appeler les panels d'autres classes
		AccueilPanel ap=new AccueilPanel();
		Gest g=new Gest();
	}
//Clear pour enlever le panel actuel dans le panel centre 
	public static void Clear(){
		pc.removeAll(); 	//supprimer le panel
	}
//Ajouter le panel dont on a besoin dans le panel centre
	public static void Add(JPanel p){
		pc.revalidate();	//re-valider /re-afficher le panel
		pc.repaint();		//re-dessiner 
		p.setPreferredSize(new Dimension(1570,865));//à convenir
//		p.setPreferredSize(new Dimension(1270,835));//F39
		pc.add(p);
	}
//Clear pour enlever le panel actuel dans le panel droit 
//Ajouter le panel dont on a besoin dans le panel droit
	public static void ClearAdd2(JPanel p) {
		pd.removeAll();
		pd.revalidate();	//re-valider /re-afficher le panel
		pd.repaint();		//re-dessiner 
		p.setPreferredSize(new Dimension(350,865));//à convenir
//		p.setPreferredSize(new Dimension(350,835));//F39
		pd.add(p);
	}
//Clear pour enlever le panel actuel dans le panel bas
//Ajouter le panel dont on a besoin dans le panel bas
	public static void ClearAdd3(JPanel p) {
		pb.removeAll();
		pb.revalidate();	//re-valider /re-afficher le panel
		pb.repaint();		//re-dessiner 
		p.setPreferredSize(new Dimension(1650,115));//à convenir
//		p.setPreferredSize(new Dimension(1650,65));//F39
		pb.add(p);
	}
}