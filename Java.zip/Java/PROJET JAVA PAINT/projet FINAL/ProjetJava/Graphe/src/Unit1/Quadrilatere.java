package Unit1;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Quadrilatere extends ObjetDeBase implements MouseListener{
	public static int indiceobj; //1 ObjetDeBase, 2 ObjetComposite
	public Point2D point2;
    public Point2D point3;
    public Point2D point4;
    private JPanel pf=new JPanel(); //panel de font
	private JTextField tf1=new JTextField(""); 
	private JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField(""); 
	private JTextField tf4=new JTextField("");
	private JTextField tf5=new JTextField(""); 
	private JTextField tf6=new JTextField("");
	private JTextField tf7=new JTextField(""); 
	private JTextField tf8=new JTextField("");
	private JButton b1=new JButton("Retourner"); 
	private JButton b2=new JButton("Afficher");
//constructeur	
	public Quadrilatere(){
		System.out.println("Rectangle");
	}
//constructeur principal
	public Quadrilatere(int i) {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(this.pf);
		JPanel p1=new JPanel();		//p2:panel haut
		JPanel p2=new JPanel(); 	//p3:panel milieu
		JPanel p3=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
//config panel haut
		//config label
		JLabel l1=new JLabel("Quadrilatere");
		//config borderlayout
		p1.setLayout(new BorderLayout());
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p21=new JPanel();
		JPanel p22=new JPanel();
		p2.setLayout(new GridLayout(2,1));
		p2.add(p21);
		p2.add(p22);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p21.add(l2);
		//config panel milieu 2
		p22.setLayout(new GridLayout(4,3));
		JLabel l21=new JLabel("Coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Coordonnées du point 2: ");
		JLabel l23=new JLabel("Coordonnées du point 3: ");
		JLabel l24=new JLabel("Coordonnées du point 4: ");
		l21.setHorizontalAlignment(JLabel.CENTER);
		l22.setHorizontalAlignment(JLabel.CENTER);
		l23.setHorizontalAlignment(JLabel.CENTER);
		l24.setHorizontalAlignment(JLabel.CENTER);
		p22.add(l21);
		p22.add(tf1);
		p22.add(tf2);
		p22.add(l22);
		p22.add(tf3);
		p22.add(tf4);
		p22.add(l23);
		p22.add(tf5);
		p22.add(tf6);
		p22.add(l24);
		p22.add(tf7);
		p22.add(tf8);
//config panel bas
		p3.add(b1);
		p3.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
	}	
//les fonctions
	public Point2D getPoint2(){
			return point2;
	}
	public Point2D getPoint3(){
			return point3;
	}
	public Point2D getPoint4(){
		return point4;
	}
	public void setPoint2(Point2D p2){
			this.point2 =p2;
	}
	public void setPoint3(Point2D p3){
			this.point3=p3;
	}
	public void setPoint4(Point2D p4){
		this.point4=p4;
	} 
//afficher le message
	@Override
	public String toString() {
		return "Quadrilatere [pointref="+pointref+
				", point2=" + point2 + 
				", point3=" + point3 + 
				", point4=" + point4 + "]";
	}
//mouse listener	
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	
			if (indiceobj==2)
			{
			Accueil.Clear();
			Accueil.Add(new ObjetComposite(1));
			System.out.println("Objet");
			}
			else {
			Accueil.Clear();
			Accueil.Add(new ObjetDeBase(1));
			}
		}
		else if (e.getSource()==b2)
		{	//r閏up閞er les coordonnées des 2 points
			try{String str1=tf1.getText();
			String str2=tf2.getText();
			String str3=tf3.getText(); 
			String str4=tf4.getText();
			String str5=tf5.getText();
			String str6=tf6.getText();
			String str7=tf7.getText(); 
			String str8=tf8.getText();
			this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
			this.point2=new Point2D(Integer.parseInt(str3),Integer.parseInt(str4));
			this.point3=new Point2D(Integer.parseInt(str5),Integer.parseInt(str6));
			this.point4=new Point2D(Integer.parseInt(str7),Integer.parseInt(str8));
			PanelDraw pd=new PanelDraw(this);
			PanelDraw.Add(this);
			}
			catch(Exception ef)
			{
				System.out.println("vous n'avez pas saisi de coordonnées ou vous avez oubli� une coordonn閑");
			}
		}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
}
