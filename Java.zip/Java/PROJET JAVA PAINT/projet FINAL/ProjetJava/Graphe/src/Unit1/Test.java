package Unit1;

public class Test {
	public static void main(String[] args) {
		Accueil a=new Accueil();
	}
}