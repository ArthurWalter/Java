package Unit1;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ellipse extends ObjetDeBase{
	public static int indiceobj; 
	//1 ObjetDeBase, 2 ObjetComposite, 3 MultiEllipse
	public Point2D pointref2;
	private int rayonlong;
    private int rayoncourt;
    private JPanel pf=new JPanel();		//p1:panel des font
	private static JTextField tf1=new JTextField(""); 
	private static JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField("");
	private JTextField tf4=new JTextField("");
	private JButton bretour=new JButton("Retourner"); 
	private JButton bafficher=new JButton("Afficher");
//constructeur    
	public Ellipse(){
		System.out.println("Ellipse");
	}
//constructeur principal
	public Ellipse(int i) {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(this.pf);
//config panel de font qui contient panels haut, milieu et bas			
		JPanel p1=new JPanel();		//p2:panel haut
		JPanel p2=new JPanel(); 	//p3:panel milieu
		JPanel p3=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
//config panel haut
		//config label
		JLabel l1=new JLabel("Ellipse");
		//config borderlayout
		p1.setLayout(new BorderLayout());
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p21=new JPanel();
		JPanel p22=new JPanel();
		GridLayout gl2=new GridLayout(2,1);
		p2.setLayout(gl2);
		p2.add(p21);
		p2.add(p22);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p21.add(l2);
		//config panel milieu 2
		GridLayout gl3=new GridLayout(3,3);
		p22.setLayout(gl3);
		JLabel l21=new JLabel("Les coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Rayon Long: ");
		JLabel l23=new JLabel("Rayon court: ");
		JLabel l24=new JLabel("");
		l21.setHorizontalAlignment(JLabel.CENTER);
		l22.setHorizontalAlignment(JLabel.CENTER);
		l23.setHorizontalAlignment(JLabel.CENTER);
		p22.add(l21);
		p22.add(tf1);
		p22.add(tf2);
		p22.add(l22);
		p22.add(tf3);
		p22.add(l24);
		p22.add(l23);
		p22.add(tf4);
//config panel bas
		p3.add(bretour);
		p3.add(bafficher);
		bretour.addMouseListener(this);
		bafficher.addMouseListener(this);
	}
//les fonctions
	 public int getRayonlong(){
			return rayonlong;
	}
	 public int getRayoncourt(){
			return rayoncourt;
	}
	public void setRayonlong(int r){
			this.rayonlong = r;
	}
	public void setRayoncourt(int r){
			this.rayoncourt = r;
	}
//afficher le message
	@Override
	public String toString() {
		return "Ellipse [pointref"+pointref+", pointref2=" + 
				pointref2 + ", rayonlong=" + rayonlong + 
				", rayoncourt=" + rayoncourt + "]";
	}
	//les fonctions de l'interface MouseListener		
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bretour) 
		{	
			if (indiceobj==2)
			{
			Accueil.Clear();
			Accueil.Add(new ObjetComposite(1));
			}
			else if (indiceobj==3)
			{
				Accueil.Clear();
				Accueil.Add(new AccueilPanel());
			}
			else {
			Accueil.Clear();
			Accueil.Add(new ObjetDeBase(1));
			}
		}
		else if (e.getSource()==bafficher)
		{	//r閏up閞er les coordonn閑s des 2 points
			try
			{
				String str1=tf1.getText();
				String str2=tf2.getText();
				String str3=tf3.getText(); 
				String str4=tf4.getText();
				this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
				this.rayonlong=Integer.parseInt(str3);
				this.rayoncourt=Integer.parseInt(str4);
				PanelDraw pd=new PanelDraw(this);
				PanelDraw.Add(this);//MultiEllipse
				if(indiceobj==3) 
				{
					Multiellipse.pointref=this.pointref;
					tf1.setText(str1);
					tf2.setText(str2);
					PanelDraw.Add(this);//MultiEllipse
				}
			}
			catch(Exception ef)
			{
				System.out.println("vous n'avez pas saisi de coordonnées ou vous avez oubli� une coordonn閑");
			}
		}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
}
