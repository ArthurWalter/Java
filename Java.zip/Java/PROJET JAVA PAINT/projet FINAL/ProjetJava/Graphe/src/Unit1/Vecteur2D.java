package Unit1;

public class Vecteur2D extends ObjetDeBase{
	private Point2D destination;
//constructeur	
	public Vecteur2D(){
		 Point2D pointref = new Point2D(0,0);
		 destination = new Point2D(40,40); 
	 }
//	public Vecteur2D (Point2D pointref){
//		 super(pointref); 
//		 destination = new Point2D(40,40);
//	 }
//	public Vecteur2D (Point2D pointref, Point2D x){
//		 super(pointref);
//		 destination=x;    
//	 }
//	public Vecteur2D (Vecteur2D v){
//		 super(v.pointref);
//		 this.destination=v.destination;
//	 }
//les fonctions
	public Point2D getPoint(){
		return destination;
	}
	public void setPoint(Point2D destination){
		this.destination = destination;
	}
//afficher
	 public String afficher(){//toString
		 return super.toString() +"Vecteur2D [point=" + destination.toString() + "]";
	 }
	
}
