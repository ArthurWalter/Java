package Unit1;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ObjetDeBase extends Objet implements MouseListener{
	protected Point2D pointref;
	private JPanel pf=new JPanel(); //panel de font
	private JButton br=new JButton("Rectangle");
	private JButton bc=new JButton("Cercle");
	private JButton be=new JButton("Ellipse");
	private JButton bq=new JButton("Quadrilatere");
	private JButton bretour=new JButton("Retourner");
	
//constructeur
	public ObjetDeBase(){
		pointref = new Point2D(0,0);
	}
//constructeur principal	
	public ObjetDeBase(int i) {
		pointref = new Point2D(0,0);
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(pf);
		PanelDraw.DeleteAll();
	//config les 3 panels
		JPanel p1=new JPanel();	//panel haut
		JPanel p2=new JPanel(); //panel milieu
		JPanel p3=new JPanel(); //panel bas
		//config gridlayout pour ranger les trois panels
		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
	//config panel haut et label
		JLabel l1=new JLabel("Quel type de l'objet de base voulez-vous cr�er?");
		BorderLayout bl1=new BorderLayout();
		p1.setLayout(bl1);
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);	
	//config panel milieu
		//config oridlayout pour mettre les 4 boutons
		p2.setLayout(new GridLayout(1,4));
		p2.add(br);
		p2.add(bc);
		p2.add(be);
		p2.add(bq);
		br.addMouseListener(this);
		bc.addMouseListener(this);
		be.addMouseListener(this);
		bq.addMouseListener(this);
	//config panel bas
		p3.add(bretour);
		bretour.addMouseListener(this);
	}
//les fonctions, on peut supprimer
	public Point2D getpointref() {
			return pointref;
		}
	public void setpointref(Point2D p) {
			this.pointref = p;
		}		
//afficher le message
		@Override
	public String toString() {
			return "ObjetDeBase [pointref=" + pointref + "]";
		}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==br) 	//appeler diff�rent l'interface pour entrer
		{	Accueil.Clear(); 	//les param�tres
			Accueil.Add(new Rectangle(1));
			Rectangle.indiceobj=1;
			}
		else if (e.getSource()==bc) 
		{	Accueil.Clear();
			Accueil.Add(new Cercle(1));
			Cercle.indiceobj=1;
			}
		else if (e.getSource()==be) 
		{	Accueil.Clear();
			Accueil.Add(new Ellipse(1));
			Ellipse.indiceobj=1;
			}
		else if (e.getSource()==bq) 
		{	Accueil.Clear();
			Accueil.Add(new Quadrilatere(1));
			Quadrilatere.indiceobj=1;
			}
		else if (e.getSource()==bretour) 
		{	Accueil.Clear();
			Accueil.Add(new AccueilPanel());
			}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
}
