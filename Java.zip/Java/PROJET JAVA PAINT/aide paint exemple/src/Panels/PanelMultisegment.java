package Panels;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;


public class PanelMultisegment extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel pnl_liste_multiseg = new JPanel();
	
	private ImageIcon icon_segment = new ImageIcon(this.getClass().getResource("../images/segment.png"));
	private JButton btn_segment = new JButton(icon_segment);
	
	
	
	public PanelMultisegment()
	{
		btn_segment.setToolTipText("Cliquez pour cr�er un segment.");
		this.add(btn_segment);
		this.add(pnl_liste_multiseg);
	}



	public JPanel getPnl_liste_multiseg() {
		return pnl_liste_multiseg;
	}



	public void setPnl_liste_multiseg(JPanel pnl_liste_multiseg) {
		this.pnl_liste_multiseg = pnl_liste_multiseg;
	}




	public ImageIcon getIcon_segment() {
		return icon_segment;
	}



	public void setIcon_segment(ImageIcon icon_segment) {
		this.icon_segment = icon_segment;
	}



	public JButton getBtn_segment() {
		return btn_segment;
	}



	public void setBtn_segment(JButton btn_segment) {
		this.btn_segment = btn_segment;
	}

	
}