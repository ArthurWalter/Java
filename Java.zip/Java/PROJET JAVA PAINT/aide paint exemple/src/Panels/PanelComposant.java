package Panels;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelComposant extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnl_composant = new JPanel();
	private ImageIcon icon_rectangle = new ImageIcon(this.getClass().getResource("../images/rectangle.png" ));
	private JButton btn_rectangle = new JButton(icon_rectangle);
	private ImageIcon icon_triangle = new ImageIcon(this.getClass().getResource("../images/triangle.png" ));
	private JButton btn_triangle = new JButton(icon_triangle);
	private ImageIcon icon_cercle = new ImageIcon(this.getClass().getResource("../images/cercle.png"));
	private JButton btn_cercle = new JButton(icon_cercle);
	private ImageIcon icon_segment = new ImageIcon(this.getClass().getResource("../images/segment.png"));
	private JButton btn_segment = new JButton(icon_segment);
	private ImageIcon icon_composite = new ImageIcon(this.getClass().getResource("../images/composite.png"));
	private JButton btn_composite = new JButton(icon_composite);
	private ImageIcon icon_multiseg = new ImageIcon(this.getClass().getResource("../images/multisegment.png"));
	private JButton btn_multiseg= new JButton(icon_multiseg);
	
	public PanelComposant()
	{
		btn_rectangle.setToolTipText("Cliquez pour cr�er un rectangle.");
		btn_cercle.setToolTipText("Cliquez pour cr�er un cercle.");
		btn_triangle.setToolTipText("Cliquez pour cr�er un triangle.");
		btn_segment.setToolTipText("Cliquez pour cr�er un segment.");
		btn_composite.setToolTipText("Cliquez pour cr�er un composite.");
		btn_multiseg.setToolTipText("Cliquez pour cr�er un multisegment.");
		this.add(btn_rectangle);
		this.add(btn_cercle);
		this.add(btn_triangle);
		this.add(btn_segment);
		this.add(btn_composite);
		this.add(btn_multiseg);
		this.setPreferredSize(new Dimension(30,450));
		this.add(pnl_composant,BorderLayout.WEST);
	}
	
	
	public JButton getBtn_composite() {
		return btn_composite;
	}


	public void setBtn_composite(JButton btn_composite) {
		this.btn_composite = btn_composite;
	}

	public ImageIcon getIcon_composite() {
		return icon_composite;
	}


	public void setIcon_composite(ImageIcon icon_composite) {
		this.icon_composite = icon_composite;
	}


	public ImageIcon getIcon_multiseg() {
		return icon_multiseg;
	}


	public void setIcon_multiseg(ImageIcon icon_multiseg) {
		this.icon_multiseg = icon_multiseg;
	}


	public JButton getBtn_multiseg() {
		return btn_multiseg;
	}


	public void setBtn_multiseg(JButton btn_multiseg) {
		this.btn_multiseg = btn_multiseg;
	}


	public ImageIcon getIcon_segment() {
		return icon_segment;
	}


	public void setIcon_segment(ImageIcon icon_segment) {
		this.icon_segment = icon_segment;
	}


	public JButton getBtn_segment() {
		return btn_segment;
	}


	public void setBtn_segment(JButton btn_segment) {
		this.btn_segment = btn_segment;
	}


	public JPanel getPnl_composant() {
		return pnl_composant;
	}


	public void setPnl_composant(JPanel pnl_composant) {
		this.pnl_composant = pnl_composant;
	}


	public ImageIcon getIcon_rectangle() {
		return icon_rectangle;
	}


	public void setIcon_rectangle(ImageIcon icon_rectangle) {
		this.icon_rectangle = icon_rectangle;
	}


	public JButton getBtn_rectangle() {
		return btn_rectangle;
	}


	public void setBtn_rectangle(JButton btn_rectangle) {
		this.btn_rectangle = btn_rectangle;
	}


	public ImageIcon getIcon_triangle() {
		return icon_triangle;
	}


	public void setIcon_triangle(ImageIcon icon_triangle) {
		this.icon_triangle = icon_triangle;
	}


	public JButton getBtn_triangle() {
		return btn_triangle;
	}


	public void setBtn_triangle(JButton btn_triangle) {
		this.btn_triangle = btn_triangle;
	}


	public ImageIcon getIcon_cercle() {
		return icon_cercle;
	}


	public void setIcon_cercle(ImageIcon icon_cercle) {
		this.icon_cercle = icon_cercle;
	}


	public JButton getBtn_cercle() {
		return btn_cercle;
	}


	public void setBtn_cercle(JButton btn_cercle) {
		this.btn_cercle = btn_cercle;
	}
	
	
}
