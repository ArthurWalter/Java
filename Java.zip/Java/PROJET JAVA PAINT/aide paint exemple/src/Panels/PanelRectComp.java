package Panels;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelRectComp extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnl_comp_rect = new JPanel();
	private JLabel lbl_point_rect = new JLabel ("Point : ");
	private JTextField edt_point_rect = new JTextField(15);
	private JLabel lbl_org_rect = new JLabel ("Origine : ");
	private JTextField edt_org_rect = new JTextField(15);
	public PanelRectComp()
	{
		pnl_comp_rect.setPreferredSize(new Dimension(200,145));
		pnl_comp_rect.add(lbl_org_rect);
		pnl_comp_rect.add(edt_org_rect);
		pnl_comp_rect.add(lbl_point_rect);
		pnl_comp_rect.add(edt_point_rect);
		this.add(pnl_comp_rect);
	}
	public JPanel getPnl_comp_rect() {
		return pnl_comp_rect;
	}
	public void setPnl_comp_rect(JPanel pnl_comp_rect) {
		this.pnl_comp_rect = pnl_comp_rect;
	}
	public JLabel getLbl_point_rect() {
		return lbl_point_rect;
	}
	public void setLbl_point_rect(JLabel lbl_point_rect) {
		this.lbl_point_rect = lbl_point_rect;
	}
	public JTextField getEdt_point_rect() {
		return edt_point_rect;
	}
	public void setEdt_point_rect(JTextField edt_point_rect) {
		this.edt_point_rect = edt_point_rect;
	}
	public JLabel getLbl_org_rect() {
		return lbl_org_rect;
	}
	public void setLbl_org_rect(JLabel lbl_org_rect) {
		this.lbl_org_rect = lbl_org_rect;
	}
	public JTextField getEdt_org_rect() {
		return edt_org_rect;
	}
	public void setEdt_org_rect(JTextField edt_org_rect) {
		this.edt_org_rect = edt_org_rect;
	}
}
