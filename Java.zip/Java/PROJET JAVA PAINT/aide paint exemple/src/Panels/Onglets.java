package Panels;

import java.awt.Dimension;
import javax.swing.*;

 

public class Onglets {
	
JPanel pannel = new JPanel();
JTabbedPane onglets = new JTabbedPane(SwingConstants.TOP);
JPanel onglet1 = new JPanel();
JLabel titreOnglet1 = new JLabel("Onglet 1");
JPanel onglet2 = new JPanel();
JLabel titreOnglet2 = new JLabel("Onglet 2");
public Onglets()
{
JPanel f = new JPanel();
f.setSize(new Dimension(200,200));
f.setPreferredSize(new Dimension(0, 0));

onglet1.add(titreOnglet1);
onglet1.setPreferredSize(new Dimension(300, 80));
onglets.addTab("onglet1", onglet1);

onglet2.add(titreOnglet2);
onglets.addTab("onglet2", onglet2);
onglets.setOpaque(true);
pannel.add(onglets);
f.add(pannel);
}
}