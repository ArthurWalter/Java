package Panels;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelTriangle extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnl_edt_tri = new JPanel();
	private JLabel lbl_point2_tri = new JLabel ("Point 2: ");
	private JLabel lbl_point3_tri = new JLabel ("Point 3: ");
	private JTextField edt_point2_tri = new JTextField(15);
	private JTextField edt_point3_tri = new JTextField(15);
	
	public PanelTriangle()
	{
		pnl_edt_tri.setPreferredSize(new Dimension(200,115));
		pnl_edt_tri.add(lbl_point2_tri);
		pnl_edt_tri.add(edt_point2_tri);
		pnl_edt_tri.add(lbl_point3_tri);
		pnl_edt_tri.add(edt_point3_tri);
		this.add(pnl_edt_tri);
		
	}

	public JPanel getPnl_edt_tri() {
		return pnl_edt_tri;
	}


	public void setPnl_edt_tri(JPanel pnl_edt_tri) {
		this.pnl_edt_tri = pnl_edt_tri;
	}

	public JLabel getLbl_point2_tri() {
		return lbl_point2_tri;
	}

	public void setLbl_point2_tri(JLabel lbl_point2_tri) {
		this.lbl_point2_tri = lbl_point2_tri;
	}

	public JLabel getLbl_point3_tri() {
		return lbl_point3_tri;
	}

	public void setLbl_point3_tri(JLabel lbl_point3_tri) {
		this.lbl_point3_tri = lbl_point3_tri;
	}

	public JTextField getEdt_point2_tri() {
		return edt_point2_tri;
	}

	public void setEdt_point2_tri(JTextField edt_point2_tri) {
		this.edt_point2_tri = edt_point2_tri;
	}

	public JTextField getEdt_point3_tri() {
		return edt_point3_tri;
	}

	public void setEdt_point3_tri(JTextField edt_point3_tri) {
		this.edt_point3_tri = edt_point3_tri;
	}
	

	
}
