package Panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import UML.Composant;
import UML.Composite;
import UML.Multisegment;
import UML.Point2D;
import UML.Rectangle;
import UML.Cercle;
import UML.Segment;
import UML.Triangle;

public class Cadre extends JFrame implements ActionListener,ListSelectionListener,KeyListener,MouseListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private PanelDraw pnl_draw = new PanelDraw();
	private PanelComposant pnl_composant = new PanelComposant();
	private JPanel pnl_liste = new JPanel();
	private PanelEdit pnl_edit = new PanelEdit();
	private PanelRect pnl_edt_rect = new PanelRect();
	private PanelCercle pnl_edt_cercle = new PanelCercle();
	private PanelTriangle pnl_edt_tri = new PanelTriangle();
	private PanelSegment pnl_edt_seg=new PanelSegment();
	private PanelComposite pnl_edt_comp = new PanelComposite();
	private PanelCercleComp pnl_comp_cercle = new PanelCercleComp();
	private PanelTriangleComp pnl_comp_tri = new PanelTriangleComp();
	private PanelSegmentComp pnl_comp_seg = new PanelSegmentComp();
	private PanelMultisegment pnl_edt_mulseg = new PanelMultisegment();
	private PanelSegmentComp pnl_mseg = new PanelSegmentComp();
	private JPanel pnl_general_edit = new JPanel();
	private JPanel pnl_item = new JPanel();
	private JPanel pnl_comp = new JPanel();
	private JPanel pnl_liste_mseg = new JPanel();
	
	private PanelRectComp pnl_comp_rect = new PanelRectComp();
	private JMenuBar menuBar = new JMenuBar();
	private JMenu fichier = new JMenu("Fichier");
	private JMenuItem fermer = new JMenuItem("Fermer");
	
	private JButton btn_ok = new JButton("Ok");
	
	Composite C= new Composite();
	
	public Cadre(String titre){      
			super(titre);                      
			this.setLocation(100,100);              
			this.setSize(1024, 780);                
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			BorderLayout b=new BorderLayout(); 
			b.setVgap(2);
			b.setHgap(10);   
			this.setLayout(b); 
			this.AddPanels();
			this.AddListener();
	}

	public void AddPanels()
	{
	this.add(pnl_item,BorderLayout.EAST);
	this.menuBar.add(fichier);
	this.setJMenuBar(menuBar);
	this.setVisible(true);
	this.fichier.addSeparator();
	this.fichier.add(fermer);
	this.add(pnl_composant,BorderLayout.WEST);
	this.getContentPane().add(pnl_draw);
	pnl_item.add(C.getPnl_liste_compo());
	pnl_item.add(pnl_general_edit);

	pnl_general_edit.setPreferredSize(new Dimension(250,this.getHeight()));
	pnl_item.setPreferredSize(new Dimension(270,780));
	pnl_liste.setPreferredSize(new Dimension(270,229));
	pnl_edt_comp.setPreferredSize(new Dimension(250,35));
	pnl_edt_mulseg.setPreferredSize(new Dimension(250,35));
	pnl_comp.setPreferredSize(new Dimension(250,160));
	pnl_liste_mseg.setPreferredSize(new Dimension(250,135));
	
	pnl_general_edit.add(pnl_edit);
	pnl_general_edit.add(pnl_edt_rect);
	pnl_general_edit.add(pnl_edt_cercle);
	pnl_general_edit.add(pnl_edt_tri);
	pnl_general_edit.add(pnl_edt_seg);
	pnl_general_edit.add(pnl_edt_comp);
	pnl_general_edit.add(pnl_comp);
	pnl_general_edit.add(pnl_edt_mulseg);
	pnl_general_edit.add(pnl_liste_mseg);
	pnl_general_edit.add(pnl_comp_rect);
	pnl_general_edit.add(pnl_comp_cercle);
	pnl_general_edit.add(pnl_comp_tri);
	pnl_general_edit.add(pnl_comp_seg);
	pnl_general_edit.add(pnl_mseg);
	pnl_general_edit.add(btn_ok);
	
	pnl_edt_tri.setVisible(false);
	pnl_edt_rect.setVisible(false);
	pnl_edt_cercle.setVisible(false);
	pnl_edt_seg.setVisible(false);
	pnl_edt_comp.setVisible(false);
	pnl_edt_mulseg.setVisible(false);
	pnl_comp_rect.setVisible(false);
	pnl_comp_cercle.setVisible(false);
	pnl_comp_tri.setVisible(false);
	pnl_comp_seg.setVisible(false);
	pnl_mseg.setVisible(false);
	pnl_comp.setVisible(false);
	pnl_liste_mseg.setVisible(false);
	}
	
	public void AddListener()
	{

		pnl_composant.getBtn_rectangle().addActionListener(this);
		pnl_composant.getBtn_cercle().addActionListener(this);
		pnl_composant.getBtn_triangle().addActionListener(this);
		pnl_composant.getBtn_segment().addActionListener(this);
		pnl_composant.getBtn_composite().addActionListener(this);
		pnl_composant.getBtn_multiseg().addActionListener(this);
		C.getList_compo().addListSelectionListener(this);
		C.getList_compo().addMouseListener(this);
		
		btn_ok.addActionListener(this);
		fermer.addActionListener(this);
		pnl_edit.getEdt_name().addKeyListener(this);
		pnl_edit.getEdt_origine().addKeyListener(this);
		pnl_edt_rect.getEdt_point_rect().addKeyListener(this);
		pnl_edt_cercle.getEdt_rayon_cercle().addKeyListener(this);
		pnl_edt_tri.getEdt_point2_tri().addKeyListener(this);
		pnl_edt_tri.getEdt_point3_tri().addKeyListener(this);
		pnl_edt_seg.getEdt_point_seg().addKeyListener(this);
		pnl_comp_rect.getEdt_org_rect().addKeyListener(this);
		pnl_comp_rect.getEdt_point_rect().addKeyListener(this);
		pnl_comp_cercle.getEdt_org_cercle().addKeyListener(this);
		pnl_comp_cercle.getEdt_rayon_cercle().addKeyListener(this);
		pnl_comp_tri.getEdt_origine_tri().addKeyListener(this);
		pnl_comp_tri.getEdt_point2_tri().addKeyListener(this);
		pnl_comp_tri.getEdt_point3_tri().addKeyListener(this);
		pnl_comp_seg.getEdt_org_seg().addKeyListener(this);
		pnl_comp_seg.getEdt_point_seg().addKeyListener(this);
		
		pnl_edt_comp.getBtn_cercle().addActionListener(this);
		pnl_edt_comp.getBtn_rectangle().addActionListener(this);
		pnl_edt_comp.getBtn_segment().addActionListener(this);
		pnl_edt_comp.getBtn_triangle().addActionListener(this);
		pnl_edt_mulseg.getBtn_segment().addActionListener(this);
		pnl_mseg.getEdt_org_seg().addKeyListener(this);
		pnl_mseg.getEdt_point_seg().addKeyListener(this);

	}
	
	

	 
	@SuppressWarnings("unchecked")
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		//Si on appuie sur le bouton fermer
		if(e.getSource().equals(fermer))
		{
			System.exit(0);
		}
				
		//Si on appuie sur le bouton rectangle, enleve les panels affich�s et affiche le bon
		//Ajoute un rectangle au composite C
		//Ajoute "Rectangle" a la liste, recupere le nom dans edt_name et son origine
		else if (e.getSource().equals(pnl_composant.getBtn_rectangle()))
		{	
			Rectangle rect = new Rectangle();
			pnl_edt_rect.setVisible(true);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			C.ajouter(rect);
			C.getListComposite().addElement("Rectangle");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(rect.getOrigine().getX() +"," +rect.getOrigine().getY()));
			pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX()) +"," +String.valueOf(rect.getPoint().getY()));
		}
		
		
		
		//Si on appuie sur le bouton cercle
		//Enleve les panels
		//Ajoute un cercle au composite
		else if (e.getSource().equals(pnl_composant.getBtn_cercle()))
		{	
			Cercle cercle = new Cercle();
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(true);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			C.ajouter(cercle);
			C.getListComposite().addElement("Cercle");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(cercle.getOrigine().getX() +"," +cercle.getOrigine().getY()));
			pnl_edt_cercle.getEdt_rayon_cercle().setText(String.valueOf(cercle.getRayon()));
		}
		
		
		
		//Idem mais avec un triangle
		else if (e.getSource().equals(pnl_composant.getBtn_triangle()))
		{
			Triangle tri = new Triangle();
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(true);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			C.ajouter(tri);
			C.getListComposite().addElement("Triangle");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(tri.getOrigine().getX() +"," +tri.getOrigine().getY()));
			pnl_edt_tri.getEdt_point2_tri().setText(String.valueOf(tri.getPoint1().getX() +"," +tri.getPoint1().getY()));
			pnl_edt_tri.getEdt_point3_tri().setText(String.valueOf(tri.getPoint2().getX() +"," +tri.getPoint2().getY()));
		
		}
		
		
		
		//Idem mais avec un segment
		else if(e.getSource().equals(pnl_composant.getBtn_segment()))
		{
			Segment seg = new Segment();
			pnl_edt_seg.setVisible(true);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			C.ajouter(seg);
			C.getListComposite().addElement("Segment");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(seg.getOrigine().getX() +"," +seg.getOrigine().getY()));
			pnl_edt_seg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX()) +"," +String.valueOf(seg.getPoint().getY()));
		}
		
		
		//Idem mais avec un composite
		else if (e.getSource().equals(pnl_composant.getBtn_composite()))
		{
			
			Composite comp = new Composite();
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(true);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false); 
			
			pnl_comp.removeAll();
			pnl_comp.setVisible(true);
			pnl_comp.add(comp.getScroll_compo());
			C.ajouter(comp);

			C.getListComposite().addElement("Composite");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			comp.getList_compo().addMouseListener(this);
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(comp.getOrigine().getX() +"," +comp.getOrigine().getY()));
		}
		
		//Idem mais avec un multisegment
		else if (e.getSource().equals(pnl_composant.getBtn_multiseg()))
		{
			Multisegment mseg = new Multisegment();
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(true);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			
			pnl_liste_mseg.removeAll();
			pnl_liste_mseg.setVisible(true);
			pnl_liste_mseg.add(mseg.getScroll_multiseg());
		
			C.ajouter(mseg);

			C.getListComposite().addElement("Multisegment");
			C.getList_compo().setSelectedIndex(C.getList_compo().getLastVisibleIndex());
			mseg.getList_multiseg().addMouseListener(this);
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(mseg.getOrigine().getX() +"," +mseg.getOrigine().getY()));
		}

		//Si on appui sur bouton rectangle du composite cr�e
		else if (e.getSource().equals(pnl_edt_comp.getBtn_rectangle()))
		{
			Rectangle rect = new Rectangle();
			pnl_edt_comp.setVisible(true);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_comp_rect.setVisible(true);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			
			Composite comp=((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
			comp.ajouter(rect);
			pnl_draw.afficher(rect);
			comp.getListComposite().addElement("Rectangle");
			comp.getList_compo().setSelectedIndex(comp.getList_compo().getLastVisibleIndex());
			pnl_comp_rect.getEdt_org_rect().requestFocus();
			pnl_comp_rect.getEdt_org_rect().setText(String.valueOf(rect.getOrigine().getX() +"," +rect.getOrigine().getY()));
			pnl_comp_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX()) +"," +String.valueOf(rect.getPoint().getY()));
		}
		
		
		
		
		else if (e.getSource().equals(pnl_edt_comp.getBtn_cercle()))
		{
			Cercle cercle = new Cercle();
			pnl_edt_comp.setVisible(true);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(true);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			
			Composite comp=((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
			comp.ajouter(cercle);
			pnl_draw.afficher(cercle);
			comp.getListComposite().addElement("Cercle");
			comp.getList_compo().setSelectedIndex(comp.getList_compo().getLastVisibleIndex());
			pnl_comp_cercle.getEdt_org_cercle().requestFocus();
			pnl_comp_cercle.getEdt_org_cercle().setText(String.valueOf(cercle.getOrigine().getX() +"," +cercle.getOrigine().getY()));
			pnl_comp_cercle.getEdt_rayon_cercle().setText(String.valueOf(cercle.getRayon()));
		}
		
		else if (e.getSource().equals(pnl_edt_comp.getBtn_triangle()))
		{
			Triangle tri = new Triangle();
			pnl_edt_comp.setVisible(true);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(true);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			
			Composite comp=((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
			comp.ajouter(tri);
			pnl_draw.afficher(tri);
			comp.getListComposite().addElement("Triangle");
			comp.getList_compo().setSelectedIndex(comp.getList_compo().getLastVisibleIndex());
			pnl_comp_tri.getEdt_origine_tri().requestFocus();
			pnl_comp_tri.getEdt_origine_tri().setText(String.valueOf(tri.getOrigine().getX() +"," +tri.getOrigine().getY()));
			pnl_comp_tri.getEdt_point2_tri().setText(String.valueOf(tri.getPoint1().getX() +"," +tri.getPoint1().getY()));
			pnl_comp_tri.getEdt_point3_tri().setText(String.valueOf(tri.getPoint2().getX() +"," +tri.getPoint2().getY()));
		}
		

		else if (e.getSource().equals(pnl_edt_comp.getBtn_segment()))
		{
			Segment seg = new Segment();
			pnl_edt_comp.setVisible(true);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(true);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			
			Composite comp=((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
			comp.ajouter(seg);
			pnl_draw.afficher(seg);
			comp.getListComposite().addElement("Segment");
			comp.getList_compo().setSelectedIndex(comp.getList_compo().getLastVisibleIndex());
			pnl_comp_seg.getEdt_org_seg().requestFocus();
			pnl_comp_seg.getEdt_org_seg().setText(String.valueOf(seg.getOrigine().getX() +"," +seg.getOrigine().getY()));
			pnl_comp_seg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX() +"," +seg.getPoint().getY()));
		}
		
		
		//Si on appuie sur le bouton segment lors de la construction d'un multisegment
		else if (e.getSource().equals(pnl_edt_mulseg.getBtn_segment()))
		{
			Segment seg = new Segment();
			pnl_edt_comp.setVisible(false);
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(true);
			pnl_comp.setVisible(false);
			pnl_mseg.setVisible(true);
			
			Multisegment mseg=((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex()));
			mseg.ajouter(seg);
			pnl_draw.afficher(seg);
			mseg.getListMultiseg().addElement("Segment");
			mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getLastVisibleIndex());
			pnl_mseg.getEdt_org_seg().requestFocus();

		}
		
		
		
		
		
		//BOUTON OK
		//On verifie les saisies, on split la chaine et on defini le nouveau composant
		
		else if (e.getSource().equals(btn_ok))
		{	
			if (pnl_edit.getEdt_name().getText().equals(""))
			{
				JOptionPane.showMessageDialog(this,"Vous n'avez pas entr� un nom correct","Erreur : Nom",JOptionPane.NO_OPTION);
			}
			else if (pnl_edit.getEdt_origine().getText().equals(""))
			{
				JOptionPane.showMessageDialog(this,"Vous n'avez pas entr� une origine correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
			}
			else
			{
	
			pnl_draw.effacer(C.getC().get(C.getList_compo().getSelectedIndex()));
			String str_org[];
			String ch_org=pnl_edit.getEdt_origine().getText();
			str_org=Nettoyer(ch_org);

			if(str_org.length==2)
			{
			if (!this.verifierInt(str_org[0]) || !this.verifierInt(str_org[1]))
			{
				JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
			}
			else
			{
			if ((Integer.parseInt(str_org[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_org[0]) > pnl_draw.getWidth()))
			{
				JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
			}
			else
			{
			C.getListComposite().set(C.getList_compo().getSelectedIndex(), pnl_edit.getEdt_name().getText());
			if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Rectangle)
			{	
				if (pnl_edt_rect.getEdt_point_rect().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le point de ce rectangle n'est pas correct","Erreur : Mauvais point",JOptionPane.NO_OPTION);
				}
				else
				{
				String str_pt[];
				String ch_pt=pnl_edt_rect.getEdt_point_rect().getText();
				str_pt=Nettoyer(ch_pt);
				if (str_pt.length==2)
				{
				if (!this.verifierInt(str_pt[0])||!this.verifierInt(str_pt[1]))
				{
					JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
				}
				else
				{
				if ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth()))
				{
					JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
				}
				else
				{
				pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
				C.getC().set(C.getList_compo().getSelectedIndex(), new Rectangle(new Point2D(Integer.parseInt(str_org[0]),Integer.parseInt(str_org[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
				}
				}
				}
				}
				}
			
			
			
			else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Cercle)
			{
				if (pnl_edt_cercle.getEdt_rayon_cercle().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le rayon de ce cercle n'est pas correct","Erreur : Mauvais Rayon",JOptionPane.NO_OPTION);
				}
				else
				{
				String str_pt[];
				String ch_pt=pnl_edt_cercle.getEdt_rayon_cercle().getText();
				str_pt=Nettoyer(ch_pt);
				if (str_pt.length==1)
				{
				if (!this.verifierInt(str_pt[0]))
				{
					JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
				}
				else
				{
				C.getC().set(C.getList_compo().getSelectedIndex(), new Cercle(new Point2D(Integer.parseInt(str_org[0]),Integer.parseInt(str_org[1])),(Integer.parseInt(str_pt[0]))));
				}
				}
				}
			}
			else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Triangle)
			{
				if (pnl_edt_tri.getEdt_point2_tri().getText().equals("")||pnl_edt_tri.getEdt_point3_tri().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Un point de ce triangle n'est pas correct","Erreur : Mauvais point(s)",JOptionPane.NO_OPTION);
				}
				else
				{
				String str_pt2[];
				String ch_pt2=pnl_edt_tri.getEdt_point2_tri().getText();
				str_pt2=Nettoyer(ch_pt2);

				String str_pt3[];
				String ch_pt3=pnl_edt_tri.getEdt_point3_tri().getText();
				str_pt3=Nettoyer(ch_pt3);
				if (str_pt2.length==2 && str_pt3.length==2)
				{
				if (!this.verifierInt(str_pt2[0])||!this.verifierInt(str_pt2[1]) || !this.verifierInt(str_pt3[0]) || !this.verifierInt(str_pt3[1]))
				{
					JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
				}
				else
				{
				if (((Integer.parseInt(str_pt2[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt2[0]) > pnl_draw.getWidth())) || ((Integer.parseInt(str_pt3[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt3[0]) > pnl_draw.getWidth())))
				{
					JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
				}
				else
				{
				C.getC().set(C.getList_compo().getSelectedIndex(), new Triangle(new Point2D(Integer.parseInt(str_org[0]),Integer.parseInt(str_org[1])),new Point2D(Integer.parseInt(str_pt2[0]),Integer.parseInt(str_pt2[1])),new Point2D(Integer.parseInt(str_pt3[0]),Integer.parseInt(str_pt3[1]))));
				}
				}
				}
				}
			}
			else if(C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Segment)
			{
				if (pnl_edt_seg.getEdt_point_seg().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le deuxi�me point de ce segment n'est pas correct","Erreur : Mauvais point",JOptionPane.NO_OPTION);
				}
				else
				{
				String str_pt[];
				String ch_pt=pnl_edt_seg.getEdt_point_seg().getText();
				str_pt=Nettoyer(ch_pt);
				if (str_pt.length==2)
				{
				if (!this.verifierInt(str_pt[0])||!this.verifierInt(str_pt[1]))
				{
					JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
				}
				else
				{
				if ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth()))
				{
					JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
				}
				else
				{
				pnl_edt_seg.getEdt_point_seg().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
				C.getC().set(C.getList_compo().getSelectedIndex(), new Segment(new Point2D(Integer.parseInt(str_org[0]),Integer.parseInt(str_org[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
				}
				}
				}
				}
			}
			}
			}

		if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Composite)
			{		
			
			
			if(pnl_comp_rect.isVisible() || pnl_comp_cercle.isVisible() || pnl_comp_tri.isVisible() || pnl_comp_seg.isVisible())
		{
			Composite comp = (((Composite) C.getC().get(C.getList_compo().getSelectedIndex())));
			String str_orgcomp[];
			String ch_orgcomp=pnl_edit.getEdt_origine().getText();
			str_orgcomp=Nettoyer(ch_orgcomp);
			if (Integer.valueOf(str_orgcomp[0]) != comp.getOrigine().getX() || Integer.valueOf(str_orgcomp[1]) != comp.getOrigine().getY())
			{
				comp.setOrigine(new Point2D(Integer.parseInt(str_orgcomp[0]),Integer.parseInt(str_orgcomp[1])));
				
				for(int i=0;i<=comp.getList_compo().getLastVisibleIndex();i++)
				{
					comp.getList_compo().setSelectedIndex(i);
					if (comp.getC().get(i) instanceof Rectangle)
					{
						String str_orgrect[];
						String ch_orgrect=pnl_comp_rect.getEdt_org_rect().getText();
						str_orgrect=Nettoyer(ch_orgrect);
						
						int nb1 = Integer.parseInt(str_orgrect[0])+Integer.parseInt(str_orgcomp[0]);
						int nb2 = Integer.parseInt(str_orgrect[1])+Integer.parseInt(str_orgcomp[1]);
						pnl_comp_rect.getEdt_org_rect().setText(String.valueOf(nb1 +"," +nb2));
						btn_ok.doClick();
					}
					else if (comp.getC().get(i) instanceof Cercle)
					{
						String str_orgcercle[];
						String ch_orgcercle=pnl_comp_cercle.getEdt_org_cercle().getText();
						str_orgcercle=Nettoyer(ch_orgcercle);
						
						int nb1 = Integer.parseInt(str_orgcercle[0])+Integer.parseInt(str_orgcomp[0]);
						int nb2 = Integer.parseInt(str_orgcercle[1])+Integer.parseInt(str_orgcomp[1]);
						pnl_comp_cercle.getEdt_org_cercle().setText(String.valueOf(nb1 +"," +nb2));
						btn_ok.doClick();
					}
					else if (comp.getC().get(i) instanceof Triangle)
					{
						String str_orgtri[];
						String ch_orgtri=pnl_comp_tri.getEdt_origine_tri().getText();
						str_orgtri=Nettoyer(ch_orgtri);
						
						int nb1 = Integer.parseInt(str_orgtri[0])+Integer.parseInt(str_orgcomp[0]);
						int nb2 = Integer.parseInt(str_orgtri[1])+Integer.parseInt(str_orgcomp[1]);
						pnl_comp_tri.getEdt_origine_tri().setText(String.valueOf(nb1 +"," +nb2));
						btn_ok.doClick();
					}
					else if (comp.getC().get(i) instanceof Segment)
					{
						String str_orgseg[];
						String ch_orgseg=pnl_comp_seg.getEdt_org_seg().getText();
						str_orgseg=Nettoyer(ch_orgseg);
						
						int nb1 = Integer.parseInt(str_orgseg[0])+Integer.parseInt(str_orgcomp[0]);
						int nb2 = Integer.parseInt(str_orgseg[1])+Integer.parseInt(str_orgcomp[1]);
						pnl_comp_seg.getEdt_org_seg().setText(String.valueOf(nb1 +"," +nb2));
						btn_ok.doClick();
					}	
				}
			}

			if ((((Composite) C.getC().get(C.getList_compo().getSelectedIndex())).getC().get(comp.getList_compo().getSelectedIndex()) instanceof Rectangle))
			{
				if (pnl_comp_rect.getEdt_org_rect().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"L'origine n'est pas correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
				}
				else if (pnl_comp_rect.getEdt_point_rect().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le point de ce rectangle n'est pas correct","Erreur : Mauvais point",JOptionPane.NO_OPTION);
				}
				else
				{
					String str_orgrect[];
					String ch_orgrect=pnl_comp_rect.getEdt_org_rect().getText();
					str_orgrect=Nettoyer(ch_orgrect);
					
					
					String str_pt[];
					String ch_pt=pnl_comp_rect.getEdt_point_rect().getText();
					str_pt=Nettoyer(ch_pt);
					if (str_pt.length==2 && str_orgrect.length==2)
					{
					if (!this.verifierInt(str_orgrect[0])||!this.verifierInt(str_orgrect[1])||!this.verifierInt(str_pt[0])||!this.verifierInt(str_pt[1]))
					{
						JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
					}
					else
					{
					if (((Integer.parseInt(str_orgrect[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_orgrect[0]) > pnl_draw.getWidth())) || ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth())))
					{
						JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
					}
					else
					{
					pnl_comp_rect.getEdt_point_rect().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
					pnl_comp_rect.getEdt_org_rect().setText(String.valueOf(Integer.parseInt(str_orgrect[0]) +"," +Integer.parseInt(str_orgrect[1])));
					comp.getC().set((comp.getList_compo().getSelectedIndex()), new Rectangle(new Point2D(Integer.parseInt(str_orgrect[0]),Integer.parseInt(str_orgrect[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
					}
					}
				}
				}
			}
			
			else if ((((Composite) C.getC().get(C.getList_compo().getSelectedIndex())).getC().get(comp.getList_compo().getSelectedIndex()) instanceof Cercle))
			{
				if (pnl_comp_cercle.getEdt_org_cercle().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"L'origine n'est pas correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
				}
				else if (pnl_comp_cercle.getEdt_rayon_cercle().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le rayon de ce cercle n'est pas correct","Erreur : Mauvais point",JOptionPane.NO_OPTION);
				}
				else
				{
					
					String str_orgcercle[];
					String ch_orgcercle=pnl_comp_cercle.getEdt_org_cercle().getText();
					str_orgcercle=Nettoyer(ch_orgcercle);
					String ch_ra=pnl_comp_cercle.getEdt_rayon_cercle().getText();
					if (str_orgcercle.length==2)
					{
					if (!this.verifierInt(str_orgcercle[0])||!this.verifierInt(str_orgcercle[1])||!this.verifierInt(ch_ra))
					{
						JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
					}
					else
					{
					if (((Integer.parseInt(str_orgcercle[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_orgcercle[0]) > pnl_draw.getWidth())))
					{
						JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
					}
					else
					{
					pnl_comp_cercle.getEdt_org_cercle().setText(String.valueOf(Integer.parseInt(str_orgcercle[0]) +"," +Integer.parseInt(str_orgcercle[1])));
					pnl_comp_cercle.getEdt_rayon_cercle().setText(String.valueOf(Integer.parseInt(ch_ra)));
					
					comp.getC().set((comp.getList_compo().getSelectedIndex()), new Cercle(new Point2D(Integer.parseInt(str_orgcercle[0]),Integer.parseInt(str_orgcercle[1])),Integer.parseInt(ch_ra)));
					}
					}
				}
			}	
			}
			else if ((((Composite) C.getC().get(C.getList_compo().getSelectedIndex())).getC().get(comp.getList_compo().getSelectedIndex()) instanceof Triangle))
			{
				if (pnl_comp_tri.getEdt_origine_tri().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"L'origine n'est pas correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
				}
				else if (pnl_comp_tri.getEdt_point2_tri().getText().equals("") || pnl_comp_tri.getEdt_point3_tri().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Un des points de ce triangle n'est pas correct","Erreur : Mauvais point(s)",JOptionPane.NO_OPTION);
				}
				else
				{
					
					String str_orgtri[];
					String ch_orgtri=pnl_comp_tri.getEdt_origine_tri().getText();
					str_orgtri=Nettoyer(ch_orgtri);
					
					String str_pt1[];
					String ch_pt1=pnl_comp_tri.getEdt_point2_tri().getText();
					str_pt1=Nettoyer(ch_pt1);
					
					String str_pt2[];
					String ch_pt2=pnl_comp_tri.getEdt_point3_tri().getText();
					str_pt2=Nettoyer(ch_pt2);
					if (str_orgtri.length==2 && str_pt1.length==2 && str_pt2.length==2) 
					{
					if ((!this.verifierInt(str_orgtri[0]))||(!this.verifierInt(str_orgtri[1]))||(!this.verifierInt(str_pt1[0]))||(!this.verifierInt(str_pt1[1]))||(!this.verifierInt(str_pt2[0])) || (!this.verifierInt(str_pt2[1])))
					{
						JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
					}
					else
					{
					
					if (((Integer.parseInt(str_orgtri[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_orgtri[0]) > pnl_draw.getWidth())) || ((Integer.parseInt(str_pt1[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt1[0]) > pnl_draw.getWidth())||((Integer.parseInt(str_pt2[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt2[0]) > pnl_draw.getWidth()))))
					{
						JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
					}
					else
					{
					pnl_comp_tri.getEdt_origine_tri().setText(String.valueOf(Integer.parseInt(str_orgtri[0]) +"," +Integer.parseInt(str_orgtri[1])));
					pnl_comp_tri.getEdt_point3_tri().setText(String.valueOf(Integer.parseInt(str_pt2[0]) +"," +Integer.parseInt(str_pt2[1])));
					pnl_comp_tri.getEdt_point2_tri().setText(String.valueOf(Integer.parseInt(str_pt1[0]) +"," +Integer.parseInt(str_pt1[1])));
					comp.getC().set((comp.getList_compo().getSelectedIndex()), new Triangle(new Point2D(Integer.parseInt(str_orgtri[0]),Integer.parseInt(str_orgtri[1])),new Point2D(Integer.parseInt(str_pt1[0]),Integer.parseInt(str_pt1[1])),new Point2D(Integer.parseInt(str_pt2[0]),Integer.parseInt(str_pt2[1]))));
					}
					}
				}
				}
			}
			else if ((((Composite) C.getC().get(C.getList_compo().getSelectedIndex())).getC().get(comp.getList_compo().getSelectedIndex()) instanceof Segment))
			{
				if (pnl_comp_seg.getEdt_org_seg().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"L'origine n'est pas correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
				}
				else if (pnl_comp_seg.getEdt_point_seg().getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Le point de ce segment est incorrect","Erreur : Mauvais point",JOptionPane.NO_OPTION);
				}
				else
				{
					
					String str_orgseg[];
					String ch_orgseg=pnl_comp_seg.getEdt_org_seg().getText();
					str_orgseg=Nettoyer(ch_orgseg);
					
					String str_pt[];
					String ch_pt=pnl_comp_seg.getEdt_point_seg().getText();
					str_pt=Nettoyer(ch_pt);
					if (str_pt.length==2 && str_orgseg.length==2)
					{
					if (!this.verifierInt(str_orgseg[0])||!this.verifierInt(str_orgseg[1])||!this.verifierInt(str_pt[0])||!this.verifierInt(str_pt[1]))
					{
						JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
					}
					else
					{
					if (((Integer.parseInt(str_orgseg[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_orgseg[0]) > pnl_draw.getWidth())) || ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth())))
					{
						JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
					}
					
					else
					{
					pnl_comp_seg.getEdt_point_seg().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
					pnl_comp_seg.getEdt_org_seg().setText(String.valueOf(Integer.parseInt(str_orgseg[0]) +"," +Integer.parseInt(str_orgseg[1])));
					comp.getC().set((comp.getList_compo().getSelectedIndex()), new Segment(new Point2D(Integer.parseInt(str_orgseg[0]),Integer.parseInt(str_orgseg[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
					}
					}
					}
				}
			}
		}
		}

		else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Multisegment)
		{

			if (pnl_mseg.isVisible())
			{			
				
			Multisegment mseg = (((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex())));
			
			String str_orgmseg[];
			String ch_orgmseg=pnl_edit.getEdt_origine().getText();
			str_orgmseg=Nettoyer(ch_orgmseg);

			if (Integer.valueOf(str_orgmseg[0]) != mseg.getOrigine().getX() || Integer.valueOf(str_orgmseg[1]) != mseg.getOrigine().getY())
			{
				mseg.setOrigine(new Point2D(Integer.parseInt(str_orgmseg[0]),Integer.parseInt(str_orgmseg[1])));
				mseg.getS().get(0).setOrigine(new Point2D(Integer.parseInt(str_orgmseg[0]),Integer.parseInt(str_orgmseg[1])));
				int tmp = mseg.getList_multiseg().getSelectedIndex();
				mseg.getList_multiseg().setSelectedIndex(0);
				pnl_mseg.getEdt_org_seg().setText(String.valueOf(mseg.getOrigine().getX()) +"," +mseg.getOrigine().getY());
				mseg.getList_multiseg().setSelectedIndex(tmp);
				
				for(int i=0;i<=mseg.getList_multiseg().getLastVisibleIndex();i++)
				{
					mseg.getList_multiseg().setSelectedIndex(i);
					btn_ok.doClick();

				}
				mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getLastVisibleIndex());
			}
			
			
		if ((((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex())).getS().get(mseg.getList_multiseg().getSelectedIndex())) instanceof Segment)
		{
			if (pnl_mseg.getEdt_org_seg().getText().equals(""))
			{
				JOptionPane.showMessageDialog(this,"L'origine n'est pas correcte","Erreur : Mauvaise origine",JOptionPane.NO_OPTION);
			}
			else if (pnl_mseg.getEdt_point_seg().getText().equals(""))
			{
				JOptionPane.showMessageDialog(this,"Le point de ce segment est incorrect","Erreur : Mauvais point",JOptionPane.NO_OPTION);
			}
			else
			{
				String str_orgseg[];
				String ch_orgseg=pnl_mseg.getEdt_org_seg().getText();
				str_orgseg=Nettoyer(ch_orgseg);
				
				String str_pt[];
				String ch_pt=pnl_mseg.getEdt_point_seg().getText();
				str_pt=Nettoyer(ch_pt);
				if (str_pt.length==2 && str_orgseg.length==2)
				{
				if (!this.verifierInt(str_orgseg[0])||!this.verifierInt(str_orgseg[1])||!this.verifierInt(str_pt[0])||!this.verifierInt(str_pt[1]))
				{
					JOptionPane.showMessageDialog(this,"Saisie incorrecte","Erreur : Mauvaise saisie",JOptionPane.NO_OPTION);
				}
				else
				{
				if (((Integer.parseInt(str_orgseg[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_orgseg[0]) > pnl_draw.getWidth())) || ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth())))
				{
					JOptionPane.showMessageDialog(this,"Valeur trop grande","Erreur : Valeur trop grande",JOptionPane.NO_OPTION);
				}
				else
				{
				pnl_mseg.getEdt_point_seg().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
				mseg.getS().set((mseg.getList_multiseg().getSelectedIndex()), new Segment(new Point2D(Integer.parseInt(str_orgseg[0]),Integer.parseInt(str_orgseg[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
				pnl_edit.getEdt_origine().setText(String.valueOf(mseg.getS().get(0).getOrigine().getX()) +"," +mseg.getS().get(0).getOrigine().getY());
					if (mseg.getList_multiseg().getSelectedIndex() < mseg.getList_multiseg().getLastVisibleIndex() && mseg.getList_multiseg().getSelectedIndex() > mseg.getList_multiseg().getFirstVisibleIndex())
					{
						mseg.getS().get(mseg.getList_multiseg().getSelectedIndex()+1).setOrigine(new Point2D(mseg.getS().get(mseg.getList_multiseg().getSelectedIndex()+1).getPoint().getX(),mseg.getS().get(mseg.getList_multiseg().getSelectedIndex()).getPoint().getY()));
						mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getSelectedIndex()+1);
						btn_ok.doClick();
						mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getSelectedIndex()-1);
					}
				}
				}
				}
			}
		}
		}
		}
	}		
}
			this.afficher();
	}		
}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		
		//Si on change d'element dans la liste
		//On reaffiche
		//On reaffiche les panels associ�s, et on rempli les edit avec les valeurs du composant
		this.afficher();

		if(e.getSource().equals(C.getList_compo()))
		{
	
		if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Rectangle)
		{
			pnl_edt_rect.setVisible(true);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_comp.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_liste_mseg.setVisible(false);
			
			Rectangle rect=(Rectangle)C.getC().get(C.getList_compo().getSelectedIndex());
			pnl_edit.getEdt_name().setText((String) C.getList_compo().getSelectedValue());
			pnl_edit.getEdt_origine().setText(String.valueOf(rect.getOrigine().getX()) +"," +rect.getOrigine().getY());
			pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX()) +"," +rect.getPoint().getY());
			btn_ok.requestFocus();
		}
		else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Cercle)
		{
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(true);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_comp.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_liste_mseg.setVisible(false);
			
			Cercle cercle=(Cercle)C.getC().get(C.getList_compo().getSelectedIndex());
			pnl_edit.getEdt_name().setText(((String) C.getList_compo().getSelectedValue()));
			String ch = String.valueOf(cercle.getOrigine().getX()) +"," +cercle.getOrigine().getY();
			pnl_edit.getEdt_origine().setText(ch);
			pnl_edt_cercle.getEdt_rayon_cercle().setText(String.valueOf(cercle.getRayon()));
			btn_ok.requestFocus();
		}
		else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Triangle)
		{
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(true);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_comp.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_liste_mseg.setVisible(false);
			
			Triangle tri=(Triangle)C.getC().get(C.getList_compo().getSelectedIndex());
			pnl_edit.getEdt_name().setText((String) C.getList_compo().getSelectedValue());
			pnl_edit.getEdt_origine().setText(String.valueOf(tri.getOrigine().getX()) +"," +tri.getOrigine().getY());
			pnl_edt_tri.getEdt_point2_tri().setText(String.valueOf(tri.getPoint1().getX()) +"," +tri.getPoint1().getY());
			pnl_edt_tri.getEdt_point3_tri().setText(String.valueOf(tri.getPoint2().getX()) +"," +tri.getPoint2().getY());
			btn_ok.requestFocus();
		}
		else if(C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Segment)
		{
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(true);
			pnl_edt_comp.setVisible(false);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_comp.setVisible(false);
			pnl_liste_mseg.setVisible(false);
			Segment seg=(Segment)C.getC().get(C.getList_compo().getSelectedIndex());
			pnl_edit.getEdt_name().setText((String) C.getList_compo().getSelectedValue());
			pnl_edit.getEdt_origine().setText(String.valueOf(seg.getOrigine().getX()) +"," +seg.getOrigine().getY());
			pnl_edt_seg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX() +"," +seg.getPoint().getY()));
			btn_ok.requestFocus();
		}
		else if(C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Composite)
		{
			pnl_edt_rect.setVisible(false);
			pnl_edt_cercle.setVisible(false);
			pnl_edt_tri.setVisible(false);
			pnl_edt_seg.setVisible(false);
			pnl_edt_comp.setVisible(true);
			pnl_comp_rect.setVisible(false);
			pnl_comp_cercle.setVisible(false);
			pnl_comp_tri.setVisible(false);
			pnl_comp_seg.setVisible(false);
			pnl_edt_mulseg.setVisible(false);
			pnl_mseg.setVisible(false);
			pnl_liste_mseg.setVisible(false);
			
			Composite comp=((((Composite) C.getC().get(C.getList_compo().getSelectedIndex()))));
			
			pnl_comp.removeAll();
			pnl_comp.setVisible(true);
			pnl_comp.add(comp.getScroll_compo());
			pnl_comp.updateUI();
			comp.getList_compo().addListSelectionListener(this);
			pnl_edit.getEdt_name().setText((String) C.getList_compo().getSelectedValue());
			pnl_edit.getEdt_origine().setText(String.valueOf(comp.getOrigine().getX()) +"," +comp.getOrigine().getY());
			btn_ok.requestFocus();
			
		}
		
		else if(C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Multisegment)
	{
		pnl_edt_rect.setVisible(false);
		pnl_edt_cercle.setVisible(false);
		pnl_edt_tri.setVisible(false);
		pnl_edt_seg.setVisible(false);
		pnl_edt_comp.setVisible(false);
		pnl_comp_rect.setVisible(false);
		pnl_comp_cercle.setVisible(false);
		pnl_comp_tri.setVisible(false);
		pnl_comp_seg.setVisible(false);
		pnl_edt_mulseg.setVisible(true);
		pnl_comp.setVisible(false);
		pnl_mseg.setVisible(false);
		
		Multisegment mseg=(Multisegment) C.getC().get(C.getList_compo().getSelectedIndex());

		pnl_liste_mseg.removeAll();
		pnl_liste_mseg.setVisible(true);
		pnl_liste_mseg.add(mseg.getScroll_multiseg());
		pnl_liste_mseg.updateUI();
		
		mseg.getList_multiseg().addListSelectionListener(this);
		mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getFirstVisibleIndex());
		
		pnl_edit.getEdt_name().setText((String) C.getList_compo().getSelectedValue());
		btn_ok.requestFocus();
	}
		
		}
		
		

		


		
		

		if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Composite)
		{
		if(e.getSource().equals((((Composite) C.getC().get(C.getList_compo().getSelectedIndex()))).getList_compo()))
		{	
			Composite comp=((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
			if(comp.getC().get(comp.getList_compo().getSelectedIndex()) instanceof Rectangle)
			{	pnl_comp_cercle.setVisible(false);
				pnl_comp_rect.setVisible(true);
				pnl_comp_tri.setVisible(false);
				pnl_comp_seg.setVisible(false);
				Rectangle rect=(Rectangle) comp.getC().get(comp.getList_compo().getSelectedIndex());
				pnl_comp_rect.getEdt_org_rect().setText(String.valueOf(rect.getOrigine().getX() +"," +rect.getOrigine().getY()));
				pnl_comp_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX() +"," +rect.getPoint().getY()));
				btn_ok.requestFocus();
			}
			else if(comp.getC().get(comp.getList_compo().getSelectedIndex()) instanceof Cercle)
			{	pnl_comp_cercle.setVisible(true);
				pnl_comp_rect.setVisible(false);
				pnl_comp_tri.setVisible(false);
				pnl_comp_seg.setVisible(false);
				Cercle cercle=(Cercle) comp.getC().get(comp.getList_compo().getSelectedIndex());
				pnl_comp_cercle.getEdt_org_cercle().setText(String.valueOf(cercle.getOrigine().getX() +"," +cercle.getOrigine().getY()));
				pnl_comp_cercle.getEdt_rayon_cercle().setText(String.valueOf(cercle.getRayon()));
				btn_ok.requestFocus();
			}
			else if(comp.getC().get(comp.getList_compo().getSelectedIndex()) instanceof Triangle)
			{	pnl_comp_cercle.setVisible(false);
				pnl_comp_rect.setVisible(false);
				pnl_comp_tri.setVisible(true);
				pnl_comp_seg.setVisible(false);
				Triangle tri=(Triangle) comp.getC().get(comp.getList_compo().getSelectedIndex());
				pnl_comp_tri.getEdt_origine_tri().setText(String.valueOf(tri.getOrigine().getX() +"," +tri.getOrigine().getY()));
				pnl_comp_tri.getEdt_point2_tri().setText(String.valueOf(tri.getPoint1().getX() +"," +tri.getPoint1().getY()));
				pnl_comp_tri.getEdt_point3_tri().setText(String.valueOf(tri.getPoint2().getX() +"," +tri.getPoint2().getY()));
				btn_ok.requestFocus();
			}
			else if(comp.getC().get(comp.getList_compo().getSelectedIndex()) instanceof Segment)
			{	pnl_comp_cercle.setVisible(false);
				pnl_comp_rect.setVisible(false);
				pnl_comp_tri.setVisible(false);
				pnl_comp_seg.setVisible(true);
				Segment seg=(Segment) comp.getC().get(comp.getList_compo().getSelectedIndex());
				pnl_comp_seg.getEdt_org_seg().setText(String.valueOf(seg.getOrigine().getX() +"," +seg.getOrigine().getY()));
				pnl_comp_seg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX() +"," +seg.getPoint().getY()));
				btn_ok.requestFocus();
			}
		}
		}
		
		
		else if (C.getC().get(C.getList_compo().getSelectedIndex()) instanceof Multisegment)
		{
		if(e.getSource().equals(((((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex())))).getList_multiseg()))
		{	
			
			Multisegment mseg=((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex()));
			
				pnl_comp_cercle.setVisible(false);
				pnl_comp_rect.setVisible(false);
				pnl_comp_tri.setVisible(false);
				pnl_comp_seg.setVisible(false);
				pnl_mseg.setVisible(true);
				Segment seg=(Segment) mseg.getS().get(mseg.getList_multiseg().getSelectedIndex());
				
				if (mseg.nbcomp()==1  || mseg.getList_multiseg().getSelectedIndex() == 0)
				{
				pnl_mseg.getEdt_org_seg().setText(String.valueOf(seg.getOrigine().getX() +"," +seg.getOrigine().getY()));
				pnl_mseg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX() +"," +seg.getPoint().getY()));
				}
				else if(mseg.nbcomp()>1 &&  mseg.getList_multiseg().getSelectedIndex() > 0)
				{
					Segment pred=(Segment) mseg.getS().get(mseg.getList_multiseg().getSelectedIndex()-1);
					int xpred=pred.getPoint().getX()+pred.getOrigine().getX();
					int ypred=pred.getPoint().getY()+pred.getOrigine().getY();
					pnl_mseg.getEdt_org_seg().setText(String.valueOf(xpred +"," +ypred));
					pnl_mseg.getEdt_point_seg().setText(String.valueOf(seg.getPoint().getX() +"," +seg.getPoint().getY()));
				}
				pnl_mseg.getLbl_org_seg().setVisible(false);
				pnl_mseg.getEdt_org_seg().setVisible(false);
				btn_ok.requestFocus();
		}	
		}
}


	
	public static String[] Nettoyer(String ch) 
	{
		String str[]=ch.trim().split(",");
		return str;
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		 if (e.getKeyChar() == KeyEvent.VK_ENTER)
		 {
			 btn_ok.doClick();
		 }
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getButton() == MouseEvent.BUTTON3)
		{
			
			if (pnl_comp.isVisible())
			{
				Composite comp = ((Composite) C.getC().get(C.getList_compo().getSelectedIndex()));
				if(comp.getList_compo().getSelectedIndex()==comp.getList_compo().getLastVisibleIndex() && comp.getList_compo().getSelectedIndex() != comp.getList_compo().getFirstVisibleIndex())
				{
					comp.supprimer(comp.getC().get(comp.getList_compo().getSelectedIndex()));
					comp.getList_compo().setSelectedIndex(comp.getList_compo().getSelectedIndex()-1);
					comp.getListComposite().remove(comp.getList_compo().getLastVisibleIndex());
				}
				else if(comp.getList_compo().getSelectedIndex()==comp.getList_compo().getFirstVisibleIndex() && comp.getList_compo().getLastVisibleIndex() == comp.getList_compo().getSelectedIndex())
				{	
					JOptionPane.showMessageDialog(this,"Impossible de supprimer cet �l�ment, veuillez en cr�er un nouveau puis le supprimer ensuite.","Erreur : Suppression impossible",JOptionPane.NO_OPTION);
				}
				else
				{
					comp.supprimer(comp.getC().get(comp.getList_compo().getLastVisibleIndex()));
					comp.getListComposite().remove(comp.getList_compo().getLastVisibleIndex());
				}
			}
			else if (pnl_mseg.isVisible())
			{
				Multisegment mseg = ((Multisegment) C.getC().get(C.getList_compo().getSelectedIndex()));
				if(mseg.getList_multiseg().getSelectedIndex()==mseg.getList_multiseg().getLastVisibleIndex() && mseg.getList_multiseg().getSelectedIndex() != mseg.getList_multiseg().getFirstVisibleIndex())
				{
					mseg.supprimer(mseg.getS().get(mseg.getList_multiseg().getSelectedIndex()));
					mseg.getList_multiseg().setSelectedIndex(mseg.getList_multiseg().getSelectedIndex()-1);
					mseg.getListMultiseg().remove(mseg.getList_multiseg().getLastVisibleIndex());
				}
				else if(mseg.getList_multiseg().getSelectedIndex()==mseg.getList_multiseg().getFirstVisibleIndex() && mseg.getList_multiseg().getLastVisibleIndex() == mseg.getList_multiseg().getSelectedIndex())
				{	
					JOptionPane.showMessageDialog(this,"Impossible de supprimer cet �l�ment, veuillez en cr�er un nouveau puis le supprimer ensuite.","Erreur : Suppression impossible",JOptionPane.NO_OPTION);
				}
				else
				{
					mseg.supprimer(mseg.getS().get(mseg.getList_multiseg().getLastVisibleIndex()));
					mseg.getListMultiseg().remove(mseg.getList_multiseg().getLastVisibleIndex());
				}
			}
			else
			{
			if(C.getList_compo().getSelectedIndex()==C.getList_compo().getLastVisibleIndex() && C.getList_compo().getSelectedIndex() != C.getList_compo().getFirstVisibleIndex())
			{
				C.supprimer(C.getC().get(C.getList_compo().getSelectedIndex()));
				C.getList_compo().setSelectedIndex(C.getList_compo().getSelectedIndex()-1);
				C.getListComposite().remove(C.getList_compo().getLastVisibleIndex());
			}
			else if(C.getList_compo().getSelectedIndex()==C.getList_compo().getFirstVisibleIndex() && C.getList_compo().getLastVisibleIndex() == C.getList_compo().getSelectedIndex())
			{	
				JOptionPane.showMessageDialog(this,"Impossible de supprimer cet �l�ment, veuillez en cr�er un nouveau puis le supprimer ensuite.","Erreur : Suppression impossible",JOptionPane.NO_OPTION);
			}
			else
			{
				C.supprimer(C.getC().get(C.getList_compo().getLastVisibleIndex()));
				C.getListComposite().remove(C.getList_compo().getLastVisibleIndex());
			}
			}
			
			this.afficher();
			
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void afficher()
	{
		pnl_draw.update(pnl_draw.getGraphics());
		for (int i = 0; i < C.nbcomp(); i++) {
			if(C.getC().get(i) instanceof Composite)
			{
				for(int j=0; j<((Composite) C.getC().get(i)).nbcomp();j++)
				{
					Composant c = ((Composite) C.getC().get(i)).getC().get(j);
					pnl_draw.afficher(c);
				}
				
			}	
			else if(C.getC().get(i) instanceof Multisegment)
			{
				for(int k=0; k<((Multisegment) C.getC().get(i)).nbcomp();k++)
				{
					Composant c = ((Multisegment) C.getC().get(i)).getS().get(k);
					pnl_draw.afficher(c);
				}
				
			}
			else
			{
				Composant c = C.getC().get(i);
				pnl_draw.afficher(c);
			}
		}
	}


	public boolean verifierInt(String entier) {
        boolean v = false;
        try {
            Integer.parseInt(entier);
            v = true;
        } catch (Exception e) {
            v = false;
        }
        return v;
    }
	
}
