package Panels;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelEdit extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnl_edit = new JPanel();
	private JLabel lbl_name = new JLabel ("Nom : ");
	private JLabel lbl_origine = new JLabel ("Origine : ");
	private JTextField edt_name = new JTextField(15);
	private JTextField edt_origine = new JTextField(15);

	
	public PanelEdit()
	{
		pnl_edit.setPreferredSize(new Dimension(200,91));
		pnl_edit.add(lbl_name);
		pnl_edit.add(edt_name);
		pnl_edit.add(lbl_origine);
		pnl_edit.add(edt_origine);
		this.add(pnl_edit);
	}

	public JPanel getPnl_edit() {
		return pnl_edit;
	}

	public void setPnl_edit(JPanel pnl_edit) {
		this.pnl_edit = pnl_edit;
	}

	public JLabel getLbl_name() {
		return lbl_name;
	}

	public void setLbl_name(JLabel lbl_name) {
		this.lbl_name = lbl_name;
	}

	public JLabel getLbl_origine() {
		return lbl_origine;
	}

	public void setLbl_origine(JLabel lbl_origine) {
		this.lbl_origine = lbl_origine;
	}

	public JTextField getEdt_name() {
		return edt_name;
	}

	public void setEdt_name(JTextField edt_name) {
		this.edt_name = edt_name;
	}

	public JTextField getEdt_origine() {
		return edt_origine;
	}

	public void setEdt_origine(JTextField edt_origine) {
		this.edt_origine = edt_origine;
	}

	
	
}
