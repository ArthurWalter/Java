package Panels;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelSegment extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel pnl_edt_seg = new JPanel();
	private JLabel lbl_point_seg = new JLabel ("Point : ");
	private JTextField edt_point_seg = new JTextField(15);
	public PanelSegment()
	{
		pnl_edt_seg.setPreferredSize(new Dimension(200,75));
		pnl_edt_seg.add(lbl_point_seg);
		pnl_edt_seg.add(edt_point_seg);
		this.add(pnl_edt_seg);	
	}
	public JPanel getPnl_edt_seg() {
		return pnl_edt_seg;
	}
	public void setPnl_edt_seg(JPanel pnl_edt_seg) {
		this.pnl_edt_seg = pnl_edt_seg;
	}
	public JLabel getLbl_point_seg() {
		return lbl_point_seg;
	}
	public void setLbl_point_seg(JLabel lbl_point_seg) {
		this.lbl_point_seg = lbl_point_seg;
	}
	public JTextField getEdt_point_seg() {
		return edt_point_seg;
	}
	public void setEdt_point_seg(JTextField edt_point_seg) {
		this.edt_point_seg = edt_point_seg;
	}
}
