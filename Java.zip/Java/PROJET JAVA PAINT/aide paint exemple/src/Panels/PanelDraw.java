package Panels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

import UML.Cercle;
import UML.Composant;
import UML.Rectangle;
import UML.Segment;
import UML.Triangle;

public class PanelDraw extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnl_draw = new JPanel();
	
	public PanelDraw()
	{
		this.setPreferredSize(new Dimension(0,780));
		this.setBackground(Color.WHITE);
		this.add(pnl_draw,BorderLayout.CENTER);
	}

	public void afficher(Composant c)
	{
		if (c instanceof Rectangle)
		{
			this.getGraphics().setColor(Color.BLACK);
			this.getGraphics().drawRect(c.getOrigine().getX(),c.getOrigine().getY(), ((Rectangle)c).getPoint().getX(),((Rectangle)c).getPoint().getY());
		}
		else if (c instanceof Cercle)
		{
			this.getGraphics().drawOval(c.getOrigine().getX(),c.getOrigine().getY(),((Cercle) c).getRayon(),((Cercle) c).getRayon());
		}
		else if (c instanceof Triangle)
		{
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(), (c.getOrigine().getX()+((Triangle)c).getPoint1().getX()), (c.getOrigine().getY()+((Triangle)c).getPoint1().getY()));
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(), (c.getOrigine().getX()+((Triangle)c).getPoint2().getX()), (c.getOrigine().getY()+((Triangle)c).getPoint2().getY()));
			this.getGraphics().drawLine(((Triangle)c).getPoint2().getX()+c.getOrigine().getX(), ((Triangle)c).getPoint2().getY()+c.getOrigine().getY(),((Triangle)c).getPoint1().getX()+c.getOrigine().getX(),((Triangle)c).getPoint1().getY()+c.getOrigine().getY()) ;
		}
		else if (c instanceof Segment)
		{
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(),c.getOrigine().getX()+((Segment)c).getPoint().getX(),c.getOrigine().getY()+ ((Segment)c).getPoint().getY());
		}
	}		
	
	
	
	
	public void effacer(Composant c)
	{
		if (c instanceof Rectangle)
		{
		this.getGraphics().setColor(Color.WHITE);
		this.getGraphics().drawRect(c.getOrigine().getX(),c.getOrigine().getY(), c.getOrigine().getX()+((Rectangle)c).getPoint().getX(),c.getOrigine().getY()+((Rectangle)c).getPoint().getY());
		}
		else if(c instanceof Cercle)
		{
		this.getGraphics().setColor(Color.WHITE);
		this.getGraphics().drawOval(c.getOrigine().getX(),c.getOrigine().getY(), ((Cercle) c).getRayon(),((Cercle) c).getRayon());
		}
		else if(c instanceof Triangle)
		{
			this.getGraphics().setColor(Color.WHITE);
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(), (c.getOrigine().getX()+((Triangle)c).getPoint1().getX()), (c.getOrigine().getY()+((Triangle)c).getPoint1().getY()));
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(), (c.getOrigine().getX()+((Triangle)c).getPoint2().getX()), (c.getOrigine().getY()+((Triangle)c).getPoint2().getY()));
			this.getGraphics().drawLine(((Triangle)c).getPoint1().getX(), ((Triangle)c).getPoint1().getY(),(c.getOrigine().getX()+((Triangle)c).getPoint2().getX()),(c.getOrigine().getY()+((Triangle)c).getPoint2().getY())) ;
		}
		else if (c instanceof Segment)
		{
			this.getGraphics().setColor(Color.WHITE);
			this.getGraphics().drawLine(c.getOrigine().getX(), c.getOrigine().getY(),((Segment)c).getPoint().getX(), ((Segment)c).getPoint().getY());
		}
	}
	

}