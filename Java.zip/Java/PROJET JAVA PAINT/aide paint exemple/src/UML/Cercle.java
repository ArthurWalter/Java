package UML;
public class Cercle extends Composant {
        private int rayon;
        
        
        public Cercle() {
                origine = new Point2D(0,0);
                rayon=50;
        }

        public Cercle (Point2D origine) {
                super(origine);
                rayon=5;
        }
        
        
        public Cercle (Point2D origine,int v1) {
                super(origine);
                rayon=v1;
        }
        
        public Cercle (Cercle c) {
                super(c);
                this.rayon = c.rayon;
        }
        
         public int getRayon() {
                return rayon;
        }

        public void setRayon(int v1) {
                this.rayon = v1;
        }
        
        public String afficher () {
        	return super.afficher() +"Cercle [rayon=" +rayon + "]"; 
        }
        
        

}
