package UML;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


public class Multisegment extends Composant{


	private ArrayList<Segment> S;
	private JPanel pnl_liste_mseg = new JPanel();
	private DefaultListModel ListMultiseg = new DefaultListModel();
	private JList list_multiseg = new JList(ListMultiseg);
	private JScrollPane scroll_multiseg =new JScrollPane(list_multiseg);
	
	
	public Multisegment () {
		origine = new Point2D(0,0);
		S=new ArrayList<Segment>();
		scroll_multiseg.setPreferredSize(new Dimension(250,120));
		list_multiseg.setPreferredSize(new Dimension(220,5000));
		
	}
	
	

	public Multisegment (Point2D origine) {
		super(origine);
		S=new ArrayList<Segment>();
		scroll_multiseg.setPreferredSize(new Dimension(250,120));
		list_multiseg.setPreferredSize(new Dimension(220,5000));
		pnl_liste_mseg.add(scroll_multiseg);
	}
	
	public Multisegment (Multisegment M) {
		this.origine=M.origine;
		this.S=M.S;
		scroll_multiseg.setPreferredSize(new Dimension(250,120));
		list_multiseg.setPreferredSize(new Dimension(220,5000));
		pnl_liste_mseg.add(scroll_multiseg);
		
	}
	
	public ArrayList<Segment> getS() {
		return S;
	}

	public void setS(ArrayList<Segment> s) {
		S = s;
	}
	
	public JPanel getPnl_liste_mseg() {
		return pnl_liste_mseg;
	}

	public void setPnl_liste_mseg(JPanel pnl_liste_mseg) {
		this.pnl_liste_mseg = pnl_liste_mseg;
	}

	public DefaultListModel getListMultiseg() {
		return ListMultiseg;
	}

	public void setListMultiseg(DefaultListModel listMultiseg) {
		ListMultiseg = listMultiseg;
	}

	public JList getList_multiseg() {
		return list_multiseg;
	}

	public void setList_multiseg(JList list_multiseg) {
		this.list_multiseg = list_multiseg;
	}

	public JScrollPane getScroll_multiseg() {
		return scroll_multiseg;
	}

	public void setScroll_multiseg(JScrollPane scroll_multiseg) {
		this.scroll_multiseg = scroll_multiseg;
	}

	public String toString() {
		return super.toString() +"Multisegment [S=" + S + "]";
	}
	
	public void ajouter (Segment seg) {
		S.add(seg);
	}
	
	public void supprimer (Segment seg) {
		S.remove(seg);
	}
	
	public int nbcomp () {
		return this.getS().size();
	}
	
}
