package UML;

public class Segment extends Composant {
	 private Point2D point;
	
	 public Segment() 
	 {
         origine = new Point2D(0,0);
         point = new Point2D(50,50); 
	 }
	 
     public Segment (Point2D origine) 
     {
         super(origine); 
         point = new Point2D(50,50);
     }
         
     public Segment (Point2D origine, Point2D x)
     {
         super(origine);
         point=x;    
     }
     
     public Segment (Segment S) 
     {
	     super(S);
	     this.point=S.point;
     }

	public Point2D getPoint() {
		return point;
	}

	public void setPoint(Point2D point) {
		this.point = point;
	}
     
     public String afficher(){
    	 return super.afficher() +"Segment [point=" + point.toString() + "]";
     }

}
