package UML;

public class Triangle extends Composant {
        private Point2D point1;
        private Point2D point2;
        
        
        public Triangle () {
               point1 = new Point2D(50,0);
               point2 = new Point2D(0,50);   
        }
        
        public Triangle (Point2D org) {
               origine = org;
               point1 = new Point2D(50,0);
               point2 = new Point2D(0,50);
        }
        
        public Triangle (Point2D origine, Point2D x, Point2D y) {
            super(origine);
            point1=x;
            point2=y;
        }
        
        public Triangle (Triangle t) {
                super(t);
                this.point1=t.point1;
                this.point2=t.point2;     
        }
        
        public Point2D getPoint1() {
        	return point1;
        }
        
        
        public void setPoint1(Point2D point1) {
            this.point1 = point1;
        }
        
        public Point2D getPoint2() {
        	return point2;
        }
        
        public void setPoint2(Point2D point2) {
        	this.point2 = point2;
        }
        
        
        public String afficher () {
        	return super.afficher() +"Triangle [point1=" + point1.toString() + "]" +"[point2=" +point2.toString() +"]";
        }
}
