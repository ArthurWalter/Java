package UML;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


public class Composite extends Composant {
	
	private ArrayList <Composant> C;
	private JPanel pnl_liste_compo = new JPanel();
	private DefaultListModel ListComposite = new DefaultListModel();
	private JList list_compo = new JList(ListComposite);
	private JScrollPane scroll_compo =new JScrollPane(list_compo);
	
	
	public Composite () {
		origine=new Point2D(0,0);
		C = new ArrayList<Composant>();
		scroll_compo.setPreferredSize(new Dimension(250,156));
		list_compo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_compo.add(scroll_compo);
	}
	
	public Composite (Point2D origine) {
		super(origine);
		C = new ArrayList<Composant>();
		scroll_compo.setPreferredSize(new Dimension(250,120));
		list_compo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_compo.add(scroll_compo);
	}
	
	public Composite (Composite v) {
		super(v);
		this.C=v.C;
		scroll_compo.setPreferredSize(new Dimension(250,120));
		list_compo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_compo.add(scroll_compo);
	}

	public JPanel getPnl_liste_compo() {
		return pnl_liste_compo;
	}

	public void setPnl_liste_compo(JPanel pnl_liste_compo) {
		this.pnl_liste_compo = pnl_liste_compo;
	}

	public DefaultListModel getListComposite() {
		return ListComposite;
	}

	public void setListComposite(DefaultListModel listComposite) {
		ListComposite = listComposite;
	}

	public JList getList_compo() {
		return list_compo;
	}

	public void setList_compo(JList list_compo) {
		this.list_compo = list_compo;
	}

	public JScrollPane getScroll_compo() {
		return scroll_compo;
	}

	public void setScroll_compo(JScrollPane scroll_compo) {
		this.scroll_compo = scroll_compo;
	}

	public ArrayList<Composant> getC() {
		return C;
	}

	public void setC(ArrayList<Composant> c) {
		C = c;
	}
	
	
	public void ajouter (Composant v) {
		C.add(v);
	}
	
	public void supprimer (Composant v) {
		C.remove(v);
	}
	
	public int nbcomp () {
		return this.getC().size();
	}
	
}
