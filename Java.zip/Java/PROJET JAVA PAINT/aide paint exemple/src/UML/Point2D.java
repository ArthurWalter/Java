package UML;

public class Point2D {
        
        protected int x;
        protected int y;
        
        public Point2D () {
                x=0;
                y=0;
        }
        
		public Point2D (int v) {
				x=v;
				y=0;
        } 
		
		public Point2D (int v1,int v2) {
                x=v1;
                y=v2;      
        }
		
	    public Point2D (Point2D p) {
                x=p.getX();
                y=p.getY();
        }
	    
	    public int getX() {
                return x;
        }

        public void setX(int x) {
                this.x = x;
        }

        public int getY() {
                return y;
        }

        public void setY(int y) {
                this.y = y;
        }
        
        @Override
		public String toString() {
			return "Point2D [x=" + x + ", y=" + y + "]";
		}


        
       
        



        
        
}

