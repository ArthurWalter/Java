package UML;

public class Composant{
        protected Point2D origine;
        
        
		public Composant() {
        	origine = new Point2D(0,0);
        }
        
        public Composant (Point2D x) {
        	origine=x;
        }

        public Composant (Composant c) {
            this.origine=c.origine;
        }


        public Point2D getOrigine() {
            return origine;
        }

        public void setOrigine(Point2D v) {
            this.origine = v;
        }

		public String afficher() {
			return "Composant [origine=" + origine.getX() +"," +origine.getY() +"]";
		}

}
