package UML;


public class Rectangle extends Composant {
        private Point2D point;
        
        public Rectangle() {
                origine = new Point2D(0,0);
                point = new Point2D(50,50); 
        }
        
        public Rectangle (Point2D origine) {
                super(origine); 
                point = new Point2D(50,50);
        }
                
        public Rectangle (Point2D origine, Point2D x) {
                super(origine);
                point=x;    
        }
        
        public Rectangle (Rectangle r) {
                super(r);
                this.point=r.point;
        }
        
        
        public Point2D getPoint() {
                return point;
        }

        public void setPoint(Point2D x) {
                this.point = x;
        }
        
		
		public String afficher() {
			return super.afficher() +"Rectangle [point=" + point.toString() + "]";
		}      
}
