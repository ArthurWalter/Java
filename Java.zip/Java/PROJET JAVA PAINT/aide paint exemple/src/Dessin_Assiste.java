import Panels.Cadre;



public class Dessin_Assiste {
	public static void main( String [] arg){

	Cadre m =new Cadre("Dessin Assist�");
	m.setVisible(true);
	}
}