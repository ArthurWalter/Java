package Panels;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelCercle extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JPanel pnl_edt_cercle = new JPanel();
	private JLabel lbl_rayon_cercle = new JLabel ("Rayon : ");
	private JTextField edt_rayon_cercle = new JTextField(15);
	

	public PanelCercle()
	{
		pnl_edt_cercle.setPreferredSize(new Dimension(200,75));
		pnl_edt_cercle.add(lbl_rayon_cercle);
		pnl_edt_cercle.add(edt_rayon_cercle);
		this.add(pnl_edt_cercle);
		
	}


	public JPanel getPnl_edt_cercle() {
		return pnl_edt_cercle;
	}


	public void setPnl_edt_cercle(JPanel pnl_edt_cercle) {
		this.pnl_edt_cercle = pnl_edt_cercle;
	}


	public JLabel getLbl_rayon_cercle() {
		return lbl_rayon_cercle;
	}


	public void setLbl_rayon_cercle(JLabel lbl_rayon_cercle) {
		this.lbl_rayon_cercle = lbl_rayon_cercle;
	}


	public JTextField getEdt_rayon_cercle() {
		return edt_rayon_cercle;
	}


	public void setEdt_rayon_cercle(JTextField edt_rayon_cercle) {
		this.edt_rayon_cercle = edt_rayon_cercle;
	}


}
