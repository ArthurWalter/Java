package Panels;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelRect extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private JPanel pnl_edt_rect = new JPanel();
	private JLabel lbl_point_rect = new JLabel ("Point : ");
	private JTextField edt_point_rect = new JTextField(15);
	public PanelRect()
	{
		pnl_edt_rect.setPreferredSize(new Dimension(200,75));
		pnl_edt_rect.add(lbl_point_rect);
		pnl_edt_rect.add(edt_point_rect);
		this.add(pnl_edt_rect);
	}

	public JPanel getPnl_edt_rect() {
		return pnl_edt_rect;
	}

	public JLabel getLbl_point_rect() {
		return lbl_point_rect;
	}

	public void setLbl_point_rect(JLabel lbl_point_rect) {
		this.lbl_point_rect = lbl_point_rect;
	}

	public JTextField getEdt_point_rect() {
		return edt_point_rect;
	}

	public void setEdt_point_rect(JTextField edt_point_rect) {
		this.edt_point_rect = edt_point_rect;
	}

	public void setPnl_edt_rect(JPanel pnl_edt_rect) {
		this.pnl_edt_rect = pnl_edt_rect;
	}
	
}
