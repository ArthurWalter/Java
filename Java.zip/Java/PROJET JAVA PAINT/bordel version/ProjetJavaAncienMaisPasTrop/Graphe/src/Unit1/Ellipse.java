package Unit1;
import javax.swing.JFrame;

public class Ellipse extends ObjetDeBase{
	private Point2D pointref2;
	private int rayonlong;
    private int rayoncourt;
    
	public Ellipse(){
		JFrame f1=new JFrame("Ellipse");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		
	}	
	public Ellipse(Point2D pointref,Point2D pointref2){
		super(pointref);
		this.pointref2 = pointref2;
		rayonlong=4;
		rayoncourt=4;			// on donne une valeur fixe de base au cercle, il sera possible de la modifier
	}						    // avec les autres m�thodes
	
	public Ellipse(Point2D pointref,Point2D pointref2,int r1, int r2){
			super(pointref);
			this.pointref2 = pointref2;
			this.rayonlong=r1;
			this.rayoncourt=r2;
	}
	
	public Ellipse(Ellipse e){
			super(e.pointref);
			this.pointref2=e.pointref2;
			this.rayonlong =e.rayonlong;
			this.rayoncourt = e.rayoncourt;
	}
	
	 public int getRayonlong(){
			return rayonlong;
	}
	
	 public int getRayoncourt(){
			return rayoncourt;
	}
	
	public void setRayonlong(int r){
			this.rayonlong = r;
	}
	public void setRayoncourt(int r){
			this.rayoncourt = r;
	}
	
	public String afficher(){
		return super.afficher() +"Cercle [ premier rayon=" +rayonlong +"deuxieme rayon=" +rayoncourt + "]"; 
	}
}
