package Unit1;
import Unit2.*;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
import java.awt.Graphics;
import java.lang.Object;

public class Test {

	public static void main(String[] args) {
		Accueil a=new Accueil();
		//ObjetDeBase odb=new ObjetDeBase();
		//Rectangle r=new Rectangle();
		
		/*Point2D p1 = new Point2D(90,90);
		Rectangle r=new Rectangle(p1);
		PanelDraw pd=new PanelDraw();
		pd.afficher(r);
		*/
	}
	

}



