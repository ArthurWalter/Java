package Unit1;

import javax.swing.*;
import java.awt.*;

public class RectangleDraw extends JPanel{
	private int width;
	private int height;
	private int x;
	private int y;
	
/*	public RectangleDraw(Rectangle r) {
		//f1.setContentPane(this);
		x=r.pointref.getX();
		y=r.pointref.getY();
		width=r.getPoint2().getX()-r.getPoint2().getX();
		height=r.getPoint2().getY()-r.pointref.getY();
		
		//this.getGraphics().drawRect(r.pointref.getX(),r.pointref.getY(), width, height);
	}
*/
	public void paint(Graphics g) {
		
		Graphics2D g2= (Graphics2D) g;
		g2.drawRect(10,10, 100, 100);
		//this.getGraphics().drawRect(1, 1, 100, 100);
		//this.setBackground(Color.BLACK);
	}

	
	
}
