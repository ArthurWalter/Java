package Unit1;
import javax.swing.JFrame;

public class Quadrilatere extends ObjetDeBase{
	private Point2D point2;
    private Point2D point3;
    private Point2D point4;
	
	public Quadrilatere(){
		JFrame f1=new JFrame("Quadrilatere");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		pointref = new Point2D(0,0);
		point2 = new Point2D(40,40); 
		point3 = new Point2D(60,60); 
		point4 = new Point2D(80,80); 
		
	}	
	public Quadrilatere(Point2D pointref){
		super(pointref); 				// on donne une valeur fixe de base au Quadrilatere, il sera possible de la modifier
		point2 = new Point2D(40,40); 
		point3 = new Point2D(60,60); 
		point4 = new Point2D(80,80); 	// avec les autres m��thodes	
	}
			
	public Quadrilatere (Point2D pointref, Point2D p1,Point2D p2,Point2D p3){
			super(pointref);
			point2=p1;    
			point3=p2;    
			point4=p3;    
	}
	
	public Quadrilatere (Quadrilatere q){
			super(q.pointref);
			this.point2=q.point2;
			this.point3=q.point3;
			this.point4=q.point4;
	}
	
	// getPoint	
	public Point2D getPoint2(){
			return point2;
	}
	public Point2D getPoint3(){
			return point3;
	}
	public Point2D getPoint4(){
		return point4;
	}
	public void setPoint2(Point2D p2){
			this.point2 =p2;
	}
	public void setPoint3(Point2D p3){
			this.point3=p3;
	}
	public void setPoint4(Point2D p4){
		this.point4 =p4;
	}
	public String afficher(){
		return super.afficher()+"Quadrilatere [ point1=" + point2.toString() +point2+" + point3.toString() +point3=" +
		point4.toString() + "]";
	} 
}
