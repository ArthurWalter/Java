package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Graphics;


public class Rectangle extends ObjetDeBase implements MouseListener {
//les attributs	
	private Point2D point2;
	private JFrame f1=new JFrame("Rectangle");
	private JTextField tf1=new JTextField("");//je sais pas pourquoi, mais il faut 
	private JTextField tf2=new JTextField("");//阾re instanci� comme les variables
	private JButton b1=new JButton("Retourner"); //globales, sinon 鏰 va planter
	private JButton b2=new JButton("Afficher");
//constructeur 	
	public Rectangle(){					 	
//config frame
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		//f1.setContentPane(new RectangleDraw());
//config panel de font qui contient panels haut, milieu et bas	
		JPanel p1=new JPanel();		//p1:panel des font
		JPanel p2=new JPanel();		//p2:panel haut
		JPanel p3=new JPanel(); 	//p3:panel milieu
		JPanel p4=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1); 
		f1.add(p1);						  	
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
//config panel haut
		//config label
		JLabel l1=new JLabel("Rectangle");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p2.setLayout(bl1);
		p2.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p31=new JPanel();
		JPanel p32=new JPanel();
		GridLayout gl2=new GridLayout(2,1);
		p3.setLayout(gl2);
		p3.add(p31);
		p3.add(p32);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p31.add(l2);
		//config panel milieu 2
		GridLayout gl3=new GridLayout(2,2);
		p32.setLayout(gl3);
		JLabel l21=new JLabel("Les coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Les coordonnées du point référentiel 2: ");
		p32.add(l21);
		p32.add(tf1);
		p32.add(l22);
		p32.add(tf2);
//config panel bas
		p4.add(b1);
		p4.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
		
	}
//constructeur
	public Rectangle(Point2D pointref){
		super(pointref); 				// on donne une valeur fixe de base au rectangle, il sera possible de la modifier
		Point2D point2 = new Point2D(40,40);	// avec les autres méthodes	
	}
//les fonctions
	public Point2D getPoint2(){
		return point2;
	}
	public void setPoint2(Point2D p){
		this.point2 =p;
	}
	public String afficher(){
	return super.afficher()+"Rectangle [point=" + point2.toString() + "]";
	}   
//les fonctions de l'interface MouseListener		
		public void mouseClicked(MouseEvent e){
			if (e.getSource()==b1) 
			{	
				f1.dispose();
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				ObjetDeBase odb=new ObjetDeBase();
				}
			else if (e.getSource()==b2) 
			{	String str1;	String str2;
				String[] firstArray=tf1.getText().split("\\;",2);				//);//;			
				str1=firstArray[0];
				str2=firstArray[1];
				this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
				String[] secondArray=tf1.getText().split("\\;",2);				//);//;			
				str1=firstArray[0];
				str2=firstArray[1];
				this.point2=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
				Fenetre f=new Fenetre();
				//RectangleDraw rd=new RectangleDraw(this);
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		}
		public void mousePressed(MouseEvent ev)
		{
			
		}
		public void mouseReleased(MouseEvent ev)
		{
			
		}
		public void mouseEntered(MouseEvent ev)
		{
			
		}
		public void mouseExited(MouseEvent ev)
		{
			
		}

	
}
