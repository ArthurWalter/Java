package Unit1;
import javax.swing.JFrame;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
import java.awt.Dimension;

public class ObjetComposite {
	public ArrayList <ObjetDeBase> Comp;
	private JPanel pnl_liste_objcompo = new JPanel();
	private DefaultListModel ListObjComposite = new DefaultListModel();
	private JList list_objcompo = new JList(ListObjComposite);
	private JScrollPane scroll_objcompo =new JScrollPane(list_objcompo);
}
	/*public ObjetComposite(){
		JFrame f1=new JFrame("Objet composite");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		
	
		Point2D pointref=new Point2D(0,0);
		Comp = new ArrayList<ObjetDeBase>();
		scroll_objcompo.setPreferredSize(new Dimension(250,156));
		list_objcompo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_objcompo.add(scroll_objcompo);
	}
	
	public ObjetComposite (Point2D pointref) {
		super(pointref);
		Comp = new ArrayList<ObjetDeBase>();
		scroll_objcompo.setPreferredSize(new Dimension(250,120));
		list_objcompo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_compo.add(scroll_objcompo);
	}
	
	public ObjetComposite(ObjetComposite obj){
		super(obj);
		this.Comp=obj.Comp;
		scroll_objcompo.setPreferredSize(new Dimension(250,120));
		list_compo.setPreferredSize(new Dimension(220,5000));
		pnl_liste_objcompo.add(scroll_objcompo);
	}

	public JPanel getPnl_liste_objcompo() {
		return pnl_liste_objcompo;
	}

	public void setPnl_liste_objcompo(JPanel pnl_liste_objcompo) {
		this.pnl_liste_objcompo = pnl_liste_objcompo;
	}

	public DefaultListModel getList_objCompo() {
		return list_objcompo;
	}

	public void setListObjComposite(DefaultListModel listComposite) {
		list_objcompo = listComposite;
	}

	public JList getList_objcompo() {
		return list_objcompo;
	}

	public void setList_objcompo(JList list_objcompo) {
		this.list_objcompo = list_objcompo;
	}

	public JScrollPane getScroll_objompo() {
		return scroll_objcompo;
	}

	public void setScroll_objcompo(JScrollPane scroll_objcompo) {
		this.scroll_objcompo = scroll_objcompo;
	}

	public ArrayList<ObjetDeBase> getComp() {
		return Comp;
	}

	public void setComp(ArrayList<ObjetDeBase> o) {
		Comp = o;
	}
	
	
	public void ajouter (ObjetDeBase o) {
		Comp.add(o);
	}
	
	public void supprimer (ObjetDeBase o) {
		Comp.remove(o);
	}
	
	public int nbcomp(){
		return this.getComp().size();
	}
}*/
