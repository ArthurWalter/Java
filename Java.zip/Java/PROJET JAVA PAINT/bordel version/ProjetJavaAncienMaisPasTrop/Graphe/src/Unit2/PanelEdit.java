package Unit2;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelEdit extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JPanel pnl_edt = new JPanel();
	private JLabel lbl_nomobj = new JLabel ("Nom : ");
	private JLabel lbl_pointref = new JLabel ("Origine : ");
	private JTextField edt_nomobj = new JTextField(15);
	private JTextField edt_pointref = new JTextField(15);

	public PanelEdit(){
		pnl_edt.setPreferredSize(new Dimension(200,91));
		pnl_edt.add(lbl_nomobj);
		pnl_edt.add(edt_nomobj);
		pnl_edt.add(lbl_pointref);
		pnl_edt.add(edt_pointref);
		this.add(pnl_edt);
	}


	public JPanel getPnl_edt() {
		return pnl_edt;
	}


	public void setPnl_edt(JPanel pnl_edt) {
		this.pnl_edt = pnl_edt;
	}


	public JLabel getLbl_nomobj() {
		return lbl_nomobj;
	}


	public void setLbl_nomobj(JLabel lbl_nomobj) {
		this.lbl_nomobj = lbl_nomobj;
	}


	public JLabel getLbl_pointref() {
		return lbl_pointref;
	}


	public void setLbl_pointref(JLabel lbl_pointref) {
		this.lbl_pointref = lbl_pointref;
	}


	public JTextField getEdt_nomobj() {
		return edt_nomobj;
	}


	public void setEdt_nomobj(JTextField edt_nomobj) {
		this.edt_nomobj = edt_nomobj;
	}


	public JTextField getEdt_pointref() {
		return edt_pointref;
	}


	public void setEdt_pointref(JTextField edt_pointref) {
		this.edt_pointref = edt_pointref;
	}
	
}
