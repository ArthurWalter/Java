package Unit2;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Unit1.*;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;



public class PanelDraw extends JPanel {	
	//private static final long serialVersionUID = 1L;
	private JFrame f1=new JFrame("Affichage Rectangle");
	private JPanel pnl_draw = new JPanel();
	
	public PanelDraw()
		{	
			f1.setVisible(true);
			f1.setSize(800,600);
			f1.setLocation(500,100);
		//config panel de font qui contient panels haut, milieu et bas	
			JPanel p1=new JPanel();		//p1:panel des font
			f1.setContentPane(p1);
			this.setPreferredSize(new Dimension(0,780));
			this.setBackground(Color.WHITE);
			this.add(pnl_draw,BorderLayout.CENTER);	
		}

	public void afficher(ObjetDeBase o)//cr��er un objet 
	{
		if (o instanceof Rectangle)
	{
		this.getGraphics().setColor(Color.BLACK);
		this.getGraphics().drawRect(o.getpointref().getX(),o.getpointref().getY(), ((Rectangle)o).getPoint2().getX(),((Rectangle)o).getPoint2().getY());
	}
	else if (o instanceof Cercle)
	{
		this.getGraphics().setColor(Color.BLACK);
		this.getGraphics().drawOval(o.getpointref().getX(),o.getpointref().getY(),((Cercle) o).getRayon(),((Cercle) o).getRayon());
	}
	else if (o instanceof Vecteur2D)
	{
		this.getGraphics().setColor(Color.BLACK);
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(),o.getpointref().getX()+((Vecteur2D)o).getPoint().getX(),o.getpointref().getY()+ ((Vecteur2D)o).getPoint().getY());
	}
	else if (o instanceof Quadrilatere)
	{
		this.getGraphics().setColor(Color.BLACK);
		this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint2().getY(),(((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getX()), (((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getY()));
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint3().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint3().getY()));
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint2().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint2().getY()));
		this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint3().getY(),(((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint3().getX()), (((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint4().getY()));
		//1) du point 2 au point 4
		//2) du point 2 au pointref
		//3) du point 3 au pointref
		//4) du point 3 au point 4
	}
	else if(o instanceof Ellipse){
		this.getGraphics().setColor(Color.BLACK);
		this.getGraphics().drawOval( ( (o.getpointref().getX() + o.getpointref().getX()) /2),( (o.getpointref().getY() + o.getpointref().getY()) /2),((Ellipse)o).getRayonlong(),((Ellipse)o).getRayoncourt());
											
	}
}		


public void effacer(ObjetDeBase o)
{
	if (o instanceof Rectangle)
	{
	this.getGraphics().setColor(Color.WHITE);
	this.getGraphics().drawRect(o.getpointref().getX(),o.getpointref().getY(), o.getpointref().getX()+((Rectangle)o).getPoint2().getX(),o.getpointref().getY()+((Rectangle)o).getPoint2().getY());
	}
	else if(o instanceof Cercle)
	{
	this.getGraphics().setColor(Color.WHITE);
	this.getGraphics().drawOval(o.getpointref().getX(),o.getpointref().getY(), ((Cercle) o).getRayon(),((Cercle) o).getRayon());
	}
	else if (o instanceof Vecteur2D)
	{
		this.getGraphics().setColor(Color.WHITE);
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(),((Vecteur2D)o).getPoint().getX(), ((Vecteur2D)o).getPoint().getY());
	}
	else if (o instanceof Quadrilatere)
	{
		this.getGraphics().setColor(Color.WHITE);
		this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint2().getY(),(((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getX()), (((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getY()));
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint3().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint3().getY()));
		this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint2().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint2().getY()));
		this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint3().getY(),(((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint3().getX()), (((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint4().getY()));
		//1) du point 2 au point 4
		//2) du point 2 au pointref
		//3) du point 3 au pointref
		//4) du point 3 au point 4
	}
	else if(o instanceof Ellipse){
		this.getGraphics().setColor(Color.WHITE);
		this.getGraphics().drawOval( ( (o.getpointref().getX() + o.getpointref().getX()) /2),( (o.getpointref().getY() + o.getpointref().getY()) /2),((Ellipse)o).getRayonlong(),((Ellipse)o).getRayoncourt());
											
	}
}



/*public void afficher(){   //cr��er un objet dans un panel
	
	pnl_draw.update(pnl_draw.getGraphics());
// il faut une arraylist qui doit contenir des objets 
// pour pouvoir utiliser la fonction
//(exemple : dans objetcomposite, multirectangle,...

	for (int i = 0; i < Comp.nbcomp(); i++){ 
		if(Comp.getComp().get(i) instanceof ObjetComposite)
		{
			for(int j=0; j<((Composite) Comp.getComp().get(i)).nbcomp();j++)
			{
			ObjetDeBase o = ((Composite) Comp.getComp().get(i)).getComp().get(j);
			pnl_draw.afficher(o);
			}
		}
	else if(Comp.getComp().get(i) instanceof MultiRectangle)
		{
			for(int k=0; k<((MultiRectangle) Comp.getComp().get(i)).nbcomp();k++)
			{
			ObjetDeBase o = ((MultiRectangle) Comp.getComp().get(i)).getMr().get(k);
			pnl_draw.afficher(o);
			}
		}
	
	else if(Comp.getComp().get(i) instanceof MultiCercle)
		{
			for(int k=0; k<((MultiCercle) Comp.getComp().get(i)).nbcomp();k++)
			{
			ObjetDeBase o = ((MultiCercle) Comp.getComp().get(i)).getC().get(k);
			pnl_draw.afficher(o);
			}
		}
	
	else if(Comp.getComp().get(i) instanceof MultiEllipse)
		{
			for(int k=0; k<((MultiEllipse) Comp.getComp().get(i)).nbcomp();k++)
		{
			ObjetDeBase o = ((MultiEllipse) Comp.getComp().get(i)).getE().get(k);
			pnl_draw.afficher(o);
		}
		}

	else
	{
		ObjetDeBase o = Comp.getComp().get(i);
		pnl_draw.afficher(o);
	}*/



// fonction  pour split : 
		public static String[] Nettoyer(String ch){
			String str[]=ch.trim().split(";");
			return str;
		}
		
	
}

