package Unit1;
import javax.swing.JFrame;

public class Cercle extends ObjetDeBase {
	private int rayon;
	public Cercle(){
		JFrame f1=new JFrame("Cercle");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		
	}	
}
/*

public class Cercle extends ObjetDeBase {
        private int rayon;
        
			public Cercle() {
					pointref = new Point2D(0,0);
					rayon=40;
			}

			public Cercle (Point2D pointref) {
					super(pointref);
					rayon=4;			// on donne une valeur fixe de base au cercle, il sera possible de la modifier
			}						    // avec les autres m�thodes
			
			public Cercle (Point2D pointref,int r) {
					super(pointref);
					rayon=r;
			}
			
			public Cercle (Cercle c) {
					super(c);
					this.rayon = c.rayon;
			}
			
			 public int getRayon() {
					return rayon;
			}

			public void setRayon(int r) {
					this.rayon = r;
			}
			
			public String afficher () {
				return super.afficher() +"Cercle [rayon=" +rayon + "]"; 
			}
	}
*/