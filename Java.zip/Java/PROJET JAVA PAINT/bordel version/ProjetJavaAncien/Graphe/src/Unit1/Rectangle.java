package Unit1;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javafx.scene.layout.Border;

import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;

public class Rectangle {
	
	public Rectangle(){
//config frame
		JFrame f1=new JFrame("Rectangle");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
//config panel de font qui contient panels haut, milieu et bas	
		JPanel p1=new JPanel();		//p1:panel des font
		JPanel p2=new JPanel();		//p2:panel haut
		JPanel p3=new JPanel(); 	//p3:panel milieu
		JPanel p4=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1); 
		f1.add(p1);						  	
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
//config panel haut
		//config label
		JLabel l1=new JLabel("Rectangle");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p2.setLayout(bl1);
		p2.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		BorderLayout bl2=new BorderLayout();
		p3.setLayout(bl2);
		JLabel l2=new JLabel("Entrer les coordonn�es du point r�f�rentiel: ");
		p3.add(l2);
		l2.setHorizontalAlignment(JLabel.LEFT);
		l2.setVerticalAlignment(JLabel.TOP);
		//JTextField tf1=new JTextField("111");
		//p3.add(tf1,BorderLayout.CENTER);
		
	}	
}
