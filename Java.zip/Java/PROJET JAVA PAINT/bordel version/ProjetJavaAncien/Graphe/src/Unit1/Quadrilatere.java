package Unit1;
import javax.swing.JFrame;

public class Quadrilatere {
	
	public Quadrilatere(){
		JFrame f1=new JFrame("Quadrilatere");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		
	}	
}
