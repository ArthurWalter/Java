package Unit1;
import javax.swing.JFrame;

public class Ellipse {
	
	public Ellipse(){
		JFrame f1=new JFrame("Ellipse");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		
	}	
}
