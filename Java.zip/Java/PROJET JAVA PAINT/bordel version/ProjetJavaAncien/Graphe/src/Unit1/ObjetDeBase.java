package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;

public class ObjetDeBase implements MouseListener{
	JButton b1=new JButton("Rectangle");
	JButton b2=new JButton("Cercle");
	JButton b3=new JButton("Ellipse");
	JButton b4=new JButton("Quadrilatere");
	public ObjetDeBase(){
	//configuration frame
		JFrame f1=new JFrame("Objet de base");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(400,200);
		
	//config panel de font qui contient panels haut, milieu et bas
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		f1.add(p1);
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1);
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
	//config panel haut et label
		JLabel l1=new JLabel("Quel type de l'objet de base voulez-vous cr�er?");
		p2.add(l1);
	//config panel milieu
		//config oridlayout pour mettre les 4 boutons
		GridLayout gl2=new GridLayout(1,4);
		p3.setLayout(gl2);
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
		b3.addMouseListener(this);
		b4.addMouseListener(this);
	}	
	
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	Rectangle r=new Rectangle();	}
		else if (e.getSource()==b2) 
		{	Cercle c=new Cercle();	}
		else if (e.getSource()==b3) 
		{	Ellipse el=new Ellipse();	}
		else if (e.getSource()==b4) 
		{	Quadrilatere q=new Quadrilatere();	}
			
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
