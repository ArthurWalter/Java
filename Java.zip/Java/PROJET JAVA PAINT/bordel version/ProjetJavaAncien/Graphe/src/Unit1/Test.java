package Unit1;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;

public class Test {

	public static void main(String[] args) {
		//Accueil a=new Accueil();
		Rectangle r=new Rectangle();
		//brouillon b=new brouillon();
		
		
		

	}

}



