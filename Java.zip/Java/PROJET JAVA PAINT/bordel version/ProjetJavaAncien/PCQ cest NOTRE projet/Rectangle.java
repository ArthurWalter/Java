package PROJET;

public class Rectangle extends ObjetDeBase {
        private Point2D point2;
        
			public Rectangle(){
					pointref = new Point2D(0,0);
					point2 = new Point2D(40,40); 
			}
			
			public Rectangle(Point2D pointref){
					super(pointref); 				// on donne une valeur fixe de base au rectangle, il sera possible de la modifier
					point2 = new Point2D(40,40);	// avec les autres méthodes	
			}
					
			public Rectangle (Point2D pointref, Point2D p){
					super(pointref);
					point2=p;    
			}
			
			public Rectangle (Rectangle r){
					super(r);
					this.point2=r.point2;
			}
			
			
			public Point2D getPoint(){
					return point2;
			}

			public void setPoint(Point2D p){
					this.point2 =p;
			}
			
			public String afficher(){
				return super.afficher()+"Rectangle [point=" + point2.toString() + "]";
			}      
	}
