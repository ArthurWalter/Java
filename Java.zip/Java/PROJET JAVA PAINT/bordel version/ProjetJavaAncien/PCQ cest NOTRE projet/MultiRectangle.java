package PROJET;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MultiRectangle extends ObjetDeBase{

	private ArrayList<Rectangle> R;
	private JPanel pnl_liste_mrec = new JPanel(); 
	private DefaultListModel ListMultirec = new DefaultListModel(); //Multiseg = Multirec
	private JList list_multirec = new JList(ListMultirec);
	private JScrollPane scroll_multirec =new JScrollPane(list_multirec);
	
		public MultiRectangle (){
			pointref = new Point2D(0,0);
			R=new ArrayList<Rectangle>();
			scroll_multirec.setPreferredSize(new Dimension(250,120));
			list_multirec.setPreferredSize(new Dimension(220,5000));
			
		}
		
		

		public MultiRectangle(Point2D pointref){
			super(pointref);
			R=new ArrayList<ObjetDeBase>();
			scroll_multirec.setPreferredSize(new Dimension(250,120));
			list_multirec.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mrec.add(scroll_multirec); // pnl_liste_mseg => pnl_liste_mrec
		}
		
		public MultiRectangle (MultiRectangle M){
			this.pointref=M.pointref;
			this.R=M.R;
			scroll_multirec.setPreferredSize(new Dimension(250,120));
			list_multirec.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mrec.add(scroll_multirec);
		}
		
		public ArrayList<Rectangle> getMr(){
			return Mr;
		}

		public void setMr(ArrayList<Rectangle> rec){
			R = rec;
		}
		
		public JPanel getPnl_liste_mrec(){
			return pnl_liste_mrec;
		}

		public void setPnl_liste_mrec(JPanel pnl_liste_rec){
			this.pnl_liste_mrec = pnl_liste_mrec;
		}

		public DefaultListModel getListMultiseg(){
			return list_multirec;
		}

		public void setListMultirec(DefaultListModel listMultirec){
			list_multirec = listMultirec;
		}

		public JList getList_multirec() {
			return pnl_liste_rec;
		}

		public void setList_multirec(JList pnl_liste_rec){
			this.pnl_liste_rec = pnl_liste_rec;
		}

		public JScrollPane getScroll_multirec(){
			return scroll_multirec;
		}

		public void setScroll_multirec(JScrollPane scroll_multirec){
			this.scroll_multirec = scroll_multirec;
		}

		public String toString(){
			return super.toString() +"MultiRectangle [Mr=" + R + "]";
		}
		
		public void ajouter(Rectangle r){
			R.add(r);
		}
		
		public void supprimer(Rectangle r){
			R.remove(r);
		}
		
		public int nbcomp(){
			return this.getMr().size();
		}
	}
