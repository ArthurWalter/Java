package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;

public class PanelDraw extends JPanel implements MouseListener {
// 	
	private ObjetDeBase o; //à enregistrer dans la classe Gest	
	private int x;
	private int y;
//1 Rectangle, 2 Cercle, 3 Ellipse, 4 Quadrilatere
//5 ObjetComposite	
	public static int indice;
//Rectangle
	private int width;
	private int height;
//Cercle	
	private int rayon;
//Ellipse
	private int rayonlong;
    private int rayoncourt;
//Quadrilatere
    private Point2D point2;
    private Point2D point3;
    private Point2D point4;
//panel 
    private JPanel pf=new JPanel(); //panel de font
	private JButton bretour=new JButton("Retourner");
	private JButton bsave=new JButton("Enregistrer");
	private JButton bdepl=new JButton("Déplacer");
	
	public PanelDraw(Objet odb) {
//config panel de font
		Accueil.Clear();
		Accueil.Add(pf);
		JPanel p1=new JPanel(); //panel haut
		JPanel p3=new JPanel(); //panel bas
		pf.setLayout(new BorderLayout());
		pf.add(p1,BorderLayout.NORTH);
		//config panel milieu 
		pf.add(this,BorderLayout.CENTER);
		pf.add(p3,BorderLayout.SOUTH);
		JLabel l1 = new JLabel();
		p1.setBackground(Color.LIGHT_GRAY);
		p1.add(l1, BorderLayout.CENTER);
		//config panel bas
		p3.setLayout(new GridLayout(1,2));
		p3.add(bretour);
		p3.add(bsave);
		bretour.addMouseListener(this);
		bsave.addMouseListener(this);
		bdepl.addMouseListener(this);
//si on veut dessiner un Rectangle
		if( odb instanceof Rectangle) 
		{	//les paramètres
			indice=1;
			Rectangle r=(Rectangle) odb;
			this.o=r;
			l1.setText("Rectangle :");
			x=r.pointref.getX();
			y=r.pointref.getY();
			width=r.point2.getX()-r.pointref.getX();
			height=r.point2.getY()-r.pointref.getY();
		}
//si on veut dessiner un Cercle
		else if (odb instanceof Cercle)
		{	//les paramètres
			indice=2;
			Cercle c=(Cercle) odb;
			this.o=c;
			l1.setText("Cercle :");
			x=c.pointref.getX();
			y=c.pointref.getY();
			rayon=c.getRayon();
		}
//si on veut dessiner un Ellipse
		else if (odb instanceof Ellipse)
		{	//les paramètres
			indice=3;
			Ellipse e=(Ellipse) odb;
			this.o=e;
			l1.setText("Ellipse :");
			x=e.pointref.getX();
			y=e.pointref.getY();
			rayonlong=e.getRayonlong();
			rayoncourt=e.getRayoncourt();
		}
//si on veut dessiner un Quadrilatere
		else if (odb instanceof Quadrilatere)
		{	//les paramètres
			indice=4;
			Quadrilatere q=(Quadrilatere) odb;
			this.o=q;
			l1.setText("Quadrilatere :");
			x=q.pointref.getX();
			y=q.pointref.getY();
			point2=q.getPoint2();
			point3=q.getPoint3();
			point4=q.getPoint4();
		}
//si on veut dessiner un Objet Composite
		else if (odb instanceof ObjetComposite)
		{	//les paramètres
			indice=5;
//			Quadrilatere q=(Quadrilatere) odb;
//			this.o=q;
//			l1.setText("Quadrilatere :");
//			x=q.pointref.getX();
//			y=q.pointref.getY();
//			point2=q.getPoint2();
//			point3=q.getPoint3();
//			point4=q.getPoint4();
		}
	}
//la fonction pour dessiner
	public void paint(Graphics g) {
		Graphics2D g2= (Graphics2D) g;
		if (indice==1){
			g2.drawRect(x,y, width, height);}
		else if (indice==2){
			g2.drawOval(x, y, rayon*2, rayon*2);}
		else if (indice==3){
			g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
		else if (indice==4){
			g2.drawLine(x,y, point2.getX(), point2.getY());
			g2.drawLine(point2.getX(), point2.getY(), point3.getX(), point4.getY());
			g2.drawLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
			g2.drawLine(point4.getX(), point4.getY(), x,y);
		}
	}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bretour||e.getSource()==bsave) 
		{	if (indice==1) 
			{	
				Accueil.Clear();
				Accueil.Add(new Rectangle(1));
			}
			else if (indice==2)
			{	
				Accueil.Clear();
				Accueil.Add(new Cercle(1));
			}
			else if (indice==3)
			{	
				Accueil.Clear();
				Accueil.Add(new Ellipse(1));
			}
			else if (indice==4)
			{	
				Accueil.Clear();
				Accueil.Add(new Quadrilatere(1));
			}
			else if (indice==5)
			{	
				Accueil.Clear();
				Accueil.Add(new ObjetComposite(1));
			}
			else if (indice==6)
			{	
				Accueil.Clear();
				Accueil.Add(new Ellipse(1));
			}
			else if (indice==7)
			{	
				Accueil.Clear();
				Accueil.Add(new Quadrilatere(1));
			}
			else if (indice==8)
			{	
				Accueil.Clear();
				Accueil.Add(new Quadrilatere(1));
			}
		}
			if (e.getSource()==bsave) {	
				Gest.Add(this.o);
//				Gest2.Add(this.o);
				Accueil.Clear();
				Accueil.Add(new AccueilPanel());
			}
			if(e.getSource()==bdepl) {
				
				if(o instanceof Rectangle){
					
				}
				if(o instanceof Cercle){
					
				}
				if(o instanceof Ellipse){
					
				}
				if(o instanceof Quadrilatere){
					
				}
			}
		}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
