package D;

import java.awt.Graphics;
import java.awt.geom.Point2D;

public class Rectangle extends FormeBase{
private static int i =0;
protected Point2D pointBas = new Point2D();
public Rectangle(Point2D pointBas) {
	super("Rectangle n~"+(++i));
	
}
public Point2D getPointBas()
{
	return pointBas;
		
}
public void setPointBas(Poin2D pointBas)
{
	this.pointBas = pointBas;
}
public void affichage(Graphics g)
{
	super.affichage(g);
	int longeur = getLongeur;
	int largeur = getLargeur;
	if(fill)
		g.fillRect(pointOrigine.getX(),pointOrigine.getY(),longeur,largeur));
	else 
		g.drawRect(pointOrigine.getX(),pointOrigine.getY(),longeur,largeur);
}
public void deplacement(Point2D point)
{
	super.deplacement(point);
	pointBas = PointBas.add(Point);
}
public void isOnFrome(Point2D point)
{
 return.point.getX() >PointOrigine.getX() && point.getX() < pointBas.getX();
 && point.getY()> pointOrigine.getY() && point.getY() < pointBas.getY();
}
public void agrandir (Point2D point)
{
	Point2D pointCentre = pointOrigine.centre(pointBas);
	if(point.getX() > =pointCentre.getX() &&point.getY()>= pointCentre.getY())
	{
		pointBas.setX(point.getX());
		pointBas.setY(point.getY());
	}
	else if (point.getX() > =pointCentre.getX() &&point.getY()>= pointCentre.getY())
	{
		pointBas.setX(point.getX());
		pointOrigine.setY(point.getY());
	}
	else if(point.getX() < =pointCentre.getX() &&point.getY()<= pointCentre.getY())
	{
		pointBas.setX(point.getX());
		pointOrigine.setY(point.getY());
	}
	else
	{	
		pointBas.setX(point.getX());
		pointOrigine.setY(point.getY());
	}
}
public Point2D getPointHautGauche()
{
	return pointBas.getX() -pointOrigine.getX();
}
public int getLongeur()
{
	return pointBas.getX() - pointOrigine.getX();
}
public int getLargeur()
{
	return pointBas.getY() - pointOrigine.getY();
}
}
