package projet.iut.metz.groupe4.forme;

import java.awt.Color;
import java.awt.Graphics;

public class Cercle extends FormeBase{

	private static int i = 0;
	
	protected int rayon = 0;

	public Cercle(Point2D pointOrigine, Color color, boolean fill)
	{
		super("Cercle n�" + (++i), pointOrigine, color, fill);
	}

	public int getRayon()
	{
		return rayon;
	}

	public void setRayon(int rayon)
	{
		this.rayon = rayon;
	}

	@Override
	public void affichage(Graphics graph)
	{
		super.affichage(graph);
		Point2D pointHautGauche = getPointHautGauche();
		int rayon = getLongueur();
		if (fill)
			graph.fillOval(pointHautGauche.getX(), pointHautGauche.getY(), rayon, rayon);
		else graph.drawOval(pointHautGauche.getX(), pointHautGauche.getY(), rayon, rayon);
	}
	
	@Override
	public boolean isOnForme(Point2D point)
	{
		return pointOrigine.distance(point) <= rayon;
	}

	@Override
	public void agrandir(Point2D point)
	{
		int r1 = Math.abs(pointOrigine.getX() - point.getX());
		int r2 = Math.abs(pointOrigine.getY() - point.getY());
		rayon = r1 > r2 ? r1:r2;
		//rayon = (int) pointOrigine.distance(point);
	}

	@Override
	public Point2D getPointHautGauche()
	{
		return pointOrigine.sub(new Point2D(rayon, rayon));
	}

	@Override
	public int getLongueur()
	{
		return rayon * 2;
	}

	@Override
	public int getLargeur()
	{
		return getLongueur();
	}

}
