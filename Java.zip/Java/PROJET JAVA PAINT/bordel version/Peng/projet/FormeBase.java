package projet.iut.metz.groupe4.forme;

import java.awt.Color;
import java.awt.Graphics;

public abstract class FormeBase extends Forme{
	
	protected Color color = Color.BLACK;
	protected boolean fill = true;
	
	public FormeBase(String name, Point2D pointOrigine, Color color, boolean fill)
	{
		super(name, pointOrigine);
		this.color = color;
		this.fill = fill;
	}

	public Color getCouleur()
	{
		return color;
	}

	public void setCouleur(Color couleur)
	{
		this.color = couleur;
	}

	public boolean isFill()
	{
		return fill;
	}

	public void setFill(boolean fill)
	{
		this.fill = fill;
	}
	
	@Override
	public void affichage(Graphics graph)
	{
		graph.setColor(color);
	}
	
}
