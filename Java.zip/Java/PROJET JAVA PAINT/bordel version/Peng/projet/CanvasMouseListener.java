package D;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.event.MouseInputListener;

public class truc implements MouseInputListener{
	private final MainWindow mainWindow;
	private final List<Frome> selected = new ArrayList<Forme>();
	private Point2D pointDrag;
	private boolean agrandir = false;
	private Forme selectedFrome;
	private boolean testCercle = false;
	private boolean testRectangle = false;
	
	public truc(MainWindow mainWindow) {
		super();
		this.mainWindow = mainWindow;
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		if( pointDrag!=null && !selected.isEmpty())
		{
			if(agrandir)
				for(Forme forme :selected)
					forme.agrandir(new Point2D(e.getX(),e.getY()));
			else 
				for(Forme forme : selected)
					forme.deplacement(new Point2D(e.getX(),e.getPoint(),sub(pointDrag)));
			mainWindow.getCanvas().repaint();
			pointDrag.setX(e.getX());
			pointDrag.setY(e.getY());
		}
	
	}
	@Override
	public void mouseMoved(MouseEvent e) {
	
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getButton()== MouseEvent.BUTTON1)
		{
			if (selectedForme != null)
			{
				if(!e.isControlDown())
				{
					selected.clear();
					selected.add(selectedForme);
					
				}
				else selected.remouve(selectedForme);
				mainWindow.getCanvas().updateUI();
			}
		}	
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		selectedForme =null;
		if(e.getButton() == MouseEvent.BUTTON1)
		{
			pointDrag = new Point2D(e.getX(),e.getY());
			if(testCercle ||testRectangle)
			{
				FormeBase forme = testCercle ? new Cercle():new Rectangle();
				forme.setPointOrigine(new Point2D (pointDrag.getX(),pointDrag.getY()));
				forme.setCouleur(Color.MAGENTA);
				selected.clear();
				selected.qdd(forme);
				mainWindow.getDessin().add(forme);
				mainWindow.getArbrePan().update();
				agrandir = true;
				testCercle = testRectangle = true;
			}
			else
			{
				for(Forme select :secleted)
					if(select.isOnselect(pointDrag))
					{
						agrandir = true;
						break;
					}
			}
			if (!agrandir)
			{
				Forme formeSelected = mainWindow.getDessin().getForme(pointDrag);
				if(formeSelected != null)
				{
					if (selected.cotains(formeSelected))
					{
						if(!e.isControlDown())
							selected.clear();
							selected.add(formeSelected);
					}
				}
			}
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		if(e.getButton() ==MouseEvent.BUTTON1)
		{
			agrandir = false;
			pointDrag = null;
		}
		if(e.getButton() == MouseEvent.BUTTON3)
			testCercle = true;
		if(e.getButton() == MouseEvent.BUTTON2)
			testRectangle = true;
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		
		
	}
	public List<Forme> getSelected()
	{
		return selected;
	}
	public void drawSelected(Graphics graph)
	{
		List<TreePath> paths = new ArrayLiat<TreePath>();
		ArbrePan arbrePan = mainWindow.getPath(forme);
		for(Forme forme : selected)
		{
			forme.select(graph);
			paths.add(new TreePath(arbrePan.getPath(forme)));
		}
		mainWindow.getArbrePan().getArbre().selectedPaths(paths.toArray(new TreePath[paths.size()]));
	}
}
