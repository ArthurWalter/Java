package DessinAssiste;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/*
 * propriété pour le dessin qctuelle
 */
public class AttributeDialog extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	/*Panel */
	private JPanel content;
	
	/* Couleur */
	private JPanel colorPanel;
	
	private JButton fgButton;

	/* size de Panel */
	private JPanel sizePanel;
	/*Optimiser Panel */
	private JPanel utilPanel;
	/*Police */
	private JComboBox faceCombox;
	/*style */
	private JComboBox styleCombox;
	/*font */
	private JComboBox sizeCombox;
	/*coordonée */
	private Position position;
	/*paneau */
	private FormeComposite board;

	/*initial font */
	private final Font font = new Font("Dialog", 0, 12);
	/* pinceau */
	private final String STROKES[] = new String[] { "10.0px", "8.0px", "6.5px", "4.0px", "2.5px", "2.0px" };
	/* Police */
	//private final String FACES[] = new String[] {  };
	/*Style */
	private final String STYLE[] = new String[] { "PLAIN", "BOLD", "ITALIC" };
	/* Font */
	private final String SIZES[] = new String[] { "20", "22", "24", "26", "28", "30", "32", "34", "36", "38", "40", "42", "44", "46", "48", "50" };

	public AttributeDialog(FormeComposite board) {
		this.board = board;
		initGUI();
	}

	private void initGUI() {
		setModal(true);
		setTitle("Réviser l'image actuelle");
		setLayout(new GridBagLayout());

		content = new JPanel();
		content.setLayout(new BoxLayout(content, 1));
		//
		GridBagConstraints gridbagconstraints = new GridBagConstraints();
		gridbagconstraints.anchor = 11;
		gridbagconstraints.weightx = 1.0D;
		gridbagconstraints.insets = new Insets(10, 5, 5, 5);
		getContentPane().add(content, gridbagconstraints);

		colorPanel = new JPanel();
		fgButton = new JButton();
		sizePanel = new JPanel();
		utilPanel = new JPanel();
		faceCombox = new JComboBox();
		styleCombox = new JComboBox();
		sizeCombox = new JComboBox();

		// Color Panel
		colorPanel.setLayout(new FlowLayout(1, 20, 10));
		colorPanel.setBorder(new TitledBorder("Couleur"));
		content.add(colorPanel);

		fgButton.setBackground(board.currantForme.color);
		fgButton.setToolTipText("Changer le Couleur ");
		fgButton.setBorder(new LineBorder(new Color(0, 0, 0)));
		fgButton.setPreferredSize(new Dimension(100, 50));
		fgButton.addActionListener(this);
		colorPanel.add(fgButton);

		// Size Panel
		// distinguer le teste or la forme
		if (!"text".equals(board.currantForme.getType())) {
			sizePanel.setBorder(new TitledBorder("Font"));
			sizeCombox.setFont(font);
			sizeCombox.setPreferredSize(new Dimension(100, 25));
			sizeCombox.setModel(new DefaultComboBoxModel(STROKES));
			sizeCombox.setSelectedItem(String.valueOf(board.currantForme.stroke)+"px");
			sizeCombox.addActionListener(this);

			utilPanel.setLayout(new BorderLayout(0, 3));
			utilPanel.add(sizeCombox, "North");
			sizePanel.add(utilPanel);
			content.add(sizePanel);
		} else {
			sizePanel.setBorder(new TitledBorder("Style"));

			faceCombox.setFont(font);
			faceCombox.setPreferredSize(new Dimension(120, 25));
			faceCombox.setModel(new DefaultComboBoxModel(FACES));
			faceCombox.setSelectedItem(((Text)board.currantForme).getTextFace());
			faceCombox.addActionListener(this);

			styleCombox.setFont(font);
			styleCombox.setPreferredSize(new Dimension(120, 25));
			styleCombox.setModel(new DefaultComboBoxModel(STYLE));
			styleCombox.setSelectedItem(String.valueOf(((Text)board.currantForme).getTextStyle()));
			styleCombox.addActionListener(this);

			sizeCombox.setFont(font);
			sizeCombox.setPreferredSize(new Dimension(120, 25));
			sizeCombox.setModel(new DefaultComboBoxModel(SIZES));
			sizeCombox.setSelectedItem(String.valueOf(((Text)board.currantForme).getTextSize()));
			sizeCombox.addActionListener(this);

			utilPanel.setLayout(new BorderLayout(0, 3));
			utilPanel.add(faceCombox, "North");
			utilPanel.add(styleCombox, "Center");
			utilPanel.add(sizeCombox, "South");
			sizePanel.add(utilPanel);
			content.add(sizePanel);
		}

		// Position & Diameter Panel
		if (!"line".equals(board.currantForme.getType())) {
			position = new Position(board);
			position.setBorder(new TitledBorder("Coordonnée"));
			content.add(position);
		}

		pack();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == fgButton) {
			Color color = JColorChooser.showDialog(this, "Selectionner la couleur", board.getForeground());
			if (color != null) {
				fgButton.setBackground(color);
				board.setCurrentColor(color);
			}
		}
		if (e.getSource() == faceCombox) {
			board.setCurrentTxtFontFace(faceCombox.getSelectedItem().toString());
		}
		if (e.getSource() == styleCombox) {
			board.setCurrentTxtFontStyle(styleCombox.getSelectedItem().toString());
		}
		if (!"text".equals(board.currantForme.getType())) {
			if (e.getSource() == sizeCombox) {
				String temp = sizeCombox.getSelectedItem().toString();
				board.setStrokeSize(Float.parseFloat(temp.substring(0, temp.length() - 2)), board.currantForme.getType());
			}
		} else {
			if (e.getSource() == sizeCombox) {
				board.setCurrentTxtFontSize(sizeCombox.getSelectedItem().toString());
			}
		}
	}

}
