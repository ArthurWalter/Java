package projet.iut.metz.groupe4.forme;

public class Point2D
{
	private int x = 0;
	private int y = 0;
	
	public Point2D() {}
	
	public Point2D(int x, int y)
	{
		this.setX(x);
		this.setY(y);
	}
	
	public Point2D(Point2D point)
	{
		x = point.x;
		y = point.y;
	}

	public int getX()
	{
		return x;
	}

	public void setX(int x)
	{
		this.x = x;
	}

	public int getY()
	{
		return y;
	}

	public void setY(int y)
	{
		this.y = y;
	}

	@Override
	public String toString()
	{
		return "Point2D [x = " + x + ", y = " + y + "]";
	}
	
	public Point2D add(Point2D point)
	{
		return new Point2D(x + point.x, y + point.y);
	}
	
	public Point2D sub(Point2D point)
	{
		return new Point2D(x - point.x, y - point.y);
	}
	
	public Point2D centre(Point2D point)
	{
		return new Point2D((x + point.x) / 2, (y + point.y) / 2);
	}
	
	public double distance(Point2D point)
	{
		return Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
	}
}
