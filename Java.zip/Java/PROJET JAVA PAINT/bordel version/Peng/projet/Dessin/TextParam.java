
package DessinAssiste;

/*
 * propriété de texte 
 */
public class TextParam {

	/* segement */
	private Long roadSegmentId;
	/* contenu de texte */
	private String textContent;
	/* size de texte = 30 */
	private Integer size = 30;
	/* au debut de texte */
	private PointParam point;
	/* couleur de texte */
	private ColorParam color;
	/* orientation de texte ,inital est 1；1 est horizontale，2 est verticale */
	private Integer direction = 1;

	public TextParam(Long roadSegmentId, String textContent, Integer size,
			PointParam point, ColorParam color, Integer direction) {
		super();
		this.roadSegmentId = roadSegmentId;
		this.textContent = textContent;
		this.size = size;
		this.point = point;
		this.color = color;
		this.direction = direction;
	}

	public Integer getDirection() {
		return direction;
	}

	public void setDirection(Integer direction) {
		this.direction = direction;
	}

	public Long getRoadSegmentId() {
		return roadSegmentId;
	}

	public void setRoadSegmentId(Long roadSegmentId) {
		this.roadSegmentId = roadSegmentId;
	}

	public String getTextContent() {
		return textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public PointParam getPoint() {
		return point;
	}

	public void setPoint(PointParam point) {
		this.point = point;
	}

	public ColorParam getColor() {
		return color;
	}

	public void setColor(ColorParam color) {
		this.color = color;
	}

}
