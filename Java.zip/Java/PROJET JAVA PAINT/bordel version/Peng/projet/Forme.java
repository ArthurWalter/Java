package projet.iut.metz.groupe4.forme;

import java.awt.Color;
import java.awt.Graphics;

public abstract class Forme
{
	protected String name;
	protected Point2D pointOrigine = new Point2D();
	
	public Forme(String name, Point2D pointOrigine)
	{
		this.name = name;
		this.pointOrigine = pointOrigine;
	}
	
	public String getName()
	{
		return name;
	}
	
	public final Point2D getPointOrigine()
	{
		return pointOrigine;
	}

	public final void setPointOrigine(Point2D pointOrigine)
	{
		this.pointOrigine = pointOrigine;
	}

	public void deplacement(Point2D point)
	{
		pointOrigine = pointOrigine.add(point);
	}
	
	public abstract void affichage(Graphics graph);
	
	public abstract boolean isOnForme(Point2D point);
	
	public final boolean isOnSelect(Point2D point)
	{
		Point2D pointHG = getPointHautGauche();
		int longueur = getLongueur();
		int largeur = getLargeur();
		
		return (point.getX() >= pointHG.getX() - 5 &&  point.getX() <= pointHG.getX() + longueur + 5 
					&& (point.getY() <= pointHG.getY() && point.getY() >= pointHG.getY() - 5
					|| point.getY() >= pointHG.getY() + largeur && point.getY() <= pointHG.getY() + largeur + 5))
				|| (point.getY() >= pointHG.getY() - 5 &&  point.getY() <= pointHG.getY() + largeur + 5
					&& (point.getX() <= pointHG.getX() && point.getX() >= pointHG.getX() - 5
					|| point.getX() >= pointHG.getX() + longueur && point.getX() <= pointHG.getX() + longueur + 5));
	}
	
	public final void select(Graphics graph)
	{
		Point2D pointHG = getPointHautGauche();
		int longueur = getLongueur();
		int largeur = getLargeur();
		
		graph.setColor(Color.LIGHT_GRAY);
		
		for (int i = 2; i <= 5; i++)
			graph.drawRect(pointHG.getX() - i, pointHG.getY() - i, longueur + i * 2, largeur + i * 2);
	}
	
	public abstract void agrandir(Point2D point);
	
	public abstract Point2D getPointHautGauche();
	
	public abstract int getLongueur();
	
	public abstract int getLargeur();
	
	@Override
	public String toString()
	{
		return name;
	}
}