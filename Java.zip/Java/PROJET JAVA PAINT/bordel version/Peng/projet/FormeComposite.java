package projet.iut.metz.groupe4.forme;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FormeComposite extends Forme implements Iterable<FormeBase>{

	private static int i = 0;
	
	private final List<FormeBase> formes = new ArrayList<FormeBase>();

	public FormeComposite(Point2D pointOrigine)
	{
		super("Forme Composite n�" + (++i), pointOrigine);
	}

	public List<FormeBase> getFormes()
	{
		return formes;
	}

	public void add(Forme forme)
	{
		add(forme, size());
	}
	
	public void add(Forme forme, int index)
	{
		if (forme instanceof FormeBase)
			add((FormeBase) forme, index);
		else add((FormeComposite) forme, index);
	}
	
	public void add(FormeBase forme, int index)
	{
		if (formes.contains(forme))
			formes.remove(forme);
		else if (hasSameName(forme))
			forme.name += "(C)";
		formes.add(index, forme);
	}
	
	public void add(FormeComposite formeCompo, int index)
	{
		for (FormeBase forme: formeCompo)
			add(forme, index++);
	}
	
	public FormeBase get(String name)
	{
		for (FormeBase forme: this)
			if (forme.name.equals(name))
				return forme;
		return null;
	}
	
	public boolean contains(String name)
	{
		return get(name) != null;
	}
	
	public boolean hasSameName(FormeBase forme)
	{
		return contains(forme.name);
	}
	
	public void remove(FormeBase forme)
	{
		formes.remove(forme);
	}
	
	public FormeBase remove(String name)
	{
		FormeBase forme = get(name);
		remove(forme);
		return forme;
	}

	@Override
	public void affichage(Graphics graph)
	{
		forEach(f -> f.affichage(graph));
	}
	
	public int size()
	{
		return formes.size();
	}

	@Override
	public Iterator<FormeBase> iterator()
	{
		return formes.iterator();
	}

	@Override
	public boolean isOnForme(Point2D point)
	{
		for (FormeBase forme: this)
			if (forme.isOnForme(point))
				return true;
		return false;
	}

	@Override
	public void agrandir(Point2D point)
	{
		forEach(f -> f.agrandir(point));
	}

	@Override
	public Point2D getPointHautGauche()
	{
		Point2D pointMin = new Point2D(formes.get(0).getPointHautGauche());
		for (Forme forme: this)
		{
			Point2D point = forme.getPointHautGauche();
			if (point.getX() < pointMin.getX())
				pointMin.setX(point.getX());
			if (point.getY() < pointMin.getY())
				pointMin.setY(point.getY());
		}
		return pointMin;
	}

	@Override
	public int getLongueur()
	{
		int max = 0;
		for (Forme forme: this)
			if (forme.getLongueur() > max)
				max = forme.getLongueur();
				
		return max;
	}

	@Override
	public int getLargeur()
	{
		int max = 0;
		for (Forme forme: this)
			if (forme.getLargeur() > max)
				max = forme.getLargeur();
				
		return max;
	}
}