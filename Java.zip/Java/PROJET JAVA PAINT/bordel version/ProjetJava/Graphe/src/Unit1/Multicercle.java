package Unit1;


public class Multicercle {
	
public static Point2D pointref;
	
	public Multicercle(){
		System.out.println("Multi");
	}
	public Multicercle(int i) {
		Init();
	}
	public void Init() {
		Accueil.Clear();
		Accueil.Add(new Cercle(1));
		PanelDraw.indiceobj=4;//MultiCercle
		Cercle.indiceobj=3;//MultiRectangle
	}
}
