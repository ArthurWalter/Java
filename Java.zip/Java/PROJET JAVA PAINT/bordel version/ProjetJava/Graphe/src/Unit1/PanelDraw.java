package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.util.ArrayList;
import java.util.Iterator;

public class PanelDraw extends JPanel implements MouseListener {
// 	
	public static ArrayList<ObjetDeBase> al=new ArrayList();
	private int i=0;
	
	private ObjetDeBase o; //à enregistrer dans la classe Gest	
	private int x;
	private int y;
//1 Rectangle, 2 Cercle, 3 Ellipse, 4 Quadrilatere
	public static int indice;
	public static int indiceobj;
//1 ObjetDeBase, 2 ObjetComposite
//3 MultiRectangle, 4 Multicercle, 5 Multiellipse
//Rectangle
	private int width;
	private int height;
//Cercle	
	private int rayon;
//Ellipse
	private int rayonlong;
    private int rayoncourt;
//Quadrilatere
    private Point2D point2;
    private Point2D point3;
    private Point2D point4;
//panel 
    private JPanel pf=new JPanel(); //panel de font
    private JLabel l1 = new JLabel();
	private JButton bretour=new JButton("Retourner");
	private JButton bsave=new JButton("Enregistrer");
	private JButton bdeplace=new JButton("Déplacer");
	
	public PanelDraw(Objet o) {
//config panel de font
		Accueil.Clear();
		Accueil.Add(pf);
		JPanel p1=new JPanel(); //panel haut
		JPanel p3=new JPanel(); //panel bas
		pf.setLayout(new BorderLayout());
		pf.add(p1,BorderLayout.NORTH);
		//config panel milieu 
		pf.add(this,BorderLayout.CENTER);
		pf.add(p3,BorderLayout.SOUTH);
		
		p1.setBackground(Color.LIGHT_GRAY);
		p1.add(l1, BorderLayout.CENTER);
		//config panel bas
		p3.setLayout(new GridLayout(1,2));
		p3.add(bretour);
		p3.add(bsave);
		p3.add(bdeplace);
		bretour.addMouseListener(this);
		bsave.addMouseListener(this);
		bdeplace.addMouseListener(this);
		if (o instanceof ObjetDeBase)
		{
			ObjetDeBase odb=(ObjetDeBase) o;
			calcul(odb);
		}
//		else if (o instanceof ObjetComposite)
//		{
//			ObjetComposite oc=(ObjetComposite) o;
//			
//		}	
	}
//calculer les paramètres et les mettre en attribut
	public void calcul(ObjetDeBase odb){
		//si on veut dessiner un Rectangle
		if( odb instanceof Rectangle) 
		{	//les paramètres
			indice=1;
			Rectangle r=(Rectangle) odb;
			this.o=r;
			l1.setText("Rectangle :");
			x=r.pointref.getX();
			y=r.pointref.getY();
			width=r.point2.getX()-r.pointref.getX();
			height=r.point2.getY()-r.pointref.getY();
		}
		//si on veut dessiner un Cercle
		else if (odb instanceof Cercle)
		{	//les paramètres
			indice=2;
			Cercle c=(Cercle) odb;
			this.o=c;
			l1.setText("Cercle :");
			x=c.pointref.getX();
			y=c.pointref.getY(); 
			rayon=c.getRayon();
		}
		//si on veut dessiner un Ellipse
		else if (odb instanceof Ellipse)
		{	//les paramètres
			indice=3;
			Ellipse e=(Ellipse) odb;
			this.o=e;
			l1.setText("Ellipse :");
			x=e.pointref.getX();
			y=e.pointref.getY();
			rayonlong=e.getRayonlong();
			rayoncourt=e.getRayoncourt();
		}
		//si on veut dessiner un Quadrilatere
		else if (odb instanceof Quadrilatere)
		{	//les paramètres
			indice=4;
			Quadrilatere q=(Quadrilatere) odb;
			this.o=q;
			l1.setText("Quadrilatere :");
			x=q.pointref.getX();
			y=q.pointref.getY();
			point2=q.getPoint2();
			point3=q.getPoint3();
			point4=q.getPoint4();
		}
	}
//ajouter un element dans ArrayList
	public static void Add(ObjetDeBase odb){
		al.add(odb);
	}
//dessiner selon l'indice et les attributs
	public void paint(Graphics g) {
		Graphics2D g2= (Graphics2D) g;
		Iterator it=al.iterator();
		if (indice==1)//ObjetDeBase
		{
			g2.drawRect(x,y, width, height);}
		else if (indice==2){
			g2.drawOval(x, y, rayon*2, rayon*2);}
		else if (indice==3){
			g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
		else if (indice==4){
			g2.drawLine(x,y, point2.getX(), point2.getY());
			g2.drawLine(point2.getX(), point2.getY(), point3.getX(), point4.getY());
			g2.drawLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
			g2.drawLine(point4.getX(), point4.getY(), x,y);
		}
		if(indiceobj==2)//ObjetComposite
		{
			for (int i=0;i<al.size();i++)
			{
				ObjetDeBase odb=(ObjetDeBase) al.get(i);
				calcul(odb);
				this.o=odb;
				if (indice==1){
					g2.drawRect(x,y, width, height);}
				else if (indice==2){
					g2.drawOval(x, y, rayon*2, rayon*2);}
				else if (indice==3){
					g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
				else if (indice==4){
					g2.drawLine(x,y, point2.getX(), point2.getY());
					g2.drawLine(point2.getX(), point2.getY(), point3.getX(), point4.getY());
					g2.drawLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
					g2.drawLine(point4.getX(), point4.getY(), x,y);}	
			}
		}
		else if (indiceobj==3)//MultiRectangle
		{	
//			while (it.hasNext())
//			{
//					System.out.println(it.toString());
//					ObjetDeBase odb=(ObjetDeBase)it.next();
////					this.o=odb;
//					calcul(o);
//					if (indice==1){
//						g2.drawRect(x, y, width, height);}
//					else if (indice==2){
//						g2.drawOval(x, y, rayon*2, rayon*2);}
//					else if (indice==3){
//						g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
//					else if (indice==4){
//						g2.drawLine(x,y, point2.getX(), point2.getY());
//						g2.drawLine(point2.getX(), point2.getY(), point3.getX(), point4.getY());
//						g2.drawLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
//						g2.drawLine(point4.getX(), point4.getY(), x,y);
//					}			
//			}
			for (int i=0;i<al.size();i++)
			{
				ObjetDeBase odb=(ObjetDeBase) al.get(i);
				System.out.println(al.get(i));
				calcul(odb);
				this.o=odb;
				if (indice==1){
					g2.drawRect(x,y, width, height);}
				else if (indice==2){
					g2.drawOval(x, y, rayon*2, rayon*2);}
				else if (indice==3){
					g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
				else if (indice==4){
					g2.drawLine(x,y, point2.getX(), point2.getY());
					g2.drawLine(point2.getX(), point2.getY(), point3.getX(), point4.getY());
					g2.drawLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
					g2.drawLine(point4.getX(), point4.getY(), x,y);}	
			}
		}
		
	}
	
	public static void DeleteAll(){
		al.removeAll(al);
	}
	
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bretour||e.getSource()==bsave) 
			
		{	if (indice==1) 
			{	
				Accueil.Clear();
				Accueil.Add(new Rectangle(1));
				if(indiceobj==1){
					PanelDraw.DeleteAll();
				}
			
			}
			else if (indice==2)
			{	
				Accueil.Clear();
				Accueil.Add(new Cercle(1));
				if(indiceobj==1){
					PanelDraw.DeleteAll();
				}
			}
			else if (indice==3)
			{	
				Accueil.Clear();
				Accueil.Add(new Ellipse(1));
				if(indiceobj==1){
					PanelDraw.DeleteAll();
				}
			}
			else if (indice==4)
			{	
				Accueil.Clear();
				Accueil.Add(new Quadrilatere(1));
				if(indiceobj==1){
					PanelDraw.DeleteAll();
				}
			}
		}
//		}
		if (e.getSource()==bsave) 
		{	
			if (indiceobj==2)//ObjetComposite
			{
				Gest.Add(this.o);
				Add(this.o);
				Accueil.Clear();
				Accueil.Add(new ObjetComposite(1));
				System.out.println(al.size());
			}
			else if (indiceobj==3) //MultiRectangle
			{
				Gest.Add(this.o);
				Add(this.o);
				Accueil.Clear();
				Accueil.Add(new Rectangle(1));				
				System.out.println(al.size());
			}
			else if (indiceobj==4) //MultiCercle
			{
				Gest.Add(this.o);
				Add(this.o);
				Accueil.Clear();
				Accueil.Add(new Rectangle(1));				
				System.out.println(al.size());
			}
			else if (indiceobj==5) //MultiEllipse
			{
				Gest.Add(this.o);
				Add(this.o);
				Accueil.Clear();
				Accueil.Add(new Rectangle(1));				
				System.out.println(al.size());
			}
			else {
				Gest.Add(this.o);
				Accueil.Clear();
				Accueil.Add(new AccueilPanel());
			}
		}
		if(e.getSource()==bdeplace)
		{
			PanelDeplacer pd=new PanelDeplacer();
		}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
