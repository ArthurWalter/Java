package Unit1;

public class Multiellipse {
	
public static Point2D pointref;
	
	public Multiellipse(){
		System.out.println("Multi");
	}
	public Multiellipse(int i) {
		Init();
	}
	public void Init() {
		Accueil.Clear();
		Accueil.Add(new Ellipse(1));
		PanelDraw.indiceobj=5;//Multiellipse
		Ellipse.indiceobj=3;//MultiRectangle
	}
}
