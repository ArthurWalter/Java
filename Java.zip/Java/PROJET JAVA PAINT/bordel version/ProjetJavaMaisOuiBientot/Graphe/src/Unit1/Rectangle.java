package Unit1;
import javax.swing.JButton;
import Unit1.PanelDraw;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Graphics;


public class Rectangle extends ObjetDeBase implements MouseListener {
//les attributs	
	public Point2D point2;
	private JFrame f1=new JFrame("Rectangle");
	private JTextField tf1=new JTextField(""); 
	private JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField(""); 
	private JTextField tf4=new JTextField("");
	private JButton b1=new JButton("Retourner"); 
	private JButton b2=new JButton("Afficher");
//constructeur 	
	public Rectangle(){	
		super.f1.dispose();
//config frame
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		//f1.setContentPane(new RectangleDraw());
//config panel de font qui contient panels haut, milieu et bas	
		JPanel p1=new JPanel();		//p1:panel des font
		JPanel p2=new JPanel();		//p2:panel haut
		JPanel p3=new JPanel(); 	//p3:panel milieu
		JPanel p4=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1); 
		f1.add(p1);						  	
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
//config panel haut
		//config label
		JLabel l1=new JLabel("Rectangle");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p2.setLayout(bl1);
		p2.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p31=new JPanel();
		JPanel p32=new JPanel();
		GridLayout gl2=new GridLayout(2,1);
		p3.setLayout(gl2);
		p3.add(p31);
		p3.add(p32);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p31.add(l2);
		//config panel milieu 2
		GridLayout gl3=new GridLayout(2,3);
		p32.setLayout(gl3);
		JLabel l21=new JLabel("Les coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Les coordonnées du point référentiel 2: ");
		p32.add(l21);
		p32.add(tf1);
		p32.add(tf2);
		p32.add(l22);
		p32.add(tf3);
		p32.add(tf4);
//config panel bas
		p4.add(b1);
		p4.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
	}
//constructeur
	public Rectangle(Point2D pointref){
		super(pointref); 				// on donne une valeur fixe de base au rectangle, il sera possible de la modifier
		Point2D point2 = new Point2D(40,40);	// avec les autres méthodes	
	}
//les fonctions
	public Point2D getPoint2(){
		return point2;
	}
	public void setPoint2(Point2D p){
		this.point2 =p;
	}
	public String afficher(){
	return super.afficher()+"Rectangle [point=" + point2.toString() + "]";
	}   
//les fonctions de l'interface MouseListener		
		public void mouseClicked(MouseEvent e){
			if (e.getSource()==b1) 
			{	
				f1.dispose();
				//f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
				//f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				ObjetDeBase odb=new ObjetDeBase();
				}
			else if (e.getSource()==b2)
			{	//récupérer les coordonnées des 2 points
				f1.dispose();
				try{String str1=tf1.getText();
				String str2=tf2.getText();
				String str3=tf3.getText(); 
				String str4=tf4.getText();
				this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
				this.point2=new Point2D(Integer.parseInt(str3),Integer.parseInt(str4));
				PanelDraw pd = new PanelDraw(this);
				//RectangleDraw rd = new RectangleDraw(this.pointref, this.point2);
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
				catch(Exception ef)
				{
					System.out.println("vous n'avez pas saisi de coordonnées ou vous avez oublié une coordonnée");
				}
			}
		}
		public void mousePressed(MouseEvent ev)
		{
			
		}
		public void mouseReleased(MouseEvent ev)
		{
			
		}
		public void mouseEntered(MouseEvent ev)
		{
			
		}
		public void mouseExited(MouseEvent ev)
		{
			
		}

	
}
