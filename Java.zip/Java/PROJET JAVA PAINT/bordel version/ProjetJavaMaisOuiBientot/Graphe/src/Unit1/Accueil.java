package Unit1;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
//import java.awt.BorderLayout;

public class Accueil implements MouseListener{
	JFrame f1=new JFrame("Mon logiciel de dessin");	
	JButton b1=new JButton("Objet de base");
	JButton b2=new JButton("Objet composite");
	JButton b3=new JButton("Multirectangle");
	JButton b4=new JButton("Multicercle");
	JButton b5=new JButton("Multiellipse");	

	public Accueil() {
//configuration frame 
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
//config panel de font qui contient panels haut, milieu et bas	
		JPanel p1=new JPanel();		//p1:panel des font
		JPanel p2=new JPanel();		//p2:panel haut
		JPanel p3=new JPanel(); 	//p3:panel milieu
		JPanel p4=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1); 
		f1.add(p1);						  	
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
//config panel haut
		//config label pour afficher les messages
		GridLayout gl2=new GridLayout(2,1); 
		JLabel l1=new JLabel("Bienvenu sur notre logiciel de dessin!");
		JLabel l2=new JLabel("Quel type de l'objet voulez-vous cr�er? ");
		p2.setLayout(gl2);
		p2.add(l1);
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.BOTTOM);
		p2.add(l2);
		l2.setHorizontalAlignment(JLabel.LEFT);
		l2.setVerticalAlignment(JLabel.BOTTOM);
//config panel milieu 
		//config gridlayout pour mettre les 5 boutons
		GridLayout gl3=new GridLayout(1,5);
		p3.setLayout(gl3);
		//config button
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		p3.add(b5);
//config panel bas
		//BorderLayout bl1=new BorderLayout();
		//p4.setLayout(bl1);
		//p4.add("North",new JButton("b6"));
		//p4.add("South",new JButton("b7"));
		//p4.add("North",new JButton("b8"));
//config button b1 objet de base
		b1.addMouseListener(this);
		b2.addMouseListener(this);
		b3.addMouseListener(this);
		b4.addMouseListener(this);
		b5.addMouseListener(this);
		
	}
	
	
	
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	ObjetDeBase odb=new ObjetDeBase();
			f1.dispose();}
		else if (e.getSource()==b2) 
		{	//ObjetComposite oc=new ObjetComposite();
			f1.dispose();}
		else if (e.getSource()==b3) 
		{	Multirectangle mr=new Multirectangle();
			f1.dispose();}
		else if (e.getSource()==b4) 
		{	Multicercle mc=new Multicercle();
			f1.dispose();}
		else if (e.getSource()==b5) 
		{	Multiellipse me=new Multiellipse();
			f1.dispose();}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
