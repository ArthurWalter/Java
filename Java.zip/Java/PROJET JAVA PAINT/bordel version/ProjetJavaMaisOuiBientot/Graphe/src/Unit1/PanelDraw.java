package Unit1;

import javax.swing.*;

import Unit1.Rectangle;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;

public class PanelDraw extends JPanel implements MouseListener{
	private int width;
	private int height;
	private int x;
	private int y;
	public ObjetDeBase o;
	private int rayon;
	private int indice;
	private int rayonlong;
    private int rayoncourt;
    
	JFrame f1=new JFrame("Draw");
	JButton b1=new JButton("Retourner");
	JButton b2=new JButton("Enregistrer");
	
	public PanelDraw(Rectangle r) {
	//public RectangleDraw(Point2D pointref, Point2D point2) {	
		//this.o=r;
		indice=1;
		x=r.pointref.getX();
		y=r.pointref.getY();
		width=r.point2.getX()-r.pointref.getX();
		height=r.point2.getY()-r.pointref.getY();
		
		//f2.setContentPane(rd);
		//JFrame f3=new JFrame("RectangleDraw");
		//JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		GridLayout gl=new GridLayout(1,2);
		BorderLayout bl=new BorderLayout();
		f1.setLayout(bl);
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		
		f1.add(p2,bl.NORTH);
		p2.setBackground(Color.LIGHT_GRAY);
		JLabel lrect = new JLabel("Rectangle :");
		p2.add(lrect, BorderLayout.CENTER);
		f1.add(this,bl.CENTER);
		f1.add(p3,bl.SOUTH);
		p3.setLayout(gl);
		
		p3.add(b1);
		p3.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
		
	}
	public PanelDraw(Cercle c) {
		//public RectangleDraw(Point2D pointref, Point2D point2) {	
			//this.o=c;
			indice=2;
			x=c.pointref.getX();
			y=c.pointref.getY();
			rayon=c.getRayon();
			
			//f2.setContentPane(rd);
			//JFrame f3=new JFrame("RectangleDraw");
			//JPanel p1=new JPanel();
			JPanel p2=new JPanel();
			JPanel p3=new JPanel();
			GridLayout gl=new GridLayout(1,2);
			BorderLayout bl=new BorderLayout();
			f1.setLayout(bl);
			f1.setVisible(true);
			f1.setSize(1000,800);
			f1.setLocation(500,100);
			
			f1.add(p2,bl.NORTH);
			p2.setBackground(Color.LIGHT_GRAY);
			JLabel lrect = new JLabel("Cercle :");
			p2.add(lrect, BorderLayout.CENTER);
			f1.add(this,bl.CENTER);
			f1.add(p3,bl.SOUTH);
			p3.setLayout(gl);
			
			p3.add(b1);
			p3.add(b2);
			b1.addMouseListener(this);
			b2.addMouseListener(this);
			
		}
	public PanelDraw(Ellipse e) {
		//public RectangleDraw(Point2D pointref, Point2D point2) {	
			//this.o=c;
			indice=3;
			x=e.pointref.getX();
			y=e.pointref.getY();
			rayonlong=e.getRayonlong();
			rayoncourt=e.getRayoncourt();
			//f2.setContentPane(rd);
			//JFrame f3=new JFrame("RectangleDraw");
			//JPanel p1=new JPanel();
			JPanel p2=new JPanel();
			JPanel p3=new JPanel();
			GridLayout gl=new GridLayout(1,2);
			BorderLayout bl=new BorderLayout();
			f1.setLayout(bl);
			f1.setVisible(true);
			f1.setSize(1000,800);
			f1.setLocation(500,100);
			
			f1.add(p2,bl.NORTH);
			p2.setBackground(Color.LIGHT_GRAY);
			JLabel lrect = new JLabel("Ellipse :");
			p2.add(lrect, BorderLayout.CENTER);
			f1.add(this,bl.CENTER);
			f1.add(p3,bl.SOUTH);
			p3.setLayout(gl);
			
			p3.add(b1);
			p3.add(b2);
			b1.addMouseListener(this);
			b2.addMouseListener(this);
			
		}
	public void paint(Graphics g) {
		Graphics2D g2= (Graphics2D) g;
		if (indice==1){
			g2.drawRect(x,y, width, height);}
		else if (indice==2){
			g2.drawOval(x, y, rayon*2, rayon*2);}
		else if (indice==3){
			g2.drawOval(x, y, rayonlong*2, rayoncourt*2);}
		
		//g2.drawOval(x, y, width, height);
		
	}
//mouse listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	if (indice==1) 
			{	f1.dispose();
				Rectangle r=new Rectangle();}
			else if (indice==2)
			{	f1.dispose();
				Cercle c=new Cercle();}
			else if (indice==3)
			{	f1.dispose();
				Ellipse el=new Ellipse();}
		}
		else if (e.getSource()==b2) 
		{	System.out.println("Il manque la fonction de l'enregistrer");
			//ObjetComposite o�=new ObjetComposite(o);
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
		
			
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
	
	
}
