package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JButton;

public class AccueilPanel extends JPanel implements MouseListener{
	private JPanel pf=new JPanel(); //panel de font
	private JButton bodb=new JButton("Objet de base");	//d'autre panel
	private JButton boc=new JButton("Objet composite");
	private JButton bmr=new JButton("Multirectangle");
	private JButton bmc=new JButton("Multicercle");
	private JButton bme=new JButton("Multiellipse");
	
	public AccueilPanel() {
		Init();
	}
	public void Init() {
		Accueil.Clear();
		Accueil.Add(this.pf);
		JPanel p1=new JPanel();		//p2:panel haut
		JPanel p2=new JPanel(); 	//p3:panel milieu
		JPanel p3=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels 					  	
//		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
//config panel haut et label
		JLabel l1=new JLabel("Bienvenu sur notre logiciel de dessin!");
		JLabel l2=new JLabel("Quel type de l'objet voulez-vous cr��er? ");
		p1.setLayout(new GridLayout(2,1));
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.BOTTOM);
		p1.add(l2);
		l2.setHorizontalAlignment(JLabel.LEFT);
		l2.setVerticalAlignment(JLabel.BOTTOM);
//config panel milieu 
		//config gridlayout pour mettre les 5 boutons
		p2.setLayout(new GridLayout(1,5));
		//config button
		p2.add(bodb);
		p2.add(boc);
		p2.add(bmr);
		p2.add(bmc);
		p2.add(bme);
		bodb.addMouseListener(this);
		boc.addMouseListener(this);
		bmr.addMouseListener(this);
		bmc.addMouseListener(this);
		bme.addMouseListener(this);
	}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bodb) 
		{	Accueil.Clear();
			Accueil.Add(new ObjetDeBase(1));}
		else if (e.getSource()==boc) 
		{	Accueil.Clear();
			Accueil.Add(new ObjetComposite(1));
		}
		else if (e.getSource()==bmr) 
		{	//Accueil.Clear();
			Multirectangle mr=new Multirectangle();
		}
		else if (e.getSource()==bmc) 
		{	//Accueil.Clear();
			Multicercle mc=new Multicercle();
		}
		else if (e.getSource()==bme) 
		{	//Accueil.Clear();
			Multiellipse me=new Multiellipse();
		}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
