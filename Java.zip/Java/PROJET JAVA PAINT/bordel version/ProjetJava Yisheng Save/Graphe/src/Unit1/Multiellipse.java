package Unit1;
import javax.swing.JFrame;

public class Multiellipse {
	
	public Multiellipse(){
		JFrame f1=new JFrame("Multiellipse");
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);

	}
}
