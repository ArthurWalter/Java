package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Graphics;


public class Rectangle extends ObjetDeBase implements MouseListener {
//les attributs	
	public Point2D point2;
	private JPanel pf=new JPanel(); //panel de font
	private JTextField tf1=new JTextField(""); 
	private JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField(""); 
	private JTextField tf4=new JTextField("");
	private JButton b1=new JButton("Retourner"); 
	private JButton b2=new JButton("Afficher");
//constructeur 	
	public Rectangle(){	
		System.out.println("Rectangle");
	}
	public Rectangle(int i) {
		Init();
	}
	public void Init() {
		Accueil.Clear();
		Accueil.Add(this.pf);
//config les 3 panels 	
		JPanel p1=new JPanel();		//p2:panel haut
		JPanel p2=new JPanel(); 	//p3:panel milieu
		JPanel p3=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels						  	
		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
//config panel haut
		//config label
		JLabel l1=new JLabel("Rectangle");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p1.setLayout(bl1);
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p21=new JPanel();
		JPanel p22=new JPanel();
		p2.setLayout(new GridLayout(2,1));
		p2.add(p21);
		p2.add(p22);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p21.add(l2);
		//config panel milieu 2
		p22.setLayout(new GridLayout(2,3));
		JLabel l21=new JLabel("Les coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Les coordonnées du point référentiel 2: ");
		l21.setHorizontalAlignment(JLabel.CENTER);
		l22.setHorizontalAlignment(JLabel.CENTER);
		p22.add(l21);
		p22.add(tf1);
		p22.add(tf2);
		p22.add(l22);
		p22.add(tf3);
		p22.add(tf4);
//config panel bas
		p3.add(b1);
		p3.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
	}
//constructeur
	public Rectangle(Point2D pointref){
		super(pointref); 				// on donne une valeur fixe de base au rectangle, il sera possible de la modifier
		Point2D point2 = new Point2D(40,40);	// avec les autres méthodes	
	}
//les fonctions
	public Point2D getPoint2(){
		return point2;
	}
	public void setPoint2(Point2D p){
		this.point2 =p;
	}
//	public String afficher(){
//	return super.afficher()+"Rectangle [point=" + point2.toString() + "]";
//	}   
@Override
	public String toString() {
		return "Rectangle [pointref="+pointref+
				", point2="+point2 + "]";
	}
	//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	
			Accueil.Clear();
			Accueil.Add(new ObjetDeBase(1));
		}
		else if (e.getSource()==b2)
		{	//récupérer les coordonnées des 2 points
			try{String str1=tf1.getText();
			String str2=tf2.getText();
			String str3=tf3.getText(); 
			String str4=tf4.getText();
			this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
			this.point2=new Point2D(Integer.parseInt(str3),Integer.parseInt(str4));
			PanelDraw pd=new PanelDraw(this);
		}
			catch(Exception ef)
			{
				System.out.println("vous n'avez pas saisi de coordonnées ou vous avez oublié une coordonnée");
			}
		}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
