package Unit1;

public class Point2D {
	protected int x;
    protected int y;
//constructeur    
    public Point2D () {
		x=0;
		y=0;
    }
    public Point2D (int a) {
		x=a;
		y=0;
    } 
    public Point2D (int a,int b) {
		x=a;
		y=b;      
    }
	public Point2D (Point2D p) {
		x=p.getX();
		y=p.getY();
	}
//getters and setters
	public int getX() {
			return x;
	}
	public void setX(int x) {
			this.x = x;
	}
	public int getY() {
			return y;
	}
	public void setY(int y) {
			this.y = y;
	}
//afficher
	@Override
	public String toString() {
		return "Point2D [x="+ x +", y="+ y +"]"; // permettra d'afficher les points des autres objets
	}		
}
