package Unit1;
import javax.swing.JFrame;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class Gestion implements ListSelectionListener{
	private JPanel p1 = new JPanel();
	private DefaultListModel<String> dlm=new DefaultListModel<String>();
	private JList<String> list=new JList<String>(dlm);
	
	//private DefaultListModel ListObjComposite = new DefaultListModel();
	//private JList list_objcompo = new JList(ListObjComposite);
	//private JScrollPane scroll_objcompo =new JScrollPane(list_objcompo);
	private ObjetDeBase odb;
	
	public Gestion(ObjetDeBase o){
		this.odb=o;
//config frame		
		JFrame f1=new JFrame("Gestion");
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
//config DefaultListModel
		add(o);
//		list=new JList<>(dlm);
		f1.add(list);
		
		list.addListSelectionListener(this);
		//al.add(o);
		
		}
	public void AfficherObj(ListSelectionEvent e) {	
		if(!e.getValueIsAdjusting()){
		 System.out.println(list.getSelectedValue()); 
		 // pas sûre pour ça, faudrait faire en sorte													// d'afficher les coordonnées de l'objet dans la console.
		}
	}
	public void add(ObjetDeBase o){
		//al.add(o);
//		dlm.addElement(o.afficher());
	}
	public void afficher(ObjetDeBase o){
//		o.afficher();
	}
	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		if(!arg0.getValueIsAdjusting()){
		PanelDraw pd=new PanelDraw(odb);
		}
	}
}	