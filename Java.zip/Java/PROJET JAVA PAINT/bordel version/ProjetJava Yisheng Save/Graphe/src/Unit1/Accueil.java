package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Accueil{
	public static JFrame f1=new JFrame("Accueil");
	private static JPanel pc=new JPanel();	//pc:panel centre o� on met 
	private static JPanel pd=new JPanel(); 	//pd:panel droit		
	public Accueil(){
//configuration frame 
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		f1.setExtendedState(f1.MAXIMIZED_BOTH);	
		f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
//config panel de font qui contient panels haut, centre, droit et bas	
		//config BorderLayout pour mettre les panels en ordre
		JPanel ph=new JPanel();		//ph:panel haut

		JPanel pb=new JPanel();		//pb:panel bas
		BorderLayout bl=new BorderLayout();
		f1.setLayout(bl);
		//config panel haut
		f1.add(ph,BorderLayout.NORTH);
		ph.setPreferredSize(new Dimension(100,130));//Les 100 ne sont pas utiles
		ph.setBackground(Color.PINK);
		//config panel centre
		f1.add(pc,BorderLayout.CENTER);
		pc.setPreferredSize(new Dimension(100,100));
//		pc.setBackground(Color.BLACK);
		//config panel droit					
		f1.add(pd, BorderLayout.EAST);
		pd.setPreferredSize(new Dimension(350,100));
//		pd.setBackground(Color.GREEN);
		//config panel bas
		f1.add(pb, BorderLayout.SOUTH);
		pb.setPreferredSize(new Dimension(100,130));
		pb.setBackground(Color.PINK);
		//appeler les panels d'autres classes
		Add(new AccueilPanel());
		Add(new Gest());
	}

	
//clear pour enlever le panel actuel dans le panel centre 
	public static void Clear(){
		pc.removeAll(); 	//supprimer le panel
	}
	public static void Add(JPanel p){
		pc.revalidate();	//re-valider /re-afficher le panel
		pc.repaint();		//re-dessiner 
		p.setPreferredSize(new Dimension(1570,735));//� convenir
		pc.add(p);
	}
	public static void ClearAdd2(JPanel p) {
		pd.removeAll();
		pd.revalidate();	//re-valider /re-afficher le panel
		pd.repaint();		//re-dessiner 
		p.setPreferredSize(new Dimension(350,735));//� convenir
		pd.add(p);
	}
}
