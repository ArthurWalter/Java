package Unit1;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;
import java.awt.Graphics;
import java.lang.Object;
//import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Accueil a=new Accueil();
		//ObjetDeBase odb=new ObjetDeBase();
		//Rectangle r=new Rectangle();
		//Cercle c=new Cercle();
		//Ellipse e=new Ellipse();
		//Quadrilatere q=new Quadrilatere();
//		Scanner s=new Scanner(System.in);
//		System.out.println("taper 1 pour exit");
//		int nb=s.nextInt();
//		System.exit(0);
	}
	

}



