package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;

public class ObjetDeBase implements MouseListener{
	protected Point2D pointref;
	
	public JFrame f1=new JFrame("Objet de base");
	private JButton b1=new JButton("Rectangle");
	private JButton b2=new JButton("Cercle");
	private JButton b3=new JButton("Ellipse");
	private JButton b4=new JButton("Quadrilatere");
	private JButton b5=new JButton("Retourner");
	
//constructeur
	public ObjetDeBase(){
		
		pointref = new Point2D(0,0);
	//configuration frame
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		
	//config panel de font qui contient panels haut, milieu et bas
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		f1.add(p1);
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1);
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
	//config panel haut et label
		JLabel l1=new JLabel("Quel type de l'objet de base voulez-vous cr�er?");
		BorderLayout bl1=new BorderLayout();
		p2.setLayout(bl1);
		p2.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);	
	//config panel milieu
		//config oridlayout pour mettre les 4 boutons
		GridLayout gl2=new GridLayout(1,4);
		p3.setLayout(gl2);
		p3.add(b1);
		p3.add(b2);
		p3.add(b3);
		p3.add(b4);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
		b3.addMouseListener(this);
		b4.addMouseListener(this);
	//config panel bas
		p4.add(b5);
		b5.addMouseListener(this);
	}	
		public ObjetDeBase (Point2D x) {
			//ObjetDeBase o=new ObjetDeBase();
			this.pointref=x;
		}
//les fonctions
		public Point2D getpointref() {
			return pointref;
		}
		public void setpointref(Point2D p) {
			this.pointref = p;
		}
		public String afficher() {
			return "ObjetDeBase [pointref=" + pointref.getX() +"," +pointref.getY() +"]";
		}
//mouse listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	f1.dispose();
			Rectangle r=new Rectangle();
			//f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		else if (e.getSource()==b2) 
		{	Cercle c=new Cercle();
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
		else if (e.getSource()==b3) 
		{	Ellipse el=new Ellipse();
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
		else if (e.getSource()==b4) 
		{	Quadrilatere q=new Quadrilatere();
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
		else if (e.getSource()==b5) 
		{	Accueil a=new Accueil();
			f1.dispose();
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
			
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
