package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

public class Accueil  /*implements MouseListener*/{
	
	public Accueil(){
//configuration frame 
		JFrame f1=new JFrame("Accueil");
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		f1.setExtendedState(f1.MAXIMIZED_BOTH);	
//config panel de font qui contient panels haut, centre, droit et bas	
		JPanel ph=new JPanel();		//ph:panel haut
		JPanel pc=new JPanel();		//pc:panel centre
		JPanel pd=new JPanel(); 	//pd:panel droit
		JPanel pb=new JPanel();		//pb:panel bas
		//config BorderLayout pour mettre les panels en ordre
		BorderLayout bl=new BorderLayout();
		f1.setLayout(bl);
		//config panel haut
		f1.add(ph,BorderLayout.NORTH);
		ph.setPreferredSize(new Dimension(100,130));
		ph.setBackground(Color.WHITE);
		//config panel centre
		f1.add(pc,BorderLayout.CENTER);
		pc.setPreferredSize(new Dimension(100,100));
		pc.setBackground(Color.BLACK);
		//config panel droit											//Les 100 ne sont pas utiles
		f1.add(pd, BorderLayout.EAST);
		pd.setPreferredSize(new Dimension(350,100));
		pd.setBackground(Color.GREEN);
		//config panel bas
		f1.add(pb, BorderLayout.SOUTH);
		pb.setPreferredSize(new Dimension(100,130));
		pb.setBackground(Color.PINK);
		
		
	}

//Mouse Listener	
/*	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	ObjetDeBase odb=new ObjetDeBase();
			this.dispose();}
		else if (e.getSource()==b2) 
		{	//ObjetComposite oc=new ObjetComposite();
			this.dispose();}
		else if (e.getSource()==b3) 
		{	Multirectangle mr=new Multirectangle();
			this.dispose();}
		else if (e.getSource()==b4) 
		{	Multicercle mc=new Multicercle();
			this.dispose();}
		else if (e.getSource()==b5) 
		{	Multiellipse me=new Multiellipse();
			this.dispose();}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}*/
}
