package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;


public class Quadrilatere extends ObjetDeBase implements MouseListener{
//les attributs	
	private Point2D point2;
    private Point2D point3;
    private Point2D point4;
    private JFrame f1=new JFrame("Quadrilatere");
	private JTextField tf1=new JTextField(""); 
	private JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField(""); 
	private JTextField tf4=new JTextField("");
	private JTextField tf5=new JTextField(""); 
	private JTextField tf6=new JTextField("");
	private JTextField tf7=new JTextField(""); 
	private JTextField tf8=new JTextField("");
	private JButton b1=new JButton("Retourner"); 
	private JButton b2=new JButton("Afficher");
//constructeur	
	public Quadrilatere(){
		super.f1.dispose();
		f1.setVisible(true);
		f1.setSize(500,500);
		f1.setLocation(1000,200);
		pointref = new Point2D(0,0);
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		JPanel p1=new JPanel();		//p1:panel des font
		JPanel p2=new JPanel();		//p2:panel haut
		JPanel p3=new JPanel(); 	//p3:panel milieu
		JPanel p4=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels
		GridLayout gl1=new GridLayout(3,1); 
		f1.add(p1);						  	
		p1.setLayout(gl1);
		p1.add(p2);
		p1.add(p3);
		p1.add(p4);
//config panel haut
		//config label
		JLabel l1=new JLabel("Quadrilatere");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p2.setLayout(bl1);
		p2.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p31=new JPanel();
		JPanel p32=new JPanel();
		GridLayout gl2=new GridLayout(2,1);
		p3.setLayout(gl2);
		p3.add(p31);
		p3.add(p32);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les param�tres: ");
		p31.add(l2);
		//config panel milieu 2
		GridLayout gl3=new GridLayout(4,3);
		p32.setLayout(gl3);
		JLabel l21=new JLabel("Coordonn�es du point r�f�rentiel: ");
		JLabel l22=new JLabel("Coordonn�es du point 2: ");
		JLabel l23=new JLabel("Coordonn�es du point 3: ");
		JLabel l24=new JLabel("Coordonn�es du point 4: ");
		p32.add(l21);
		p32.add(tf1);
		p32.add(tf2);
		p32.add(l22);
		p32.add(tf3);
		p32.add(tf4);
		p32.add(l23);
		p32.add(tf5);
		p32.add(tf6);
		p32.add(l24);
		p32.add(tf7);
		p32.add(tf8);
		
//config panel bas
		p4.add(b1);
		p4.add(b2);
		b1.addMouseListener(this);
		b2.addMouseListener(this);
	}	
	public Quadrilatere(Point2D pointref){
		super(pointref); 				// on donne une valeur fixe de base au Quadrilatere, il sera possible de la modifier
		point2 = new Point2D(40,40); 
		point3 = new Point2D(60,60); 
		point4 = new Point2D(80,80); 	// avec les autres m��thodes	
	}	
	public Quadrilatere (Point2D pointref, Point2D p1,Point2D p2,Point2D p3){
			super(pointref);
			point2=p1;    
			point3=p2;    
			point4=p3;    
	}
	public Quadrilatere (Quadrilatere q){
			super(q.pointref);
			this.point2=q.point2;
			this.point3=q.point3;
			this.point4=q.point4;
	}
	
//les fonctions
	public Point2D getPoint2(){
			return point2;
	}
	public Point2D getPoint3(){
			return point3;
	}
	public Point2D getPoint4(){
		return point4;
	}
	public void setPoint2(Point2D p2){
			this.point2 =p2;
	}
	public void setPoint3(Point2D p3){
			this.point3=p3;
	}
	public void setPoint4(Point2D p4){
		this.point4 =p4;
	}
	public String afficher(){
		return super.afficher()+"Quadrilatere [ point1=" + point2.toString() +point2+" + point3.toString() +point3=" +
		point4.toString() + "]";
	} 
//mouse listener	
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	
			f1.dispose();
			//f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
			//f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			ObjetDeBase odb=new ObjetDeBase();
			}
		else if (e.getSource()==b2)
		{	//r�cup�rer les coordonn�es des 2 points
			f1.dispose();
			try{String str1=tf1.getText();
			String str2=tf2.getText();
			String str3=tf3.getText(); 
			String str4=tf4.getText();
			String str5=tf5.getText();
			String str6=tf6.getText();
			String str7=tf7.getText(); 
			String str8=tf8.getText();
			this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
			this.point2=new Point2D(Integer.parseInt(str3),Integer.parseInt(str4));
			this.point3=new Point2D(Integer.parseInt(str5),Integer.parseInt(str6));
			this.point4=new Point2D(Integer.parseInt(str7),Integer.parseInt(str8));
			PanelDraw pd = new PanelDraw(this);
			
			//RectangleDraw rd = new RectangleDraw(this.pointref, this.point2);
			f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);}
			catch(Exception ef)
			{
				System.out.println("vous n'avez pas saisi de coordonn�es ou vous avez oubli� une coordonn�e");
			}
		}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
}
