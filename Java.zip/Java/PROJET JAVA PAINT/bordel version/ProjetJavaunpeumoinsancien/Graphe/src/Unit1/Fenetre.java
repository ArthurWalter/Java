package Unit1;

import javax.swing.JFrame;

public class Fenetre {

	public Fenetre(Point2D pointref, Point2D point2) {
		JFrame f1=new JFrame("Rectangle");
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		f1.setContentPane(new RectangleDraw(pointref, point2));
		
	}
}
