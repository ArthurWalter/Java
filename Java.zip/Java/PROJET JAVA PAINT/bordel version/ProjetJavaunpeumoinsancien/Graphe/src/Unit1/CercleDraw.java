package Unit1;

import javax.swing.*;

import Unit1.Rectangle;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.*;

public class RectangleDraw extends JPanel implements MouseListener{
	private int rayon;
	private int x;
	private int y;
	JFrame f1=new JFrame("CercleDraw");
	JButton b1=new JButton("Retourner");
	JButton b2=new JButton("Enregistrer");
	
	public RectangleDraw(Point2D pointref, Point2D point2) {
		
		x=pointref.getX();
		y=pointref.getY();
		rayon=point2.getX();
		rayon=point2.getY();
		
		//f2.setContentPane(rd);
		//JFrame f3=new JFrame("RectangleDraw");
		//JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		GridLayout gl=new GridLayout(1,2);
		BorderLayout bl=new BorderLayout();
		f1.setLayout(bl);
		f1.setVisible(true);
		f1.setSize(1000,800);
		f1.setLocation(500,100);
		
		f1.add(p2,bl.NORTH);
		p2.setBackground(Color.LIGHT_GRAY);
		JLabel lrect = new JLabel("Cercle :");
		p2.add(lrect, BorderLayout.CENTER);
		f1.add(this,bl.CENTER);
		f1.add(p3,bl.SOUTH);
		p3.setLayout(gl);
		
		p3.add(b1);
		p3.add(b2);
		
		
	}

	public void paint(Graphics g) {
		
		Graphics2D g2= (Graphics2D) g;
		g2.drawOval(x,y, rayon, rayon);
		
	}
//mouse listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==b1) 
		{	f1.dispose();
			Cercle c=new Cercle();}
		else if (e.getSource()==b2) 
		{	f1.dispose();}
	}
	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
	
	
}
