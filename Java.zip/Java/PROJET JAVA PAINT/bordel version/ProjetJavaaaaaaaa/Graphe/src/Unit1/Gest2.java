package Unit1;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Gest2 implements MouseListener, ListSelectionListener{
	private JPanel pf=new JPanel();
	private DefaultListModel<String> dlm=new DefaultListModel();
	private JList<String> list =new JList<String>(dlm); 	//list	
	private JScrollPane sp=new JScrollPane(list);//construire avec le composant 
	private JButton bremove=new JButton("Supprimer"); 
	private JButton bafficher=new JButton("Afficher");
	
	public Gest2() {
		Init();
	}
	public void Init() {
		Accueil.ClearAdd2(pf);
		//config gridlayout pour ranger les trois panels 	
		pf.setLayout(new BorderLayout());
		JPanel p1=new JPanel(); //panel haut
		JPanel p2=new JPanel(); //panel milieu
		JPanel p3=new JPanel(); //panel bas
		pf.add(p1,BorderLayout.NORTH);
		pf.add(p2,BorderLayout.CENTER);
		pf.add(p3,BorderLayout.SOUTH);
		//panel haut
		JLabel l1=new JLabel("List des Objets");
		p1.add(l1);
		//panel milieu
		p2.setLayout(new BorderLayout());
		p2.add(sp,BorderLayout.CENTER);
		//panel bas
		p3.add(bremove);
		p3.add(bafficher);
		bremove.addMouseListener(this);
		bafficher.addMouseListener(this);
		list.addListSelectionListener(this);
	}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bremove) 
		{
//				int i=list.getLeadSelectionIndex();
//				dlm.remove(i);
			System.out.println("222");
			dlm.removeElementAt(list.getLeadSelectionIndex());
//				pf.revalidate();
//				pf.repaint();
		}
		else if (e.getSource()==bafficher) {
			System.out.println("333");
//				Accueil.Clear();
//				AccueiL.Add(new PanelDraw());
		}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
//ListSelection Listener	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(!e.getValueIsAdjusting())
		{
			System.out.println("s��lection��");
		}
		
	}
}
