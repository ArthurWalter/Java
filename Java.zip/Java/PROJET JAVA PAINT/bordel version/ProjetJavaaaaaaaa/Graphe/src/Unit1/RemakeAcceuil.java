package Unit1;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class RemakeAcceuil extends Objet implements MouseListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Point2D pointref;
	private JPanel pn=new JPanel(); //panel de font
	private JButton br=new JButton("Rectangle");
	private JButton bc=new JButton("Cercle");
	private JButton be=new JButton("Ellipse");
	private JButton bq=new JButton("Quadrilatere");
	
//constructeur principal
	public RemakeAcceuil(){
		pointref = new Point2D(0,0);
	}
	public RemakeAcceuil(int i) {
		Init();
	}
	public void Init() {
		Accueil.Add(pn);
	//config les 3 panels
		JPanel p1=new JPanel();	//panel haut
		JPanel p2=new JPanel(); //panel milieu
		JPanel p3=new JPanel(); //panel bas
		//config gridlayout pour ranger les trois panels
		this.add(pn);
		pn.setLayout(new GridLayout(3,1));
		pn.add(p1);
		pn.add(p2);
		pn.add(p3);
	//config panel haut et label
		JLabel l1=new JLabel("Quel type de l'objet de base voulez-vous cr��er?");
		BorderLayout bl1=new BorderLayout();
		p1.setLayout(bl1);
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);	
	//config panel milieu
		//config oridlayout pour mettre les 4 boutons
		p2.setLayout(new GridLayout(1,4));
		p2.add(br);
		p2.add(bc);
		p2.add(be);
		p2.add(bq);
		br.addMouseListener(this);
		bc.addMouseListener(this);
		be.addMouseListener(this);
		bq.addMouseListener(this);
	//config panel bas
		
	}
//constructeur
		public RemakeAcceuil (Point2D x) {
			//ObjetDeBase o=new ObjetDeBase();
			this.pointref=x;
		}
//les fonctions
		public Point2D getpointref() {
			return pointref;
		}
		public void setpointref(Point2D p) {
			this.pointref = p;
		}		
@Override
		public String toString() {
			return "ObjetDeBase [pointref=" + pointref + "]";
		}
	//Mouse Listener
			
public void mouseClicked1(MouseEvent e){
	if (e.getSource()==br) 
	{	
		Accueil.Add(new Rectangle(1));
		}
	else if (e.getSource()==bc) 
	{	
		Accueil.Add(new Cercle(1));
		}
	else if (e.getSource()==be) 
	{	
		Accueil.Add(new Ellipse(1));
		}
	else if (e.getSource()==bq) 
	{	
		Accueil.Add(new Quadrilatere(1));
		}
		
}

	public void mousePressed(MouseEvent ev)
	{
		
	}
	public void mouseReleased(MouseEvent ev)
	{
		
	}
	public void mouseEntered(MouseEvent ev)
	{
		
	}
	public void mouseExited(MouseEvent ev)
	{
		
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
