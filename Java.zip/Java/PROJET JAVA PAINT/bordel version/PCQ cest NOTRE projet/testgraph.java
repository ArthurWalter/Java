import javax.swing.JFrame;
import javax.swing.Jpanel;

public class RectDraw extends JFrame {
	private JPanel Graphics2D;
	
	
	public RectDraw() {
		Graphics2D g= new Jpanel();		
	}

}



public void mouseClicked(MouseEvent e){
			if (e.getSource()==b1) 
			{	
				f1.dispose();
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				ObjetDeBase odb=new ObjetDeBase();
				}
			else if (e.getSource()==b2) 
			{	String str1;	String str2;
				String[] firstArray=tf1.getText().split(";",2);				//);//;			
				
				this.pointref=new Point2D(Integer.parseInt(firstArray[0]),Integer.parseInt(firstArray[1]));
				String[] secondArray=tf1.getText().split(";",2);				//);//;			
				
				this.point2=new Point2D(Integer.parseInt(secondArray[0]),Integer.parseInt(secondArray[1]));
				RectDraw rd = new RectDraw();
				g.getGraphics().DrawRect(firstArray[0],firstArray[1],secondArray[0],secondArray[1]);
				rd.setVisible(true);
				
				
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}