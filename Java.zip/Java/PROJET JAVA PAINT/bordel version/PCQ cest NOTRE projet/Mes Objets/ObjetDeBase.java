package PROJET;

public class ObjetDeBase{
        protected Point2D pointref;
        
			public ObjetDeBase() {
				pointref = new Point2D(0,0);
			}
			
			public ObjetDeBase (Point2D x) {
				pointref=x;
			}

			public ObjetDeBase (ObjetDeBase o) {
				this.pointref=o.pointref;
			}


			public Point2D getpointref() {
				return pointref;
			}

			public void setpointref(Point2D p) {
				this.pointref = p;
			}

			public String afficher() {
				return "ObjetDeBase [pointref=" + pointref.getX() +"," +pointref.getY() +"]";
			}
	}