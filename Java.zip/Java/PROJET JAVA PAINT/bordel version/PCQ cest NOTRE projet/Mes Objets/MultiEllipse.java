package PROJET;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MultiEllipse extends ObjetDeBase{

	private ArrayList<Ellipse> E;
	private JPanel pnl_liste_mell = new JPanel(); 
	private DefaultListModel listMultiellipse = new DefaultListModel(); //Multiseg = Multirec
	private JList list_multiellipse = new JList(listMulticercle);
	private JScrollPane scroll_multiellipse =new JScrollPane(list_multiellipse);
	
		public MultiEllipse(){
			pointref = new Point2D(0,0);
			E=new ArrayList<Ellipse>();
			scroll_multiellipse.setPreferredSize(new Dimension(250,120));
			list_multiellipse.setPreferredSize(new Dimension(220,5000));
		}
		
		public MultiEllipse(Point2D pointref){
			super(pointref);
			E=new ArrayList<Ellipse>();
			scroll_multiellipse.setPreferredSize(new Dimension(250,120));
			list_multiellipse.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mell.add(scroll_multiellipse); 
		}
		
		public MultiEllipse (MultiEllipse Me){
			this.pointref=Me.pointref;
			this.E=Me.E;
			scroll_multiellipse.setPreferredSize(new Dimension(250,120));
			list_multiellipse.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mell.add(scroll_multiellipse);
		}
		
		public ArrayList<Ellipse> getE(){
			return E;
		}

		public void setC(ArrayList<Ellipse> ell){
			E = ell;
		}
		
		public JPanel getList_multiEllipse(){
			return list_multiellipse;
		}

		public void setPnl_liste_mrec(JPanel listMultiellipse){
			this.list_multiellipse = listMultiellipse;
		}

		public DefaultListModel getListMultiell(){
			return list_multiellipse;
		}

		public void setlistMultiellipse(DefaultListModel listMultiellipse){
			list_multiellipse = listMultiellipse;
		}

		public JList getlist_multiEllipse() {
			return list_multiellipse;
		}

		public void setlist_multiEllipse(JList pnl_liste_mell){
			this.pnl_liste_mell = pnl_liste_mell;
		}

		public JScrollPane getscroll_multiellipse(){
			return scroll_multiellipse;
		}

		public void setscroll_multiellipse(JScrollPane scroll_multiellipse){
			this.scroll_multiellipse = scroll_multiellipse;
		}

		public String toString(){
			return super.toString() +"MultiEllipse [E=" + E + "]";
		}
		
		public void ajouter(Ellipse e){
			E.add(e);
		}
		
		public void supprimer(Ellipse e){
			E.remove(e);
		}
		
		public int nbcomp(){
			return this.getE().size();
		}
	}
