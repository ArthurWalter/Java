package PROJET;

public class Ellipse extends ObjetDeBase {
        private int ralonlong;
        private int rayoncourt;
        
			public Ellipse(){
					pointref = new Point2D(0,0);
					pointref2 = new Point2D(0,0);
					
					ralonlong=4;
					rayoncourt=4;
			}

			public Ellipse(Point2D pointref){
					super(pointref,pointref2);
					ralonlong=4;
					rayoncourt=4;			// on donne une valeur fixe de base au cercle, il sera possible de la modifier
			}						    // avec les autres m�thodes
			
			public Ellipse(Point2D pointref,int r1, int r2){
					super(pointref,pointref2);
					rayonlong=r1;
					rayoncourt=r2;
			}
			
			public Cercle(Cercle c){
					super(c);
					this.rayonlong = c.rayonlong;
					this.rayoncourt = c.rayoncourt;
			}
			
			 public int getRayonlong(){
					return ralonlong;
			}
			
			 public int getRayoncourt(){
					return raloncourt;
			}

			public void setRayonlong(int r){
					this.ralonlong = r;
			}
			public void setRayoncourt(int r){
					this.raloncourt = r;
			}
			
			public String afficher(){
				return super.afficher() +"Cercle [ premier rayon=" +rayonlong +"deuxieme rayon=" +rayoncourt + "]"; 
			}
	}
