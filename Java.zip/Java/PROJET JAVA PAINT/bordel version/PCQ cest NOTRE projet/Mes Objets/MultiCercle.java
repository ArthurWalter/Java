package PROJET;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MultiRectangle extends ObjetDeBase{

	private ArrayList<Cercle> C;
	private JPanel pnl_liste_mrec = new JPanel(); 
	private DefaultListModel listMulticercle = new DefaultListModel(); 
	private JList list_multicercle = new JList(listMulticercle);
	private JScrollPane scroll_multicercle =new JScrollPane(list_multiCercle);
	
		public MultiCercle (){
			pointref = new Point2D(0,0);
			C=new ArrayList<Cercle>();
			scroll_multicercle.setPreferredSize(new Dimension(250,120));
			list_multicercle.setPreferredSize(new Dimension(220,5000));
		}
		
		public MultiCercle(Point2D pointref){
			super(pointref);
			C=new ArrayList<Cercle>();
			scroll_multicercle.setPreferredSize(new Dimension(250,120));
			list_multicercle.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mrec.add(scroll_multicercle);
		}
		
		public MultiCercle (MultiCercle Ce){
			this.pointref=Ce.pointref;
			this.C=Ce.C;
			scroll_multicercle.setPreferredSize(new Dimension(250,120));
			list_multicercle.setPreferredSize(new Dimension(220,5000));
			pnl_liste_mrec.add(scroll_multicercle);
		}
		
		public ArrayList<Cercle> getC(){
			return C;
		}

		public void setC(ArrayList<Cercle> cer){
			C = cer;
		}
		
		public JPanel getList_multiCercle(){
			return list_multicercle;
		}

		public void setPnl_liste_mcer(JPanel list_multicercle){
			this.list_multicercle = list_multicercle;
		}

		public DefaultListModel getListMulticer(){
			return list_multicercle;
		}

		public void setlistMulticercle(DefaultListModel listMulticercle){
			list_multicercle = listMulticercle;
		}

		public JList getlist_multiCercle() {
			return list_multicercle;
		}

		public void setlist_multiCercle(JList pnl_liste_cercle){
			this.pnl_liste_cercle = pnl_liste_cercle;
		}

		public JScrollPane getscroll_multicercle(){
			return scroll_multicercle;
		}

		public void setscroll_multicercle(JScrollPane scroll_multicercle){
			this.scroll_multicercle = scroll_multicercle;
		}

		public String toString(){
			return super.toString() +"MultiCercle [C=" + C + "]";
		}
		
		public void ajouter(Cercle c){
			C.add(c);
		}
		
		public void supprimer(Cercle c){
			C.remove(c);
		}
		
		public int nbcomp(){
			return this.getC().size();
		}
	}
