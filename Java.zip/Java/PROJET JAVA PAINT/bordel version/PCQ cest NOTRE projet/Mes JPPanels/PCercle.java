package Panels;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelCercle extends JPanel{

	private JPanel PnlEdtCercle= new JPanel();
	private JLabel LblRayonCercle= new JLabel ("Saisir un rayon : ");
	private JTextField EdtRayonCercle= new JTextField(20);

		public PanelCercle(){
			PnlEdtCercle.setPreferredSize(new Dimension("JSAIPAS","JSAIPAS"));
			PnlEdtCercle.add(LblRayonCercle);
			PnlEdtCercle.add(edt_rayon_cercle);
			this.add(PnlEdtCercle);	
		}

		public JPanel getPnl_edt_cercle(){
			return PnlEdtCercle;
		}

		public void setPnl_edt_cercle(JPanel PnlEdtCercle){
			this.PnlEdtCercle = PnlEdtCercle;
		}

		public JLabel getLblRayonCercle(){
			return LblRayonCercle;
		}

		public void setLbl_rayon_cercle(JLabel LblRayonCercle){
			this.LblRayonCercle = LblRayonCercle;
		}

		public JTextField getEdtRayonCercle(){
			return EdtRayonCercle;
		}

		public void setEdtRayonCercle(JTextField EdtRayonCercle){
			this.EdtRayonCercle = EdtRayonCercle;
		}
		
	}
