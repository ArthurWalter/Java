package Panels;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelRect extends JPanel{

	private JPanel PnlEdtRect = new JPanel();
	private JLabel lblPointRect = new JLabel ("Saisir un point : ");
	private JTextField EdtPointRect = new JTextField(15);//edt de rectangle
	
		public PanelRect(){
			PnlEdtRect.setPreferredSize(new Dimension("JSAIPAS","JSAIPAS"));
			PnlEdtRect.add(lblPointRect);
			PnlEdtRect.add(EdtPointRect);
			this.add(PnlEdtRect);
		}

		public JPanel getPnlEdtRect(){
			return PnlEdtRect;
		}

		public JLabel getLbl_point_rect(){
			return lblPointRect;
		}

		public void setLbl_point_rect(JLabel lblPointRect){
			this.lblPointRect = lblPointRect;
		}

		public JTextField getEdt_point_rect() {
			return EdtPointRect;
		}

		public void setEdt_point_rect(JTextField EdtPointRect){
			this.EdtPointRect = EdtPointRect;
		}

		public void setPnlEdtRect(JPanel PnlEdtRect){
			this.PnlEdtRect = PnlEdtRect;
		}
		
	}
