package Panels;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelVect extends JPanel{

	private JPanel PnlEdtVect = new JPanel();
	private JLabel LblPointVect = new JLabel ("Saisir un point : ");
	private JTextField EdtPointVect = new JTextField(15);
	
		public PanelVect(){
			PnlEdtVect.setPreferredSize(new Dimension("JSAIPAS","JSAIPAS"));
			PnlEdtVect.add(LblPointVect);
			PnlEdtVect.add(EdtPointVect);
			this.add(PnlEdtVect);	
		}
		
		public JPanel getPnlEdtVect(){
			return PnlEdtVect;
		}
		
		public void setPnlEdtVect(JPanel PnlEdtVect){
			this.PnlEdtVect = PnlEdtVect;
		}
		
		public JLabel getLblPointVect(){
			return LblPointVect;
		}
		
		public void setLblPointVect(JLabel LblPointVect){
			this.LblPointVect = LblPointVect;
		}
		
		public JTextField getEdtPointVect(){
			return EdtPointVect;
		}
		
		public void setEdtPointVect(JTextField EdtPointVect){
			this.EdtPointVect = EdtPointVect;
		}
		
	}
