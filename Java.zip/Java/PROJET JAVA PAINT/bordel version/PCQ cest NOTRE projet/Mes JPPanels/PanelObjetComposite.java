package Panels;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
public class PanelObjetComposite extends JPanel{
	
	private JPanel pnl_liste_objcompo = new JPanel();
	private ImageIcon IconRectangle = new ImageIcon(this.getClass().getResource("../MesImages/rectangle.png" ));
	private JButton BtnRectangle = new JButton(IconRectangle);
	private ImageIcon IconCercle = new ImageIcon(this.getClass().getResource("../MesImages/cercle.png"));
	private JButton BtnCercle = new JButton(IconCercle);
	private ImageIcon IconVecteur = new ImageIcon(this.getClass().getResource("../MesImages/vecteur.png"));
	private JButton BtnEllipse = new JButton(IconEllipse);
	private ImageIcon IconEllipse = new ImageIcon(this.getClass().getResource("../MesImages/ellipse.png"));
	private JButton BtnVecteur = new JButton(IconVecteur);
	
		public PanelComposite(){
			BtnRectangle.setToolTipText("Cliquez pour cr�er un rectangle.");
			BtnCercle.setToolTipText("Cliquez pour cr�er un cercle.");
			BtnEllipse.setToolTipText("Cliquez pour cr�er un triangle.");
			BtnVecteur.setToolTipText("Cliquez pour cr�er un segment.");
			this.add(BtnRectangle);
			this.add(BtnCercle);
			this.add(BtnEllipse);
			this.add(BtnVecteur);
			this.add(pnl_liste_objcompo);
		}



		public JPanel getPnl_liste_objcompo(){
			return pnl_liste_objcompo;
		}



		public void setPnl_liste_objcompo(JPanel pnl_liste_objcompo) {
			this.pnl_liste_objcompo = pnl_liste_objcompo;
		}



		public ImageIcon getIconRectangle() {
			return IconRectangle;
		}



		public void setIconRectangle(ImageIcon iconRectangle) {
			IconRectangle = iconRectangle;
		}



		public JButton getBtnRectangle() {
			return BtnRectangle;
		}



		public void setBtnRectangle(JButton btnRectangle) {
			BtnRectangle = btnRectangle;
		}



		public ImageIcon getIconCercle() {
			return IconCercle;
		}



		public void setIconCercle(ImageIcon iconCercle) {
			IconCercle = iconCercle;
		}



		public JButton getBtnCercle() {
			return BtnCercle;
		}



		public void setBtnCercle(JButton btnCercle) {
			BtnCercle = btnCercle;
		}



		public ImageIcon getIconVecteur() {
			return IconVecteur;
		}



		public void setIconVecteur(ImageIcon iconVecteur) {
			IconVecteur = iconVecteur;
		}



		public JButton getBtnEllipse() {
			return BtnEllipse;
		}



		public void setBtnEllipse(JButton btnEllipse) {
			BtnEllipse = btnEllipse;
		}



		public ImageIcon getIconEllipse() {
			return IconEllipse;
		}



		public void setIconEllipse(ImageIcon iconEllipse) {
			IconEllipse = iconEllipse;
		}



		public JButton getBtnVecteur() {
			return BtnVecteur;
		}



		public void setBtnVecteur(JButton btnVecteur) {
			BtnVecteur = btnVecteur;
		}
		
		
	}