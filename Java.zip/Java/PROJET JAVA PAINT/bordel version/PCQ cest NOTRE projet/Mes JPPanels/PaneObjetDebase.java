package pro;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelObjetDeBase extends JPanel{

	private JPanel PnlObj = new JPanel();
	private ImageIcon IconRectangle = new ImageIcon(this.getClass().getResource("../MesImages/rectangle.png" ));
	private JButton BtnRectangle = new JButton(IconRectangle);
	private ImageIcon IconCercle = new ImageIcon(this.getClass().getResource("../MesImages/cercle.png"));
	private JButton BtnCercle = new JButton(IconCercle);
	private ImageIcon IconVecteur = new ImageIcon(this.getClass().getResource("../MesImages/vecteur.png"));
	private JButton BtnEllipse = new JButton(IconEllipse);
	private ImageIcon IconEllipse = new ImageIcon(this.getClass().getResource("../MesImages/ellipse.png"));
	private JButton BtnVecteur = new JButton(IconVecteur);
	private ImageIcon IconObjComposite = new ImageIcon(this.getClass().getResource("../MesImages/objcomposite.png"));
	private JButton BtnObjComposite = new JButton(IconObjComposite);
	private ImageIcon IconMultirec = new ImageIcon(this.getClass().getResource("../MesImages/multirec.png"));
	private JButton BtnMultirec= new JButton(IconMultirec);
	private ImageIcon IconMultiell = new ImageIcon(this.getClass().getResource("../MesImages/multiell.png"));
	private JButton BtnMultiell= new JButton(IconMultiell);
	private ImageIcon IconMulticer = new ImageIcon(this.getClass().getResource("../MesImages/multicer.png"));
	private JButton BtnMulticer= new JButton(IconMulticer);

		public PanelObjetDeBase(){
			BtnRectangle.setToolTipText("Cliquez ici pour cr��er un rectangle : ");
			BtnCercle.setToolTipText("Cliquez ici pour cr�er un cercle : ");
			BtnTriangle.setToolTipText("Cliquez ici pour cr�er un triangle : ");
			BtnVecteur.setToolTipText("Cliquez ici pour cr�er un vecteur : ");
			BtnEllipse.setToolTipText("Cliquez ici pour cr�er une ellipse : ");
			BtnObjComposite.setToolTipText("Cliquez ici pour cr�er un Objet Composite: ");
			BtnMulticer.setToolTipText("Cliquez ici pour cr�er un multicercle : ");
			BtnMultirec.setToolTipText("Cliquez ici pour cr�er un multirecangle : ");
			BtnMultiell.setToolTipText("Cliquez ici pour cr�er une multiellipse : ");
			this.add(BtnRectangle);
			this.add(BtnCercle);
			this.add(BtnTriangle);
			this.add(BtnVecteur);
			this.add(BtnEllipse);
			this.add(BtnObjComposite);
			this.add(BtnMulticer);
			this.add(BtnMultirec);
			this.add(BtnMultiell);
			this.setPreferredSize(new Dimension("JSAIPAS","JSAIPAS"));
			this.add(PnlObj,BorderLayout.WEST);
		}

		public JPanel PnlObj() {
			return PnlObj;
		}

		public void setPnlComposant(JPanel PnlObje) {
			PnlObj = PnlObje;
		}

		public ImageIcon getIconRectangle() {
			return IconRectangle;
		}

		public void setIconRectangle(ImageIcon iconRectangle) {
			IconRectangle = iconRectangle;
		}

		public JButton getBtnRectangle() {
			return BtnRectangle;
		}

		public void setBtnRectangle(JButton btnRectangle) {
			BtnRectangle = btnRectangle;
		}

		public ImageIcon getIconTriangle() {
			return IconTriangle;
		}

		public void setIconTriangle(ImageIcon iconTriangle) {
			IconTriangle = iconTriangle;
		}

		public JButton getBtnTriangle() {
			return BtnTriangle;
		}

		public void setBtnTriangle(JButton btnTriangle) {
			BtnTriangle = btnTriangle;
		}

		public ImageIcon getIconCercle() {
			return IconCercle;
		}

		public void setIconCercle(ImageIcon iconCercle) {
			IconCercle = iconCercle;
		}

		public JButton getBtnCercle() {
			return BtnCercle;
		}

		public void setBtnCercle(JButton btnCercle) {
			BtnCercle = btnCercle;
		}

		public ImageIcon getIconVecteur() {
			return IconVecteur;
		}

		public void setIconVecteur(ImageIcon iconVecteur) {
			IconVecteur = iconVecteur;
		}

		public JButton getBtnEllipse() {
			return BtnEllipse;
		}

		public void setBtnEllipse(JButton btnEllipse) {
			BtnEllipse = btnEllipse;
		}

		public ImageIcon getIconEllipse() {
			return IconEllipse;
		}

		public void setIconEllipse(ImageIcon iconEllipse) {
			IconEllipse = iconEllipse;
		}

		public JButton getBtnVecteur() {
			return BtnVecteur;
		}

		public void setBtnVecteur(JButton btnVecteur) {
			BtnVecteur = btnVecteur;
		}

		public ImageIcon getIconObjComposite() {
			return IconObjComposite;
		}

		public void setIconObjComposite(ImageIcon iconObjComposite) {
			IconObjComposite = iconObjComposite;
		}

		public JButton getBtnObjComposite() {
			return BtnObjComposite;
		}

		public void setBtnObjComposite(JButton btnObjComposite) {
			BtnObjComposite = btnObjComposite;
		}

		public ImageIcon getIconMultirec() {
			return IconMultirec;
		}

		public void setIconMultirec(ImageIcon iconMultirec) {
			IconMultirec = iconMultirec;
		}

		public JButton getBtnMultirec() {
			return BtnMultirec;
		}

		public void setBtnMultirec(JButton btnMultirec) {
			BtnMultirec = btnMultirec;
		}

		public ImageIcon getIconMultiell() {
			return IconMultiell;
		}

		public void setIconMultiell(ImageIcon iconMultiell) {
			IconMultiell = iconMultiell;
		}

		public JButton getBtnMultiell() {
			return BtnMultiell;
		}

		public void setBtnMultiell(JButton btnMultiell) {
			BtnMultiell = btnMultiell;
		}

		public ImageIcon getIconMulticer() {
			return IconMulticer;
		}

		public void setIconMulticer(ImageIcon iconMulticer) {
			IconMulticer = iconMulticer;
		}

		public JButton getBtnMulticer() {
			return BtnMulticer;
		}

		public void setBtnMulticer(JButton btnMulticer) {
			BtnMulticer = btnMulticer;
		}
	}
