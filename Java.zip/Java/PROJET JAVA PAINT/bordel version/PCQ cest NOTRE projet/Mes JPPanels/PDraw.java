package Panels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

import PROJET.cercle;
import PROJET.composant;
import PROJET.Rectangle;
import PROJET.Vecteur2D;
import PROJET.Triangle;

public class PanelDraw extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JPanel pnl_draw = new JPanel();
	
		public PanelDraw()
		{
			this.setPreferredSize(new Dimension(0,780));
			this.setBackground(Color.WHITE);
			this.add(pnl_draw,BorderLayout.CENTER);
		}

		public void afficher(ObjetDebase o)
		{
			if (o instanceof Rectangle)
			{
				this.getGraphics().setColor(Color.BLACK);
				this.getGraphics().drawRect(o.getpointref().getX(),o.getpointref().getY(), ((Rectangle)o).getPoint().getX(),((Rectangle)o).getPoint().getY());
			}
			else if (o instanceof Cercle)
			{
				this.getGraphics().setColor(Color.BLACK);
				this.getGraphics().drawOval(o.getpointref().getX(),o.getpointref().getY(),((cerole) o).getRayon(),((oerole) o).getRayon());
			}
			else if (o instanceof Vecteur2D)
			{
				this.getGraphics().setColor(Color.BLACK);
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(),o.getpointref().getX()+((Vecteur2D)o).getPoint().getX(),o.getpointref().getY()+ ((Vecteur2D)o).getPoint().getY());
			}
			else if (o instanceof Quadrilatere)
			{
				this.getGraphics().setcolor(Color.BLACK);
				this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint2().getY(),(((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getX()), (((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getY()));
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint3().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint3().getY()));
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint2().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint2().getY()));
				this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint3().getY(),(((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint3().getX()), (((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint4().getY()));
				//1) du point 2 au point 4
				//2) du point 2 au pointref
				//3) du point 3 au pointref
				//4) du point 3 au point 4
			}
			else if(o instanceof Ellipse){
				this.getGraphics().setColor(Color.BLACK);
				this.getGraphics().drawEllipse2D( ( (o.getpointref().getX() + o.getpointref().getX()) /2),( (o.getpointref().getY() + o.getpointref().getY()) /2),((Ellipse)o).getRayonlong(),((Ellipse)o).getRayoncourt());
													
			}
		}		
		
		
		public void effacer(ObjetDeBase o)
		{
			if (o instanceof Rectangle)
			{
			this.getGraphics().setColor(Color.WHITE);
			this.getGraphics().drawRect(o.getpointref().getX(),o.getpointref().getY(), o.getpointref().getX()+((Rectangle)o).getPoint().getX(),o.getpointref().getY()+((Rectangle)o).getPoint().getY());
			}
			else if(o instanceof Cercle)
			{
			this.getGraphics().setColor(Color.WHITE);
			this.getGraphics().drawOval(o.getpointref().getX(),o.getpointref().getY(), ((cercle) o).getRayon(),((cercle) o).getRayon());
			}
			else if (o instanceof Vecteur2D)
			{
				this.getGraphics().setColor(Color.WHITE);
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(),((Vecteur2D)o).getPoint().getX(), ((Vecteur2D)o).getPoint().getY());
			}
			else if (o instanceof Quadrilatere)
			{
				this.getGraphics().setColor(Color.WHITE);
				this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint2().getY(),(((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getX()), (((Quadrilatere)o).getPoint2().getX()+((Quadrilatere)o).getPoint4().getY()));
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint3().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint3().getY()));
				this.getGraphics().drawLine(o.getpointref().getX(), o.getpointref().getY(), (o.getpointref().getX()+((Quadrilatere)o).getPoint2().getX()), (o.getpointref().getY()+((Quadrilatere)o).getPoint2().getY()));
				this.getGraphics().drawLine(((Quadrilatere)o).getPoint2().getX(), ((Quadrilatere)o).getPoint3().getY(),(((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint3().getX()), (((Quadrilatere)o).getPoint3().getX()+((Quadrilatere)o).getPoint4().getY()));
				//1) du point 2 au point 4
				//2) du point 2 au pointref
				//3) du point 3 au pointref
				//4) du point 3 au point 4
			}
			else if(o instanceof Ellipse){
				this.getGraphics().setColor(Color.WHITE);
				this.getGraphics().drawEllipse2D( ( (o.getpointref().getX() + o.getpointref().getX()) /2),( (o.getpointref().getY() + o.getpointref().getY()) /2),((Ellipse)o).getRayonlong(),((Ellipse)o).getRayoncourt());
													
			}
		}
		
		
	//	___________________________________________________________
	// la fonction de création : 
		public void afficher(){
		pnl_draw.update(pnl_draw.getGraphics());
		for (int i = 0; i < Comp.nbcomp(); i++){
			if(Comp.getComp().get(i) instanceof ObjetComposite){
				for(int j=0; j<((Composite) Comp.getComp().get(i)).nbcomp();j++){
					ObjetDeBase o = ((Composite) Comp.getComp().get(i)).getComp().get(j);
					pnl_draw.afficher(o);
				}
			}
			
			else if(Comp.getComp().get(i) instanceof MultiRectangle){
				for(int k=0; k<((MultiRectangle) Comp.getComp().get(i)).nbcomp();k++){
					ObjetDeBase o = ((MultiRectangle) Comp.getComp().get(i)).getMr().get(k);
					pnl_draw.afficher(o);
				}
			}
			
			else if(Comp.getComp().get(i) instanceof MultiCercle){
				for(int k=0; k<((MultiCercle) Comp.getComp().get(i)).nbcomp();k++){
					ObjetDeBase o = ((MultiCercle) Comp.getComp().get(i)).getC().get(k);
					pnl_draw.afficher(o);
				}
			}
			
			else if(Comp.getComp().get(i) instanceof MultiEllipse){
				for(int k=0; k<((MultiEllipse) Comp.getComp().get(i)).nbcomp();k++){
					ObjetDeBase o = ((MultiEllipse) Comp.getComp().get(i)).getE().get(k);
					pnl_draw.afficher(o);
				}
			}
			
			else{
				ObjetDeBase o = Comp.getComp().get(i);
				pnl_draw.afficher(o);
			}
		}
		}
		// ___________________________________________________________
		// fonction  pour split : 
			public static String[] Nettoyer(String ch){
				String str[]=ch.trim().split(";");
				return str;
			}
			
			
			
			
			public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		//Si on appuie sur le bouton fermer
		if(e.getSource().equals(fermer))
		{
			System.exit(0);
		}
				
		//Si on appuie sur le bouton rectangle, enleve les panels affichés et affiche le bon
		//Ajoute un rectangle au composite C
		//Ajoute "Rectangle" a la liste, recupere le nom dans edt_name et son origine
		else if (e.getSource().equals(pnl_composant.getBtn_rectangle()))
		{	
			Rectangle rect = new Rectangle();
			
			// il faudra créer un ObjetComposite ( => C ) 
			
			C.ajouter(rect);
			C.getListComposite().addElement("Rectangle");
			C.getListComposite()().setSelectedIndex(C.getListComposite()().getLastVisibleIndex());
			pnl_edit.getEdt_name().requestFocus();
			pnl_edit.getEdt_origine().setText(String.valueOf(rect.getOrigine().getX() +";" +rect.getOrigine().getY()));
			pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX()) +";" +String.valueOf(rect.getPoint().getY()));
		}
		
		
	}