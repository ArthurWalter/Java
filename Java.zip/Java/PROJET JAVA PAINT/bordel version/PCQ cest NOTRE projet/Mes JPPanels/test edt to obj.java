
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import UML.ObjetDeBase;
import UML.ObjetComposite;
import UML.Rectangle;
// ouai enfin plutôt la manière faire qu'un vrai test
public class test extends JFrame implements ActionListener,ListSelectionListener,KeyListener,MouseListener{ // OUI ça fait beaucoup


	ObjetComposite Oc= new ObjetComposite();
	private PanelRect pnl_edt_rect = new PanelRect();

	pnl_ObjetDeBase.getBtn_rectangle().addActionListener(this);
	btn_ok.addActionListener(this);
	
	pnl_edit.getEdt_nomobj().addKeyListener(this);
	pnl_edit.getEdt_pointref().addKeyListener(this);
	pnl_edt_comp.getBtn_rectangle().addActionListener(this);
	pnl_edt_rect.getEdt_point_rect().addKeyListener(this);

				//Si on appuie sur le bouton rectangle, enleve les panels affich閟 et affiche le bon
		//Ajoute un rectangle au composite Oc
		//Ajoute "Rectangle" a la liste, recupere le nom dans edt_name et son origine
		if (e.getSource().equals(pnl_ObjetDeBase.getBtn_rectangle()))
		{	
			Rectangle rect = new Rectangle();
			Oc.comp.ajouter(rect);
			Oc.comp.getList_objCompo().addElement("Rectangle");
			//Oc.getListComposite().addElement("Rectangle");    ces deux là sont optionnels pcq c'est pour la liste des objets composites (après)
			//Oc.getList_objCompo().setSelectedIndex(Oc.getList_objCompo().getLastVisibleIndex());
			pnl_edt.getEdt_nomobj().requestFocus();
			pnl_edt.getEdt_pointref().setText(String.valueOf(rect.getOrigine().getX() +"," +rect.getOrigine().getY()));
			pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(rect.getPoint().getX()) +"," +String.valueOf(rect.getPoint().getY()));
		}
		if (C.getC().get(Oc.getList_objcompo().getSelectedIndex()) instanceof Rectangle)
			{	
				else
				{
				String str_pt[];
				String ch_pt=pnl_edt_rect.getEdt_point_rect().getText();
				str_pt=Nettoyer(ch_pt);
				
				
				if ((Integer.parseInt(str_pt[1]) > pnl_draw.getHeight()) ||(Integer.parseInt(str_pt[0]) > pnl_draw.getWidth()))
				else
				{
				pnl_edt_rect.getEdt_point_rect().setText(String.valueOf(Integer.parseInt(str_pt[0]) +"," +Integer.parseInt(str_pt[1])));
				C.getC().set(C.getList_compo().getSelectedIndex(), new Rectangle(new Point2D(Integer.parseInt(str_org[0]),Integer.parseInt(str_org[1])),new Point2D(Integer.parseInt(str_pt[0]),Integer.parseInt(str_pt[1]))));
				
				this.afficher();
				
				// ensuite, après cela il faudra juste appeler la fonction
				// afficher (sans rien d'autre, juste une ligne afficher() ) 
				// pour afficher graphiquement ce que l'on veut
				// et voilà :p
				
	