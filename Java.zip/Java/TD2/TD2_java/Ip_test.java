package IP;
import java.util.Scanner;
import java.util.regex.Pattern;

public class IP_Validation {

	public static void main(String[] args) {
		String Ip = new Scanner(System.in).nextLine();
		if(estValide(Ip))
			System.out.println(Ip + "est valide");
		else
			System.out.println(Ip + "est invalide");	
	}
	static boolean estValide(String ip) {
		
		
		String[] segments = ip.split("\\.");
	
		for (int j=0; j < 4; j++) System.out.println(segments[j]); 
		try{
		if (segments.length == 4)
		{ 
			boolean isIP = true; 
			int i = 0; 
		    while (isIP && i < 4)
		    {   int nbre  = Integer.parseInt(segments[i]);
		        if (nbre <0 || nbre > 255) isIP = false;
		        i++;
		    }
		    return isIP; 
		}
		
		else return false; 
		} catch(NumberFormatException e){
			return false;
		}
	}
}
	
 