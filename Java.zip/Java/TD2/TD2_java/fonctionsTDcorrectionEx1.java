package FonctionVerif;
/**
 * 
 * @author zidna
 *
 */
public class fonctions {
	/**
	 * 
	 * @param str une chaine de carcat�res qui represente 
	 * un adresse IP
	 * @return un booleen qui signifie que la chaine est 
	 * est un nombre entier.
	 */

  	 public static boolean isNumeric(String str)  
	  {  
	    try  
	    {  
	      int d = Integer.parseInt(str);  
	    }  
	    catch(NumberFormatException nfe)  
	    {  
	      return false;  
	    }  
	    return true;  
	  }  
}
// pour convertir un entier en cha�ne : String.valueOf(n) ou n est l'entier;
// pour convertir une chaine en entier : Integer.parseInt(ch);
// pour convertir une chaine en float : Float.parseFloat(ch);
// trim permet de virer les espaces au d�but et � la fin : ch.trim();
// ch.toUpperCase(); permet de mettre la chaine en majuscule // toLowerCase en minuscule;
// charAt() permet de regarder si les caract�res sont les m�mes (retourne le caract�re � l'adresse indiqu�)
// exemple : ch1.chatAt(0)==ch2.charAt(0) compare si le premier caract�re des deux chaines sont les m�mes;
// compareTo et compareToIgnoreCase compare l'�cart entre les caract�res d'une chaine (dans l'ordre de l'alphabet), compareToIgnoreCase ne prend pas en compre les majuscules;
//  pour savoir si ils ont les m�mes caract�res en fin de chaine, on peut faire : ch1.indexOf(ch2) , va renvoyer l'�cart entre les caract�res en fin de chaine. 
// � la limite on aurait aussi pu utiliser charAt ;
		
		/*  int somme;
		for(int i=1;i<=ch1.length;i++)
			somme= somme + ch1.indexOf(ch2);
		if (somme==0)
			System.out.println("ch1 contient ch2");
	*/
																						// ch.replaceAll(" ","");
																						// ch.toUpperCase();
																						
																						//if (ch2.FirstIndexOf(ch1))

		if (ch1.indexOf(ch2)!=-1){
			System.out.println("ch1 contient ch2");
			if (ch1.indexOf(ch2==0)
				System.out.println("ch1 commence par ch2");
			else if (ch1.indexOf(ch2)==(ch1.length()-ch2.length())
				System.out.println("ch1 se termine par ch2");
			System.out.println(ch1.substring(0,ch1.indexOf(ch2));
			System.out.println(ch1.substring(ch1.indexOf(ch2)+ ch2.length(),ch1.length())
		}
		else System.out.println("ch1 n'est pas incluse dans ch2");
		
		







