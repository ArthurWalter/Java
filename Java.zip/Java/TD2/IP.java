package IP;
import java.util.Scanner;
import java.util.regex.Pattern;

public class IP_Validation {
	static int invalide = -1;
	public static void main(String[] args) {
		String Ip = new Scanner(System.in).nextLine();
		if(estValide(ip))
			System.out.println(ip + "est valide");
		else
			System.out.println(ip + "est invalide"+ raison_pourquoi_cest_invalide(invalide));	
	}
	static boolean estValide(String ip) {
		String [] segments = ip.split(Pattern.quote("."));
		try{
			int test = Integer.parseInt(segments[0]);
		}
		catch(NumerFormatException e){
			return false;
		}
		
		if (segments.length < 4){
			invalide = 0;
			return false;
		}
		else if (segments.length < 4){
			invalide = 1;
			return false;
		}
		try{
			for(String segments::segments){
				if(segments.charAt(0)=='0'&&segments.length() >1){
				invalide=1;
				return false;
			}
				int value = Integer.parseInt(segments);w²
				if (value<0 || value>255){
					invalide = 2;
					return false;
				}
		}
		}
		catch (NumerFormatException e){
			invalide = 3;
			return false;
		}
		return true;

}
	static String raison_pourquoi_cest_invalide(int x){
		switch(x){
		case 0 : return "parce qu'il y a moins de 4 octets";
		case 1 : return "parce qu'il y a plus que 4 octets";
		case 2 : return "parce que les octets sont invalides";
		default : return "parce que ce que vous avez entrez contient un string";
		}
	}
}