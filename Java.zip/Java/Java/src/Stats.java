import java.util.*;

public class Stats {
		static int nb;
		static double tab  [];
		public static void main(String[] args) {
			LireNotes();
			System.out.println("La moyenne est :" + moy());
			System.out.println("Le minimum est :" + min());
			System.out.println("Le maximum est :" + max());
			
		}
		 public static void LireNotes(){
			 int i;
			 Scanner sc = new Scanner(System.in);
			 int nb = sc.nextInt();
			 tab = new Tab[nb];
			 for(i=0; i<=nb;i++)
				 Tab[i]=sc.nextDouble();
		 }
		 public static double moy(){
			 int i;
			 double save;
			 for(i=0;i<=nb;i++)
				 save = save + Tab[i];
			 calcul = save/nb;
			 System.out.println(calcul +);
		 }
		 public static int min{
			 int i;
			 double = s
			 for(i=0;i<=nb;i++)
				 if(Tab[i]<=Tab[i+1])
					 s= Tab[i];
			 System.out.println(s +);
		 }
		 public static int max{
			 int i;
			 double = s
			 for(i=0;i<=nb;i++)
				 if(Tab[i]>=Tab[i+1])
					 s= Tab[i];
			 System.out.println(s +);
		 }
		 
		 
					 
			 
			 	
		/*int n1, n2, n3, n4,i, nbnotes;
		double moy;
		static double [] notes;
		Scanner LectureCLavier = new Scanner(System.in);
		System.out.print("Entrer le nombre de notes :");
		
		
		while(nbnotes>=0 && nbnotes<=20)
			nbnotes = LectureCLavier.nextInt();
		for(i=0;i<=nbnotes;i++)
			notes[i] = LectureClavier.nextDouble();*/
		
		
		/*
		System.out.print("Entrez la note 1 :");
		n1 = LectureClavier.nextInt();
		System.out.println(n1 +);
		
		System.out.print("Entrez la note 2 :");
		n2 = LectureClavier.nextInt();
		System.out.println(n2 +);
		
		System.out.print("Entrez la note 3 :");
		n3 = LectureClavier.nextInt();
		System.out.println(n3 +);
		
		System.out.print("Entrez la note 4 :");
		n4 = LectureClavier.nextInt();
		System.out.println(n4 +);
		
		moy = (n1 + n2 + n3 + n4)/4;
		System.out.print(moy +);*/
		
		
		
		
		
		

	}

}
