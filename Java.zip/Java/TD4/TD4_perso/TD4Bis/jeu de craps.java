package lancerDes;
import java.util.*;
public class De { // extends Craps
	
   private final int MAX = 6;  // nombre maximum de faces
 
   private int valFace;  // la valeur courante de la face

   public De(){
      valFace = 1;
   }
 
   public int lancer(){
      valFace = (int)(Math.random() * MAX) + 1;
      return valFace;
   }
 
   public void setvaleurFace (int value) {
      valFace = value;
   }
 
   public int getvaleurFace(){
      return valFace;
   }
   
   public String toString(){
      String result = Integer.toString(valFace);
      return result;
   }
   
   public int Afficher(){
	   return valFace;
   }
}


