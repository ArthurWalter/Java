import java.util.*


public class TestCraps{
	
	public void main(String [] args){
		
		System.out.println("saisissez le nombre de parties que vous voulez jouez : ")
		Scanner sc = new Scanner(System.in);
		int nb_parties = sc.nextLong();
		
		long nb_perdu=0;
		long nb_gagne=0;
		
		for(long i=0; i<=nb;i++)
			Craps C = new Craps();
			C.lancer();
			String resultat = C.jeuCraps();
			 switch (resultat)
				 {
				 case "GAGNE" : nb_gagne++; break;
				 case "PERDU" : nb_perdu++; break;
				 }
			System.out.println("le pourcentage de parties gagnées : "+(nb_gagne*100)/nb_parties);
			System.out.println("le pourcentage de parties perdues ! "+(nb_perdu*100)/nb_parties);
	}
}