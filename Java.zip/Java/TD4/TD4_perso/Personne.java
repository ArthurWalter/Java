package Personne;
import java.util.*;

class Personne{
	private String nom;
	private String prenom;
	private Date nais;
	
		public Personne(String nom, String prenom, Date dnaissance) {
			super();
			this.nom = nom;
			this.prenom = prenom;
			this.nais = nais;
		}
//__________get_____________
		public String getnom(){
			return nom;
		}
		public String getprenom(){
			return prenom;
		}
			public Date getnais(){
			return nais;
		}
//__________set_____________
		public void setnom(String s){
			this.nom = s;
		}
		public void setprenom(String s){
			this.prenom = s;
		}
		
		public void setnais(Date d){
			this.nais = d;
		}
//_________toString_________
		public String toString()
		{
		return System.out.println("nom : "+nom+ "/ prenom: "+prenom+"/ date de naissance : "+nais);
		}
//__________equals__________
		public boolean equals(Personne p){
			Personne test = (Personne) p;
			if(prenom != test.prenom)
				return false;
			if(nom != test.nom)
				return false;
			if(nais != test.nais)
				return false;
			return true;	
		}
}











