package Personne;
import java.util.*

	class testDate{
		public void main(String []args){
			
			Date d1(10,05,2018);
			Date d2(30,01,2018);
			int nb = d1.difference(d2);
			System.out.println("La différence entre d1 et d2 est : "+res);
			
		}
	}