package personne;
import java.util.*;

class Date{
	private int jour;
	private int mois;
	private int annee;
//_________constructeur________	
	public Date(int jour, int mois, int annee) {
		super();
		this.jour = jour;
		this.mois = mois;
		this.annee = annee;
	}
// ____________get_____________
	public int getjour(){
		return jour;
	}
	public int getmois(){
		return mois;
	}
	
	public int getannee(){
		return annee;
	}
//_____________set_____________	
	public void setjour(int jour){
		this.jour=jour;
	}
	
	public void setmois(int mois){
		this.mois=mois;
	}
	
	public void setannee(int annee){
		this.annee=annee;
	}
//___________toString___________
	
	public String toString(){
		return System.out.println("jour : "+jour+ "/ mois: "+mois+"/ annee : "+annee);
	}
//____________equals____________
	public boolean equals(Date d){
		Date test = (Date) d
		if((test.jour<)=31&&(test.jour>0))
		{
				if((test.mois<)=12&&(test.mois>0))
			return true;
		}
		else {
			if(annee != test.annee)
				return false;
			if(jour != test.jour)
				return false;
			if(mois != test.mois)
				return false;
			}
		return true;
	}
//___________calcul nb_jours et difference____________________
	public static int nbJours(int jour, int mois, int annee){
			return (int)((1461 * (annee + 4800 + (mois - 14) / 12)) / 4 +
			(367 * (mois - 2 - 12 * ((mois - 14) / 12))) / 12 -
			(3 * ((annee + 4900 + (mois - 14) / 12) / 100)) / 4 +
			jour - 32075);
			}
	public int difference(Date d){
		int res = (int) nbJours(jour,mois,annee) - nbJours(d.jour,d.mois,d.annee);
		return Math.abs(res);
		
	}	
}