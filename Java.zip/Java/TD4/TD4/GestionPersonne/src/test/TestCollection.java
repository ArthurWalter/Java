package test;

import personne.CollectionPersonne;
import personne.Date;
import personne.Employe;
import personne.Etudiant;
import personne.Personne;

public class TestCollection {
public static void main(String arg[])
{
  Personne p1=new Personne("Albert", "Mehdi", new Date(3,4,1987));	
  Personne p2=new Personne("Francois", "Celine", new Date(3,4,1987));	
  Etudiant e1=new Etudiant("Conrad", "pierre", new Date(30,5,1980),"conrad@gmail.com");
  Employe e2=new Employe("Salazar", "titus", new Date(30,5,1930), 50);

  CollectionPersonne col= new CollectionPersonne();
  col.ajouter(p1);
  col.ajouter(p2);
  col.ajouter(e1);
  col.ajouter(e2);
  col.afficher();
  
}

}
