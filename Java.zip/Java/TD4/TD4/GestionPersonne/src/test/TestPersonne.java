package test;

import personne.Date;
import personne.Personne;

public class TestPersonne {

	public static void main(String[] args) {
    Date d= new Date(12,4,1976);
    Personne p1=new Personne("Sanfrape", "Andre", d );
    Personne p2=new Personne("Tonsac", "David",d);
    d.setAnnee(1970);
    System.out.println(p1);
    System.out.println(p2);
	}

}
