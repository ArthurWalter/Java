package personne;

public class Etudiant extends Personne{
	
	private String email; 
	private nom;
	private prenom;
	private dnaissance;
	private email;

	public Etudiant(String nom, String prenom, Date dnaissance, String email) {
		super(nom, prenom, dnaissance);
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Etudiant ["+super.toString()+ "email=" + email+"]"; 
				
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof Etudiant))
			return false;
		Etudiant other = (Etudiant) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		return true;
	}

	

}
