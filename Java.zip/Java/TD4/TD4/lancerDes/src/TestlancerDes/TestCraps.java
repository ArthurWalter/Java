package TestlancerDes;


import java.util.Scanner;

import lancerDes.Craps;
import lancerDes.Score;

public class TestCraps {


public static void main (String[] args)
{
Scanner sc = new Scanner(System.in);
System.out.println("Entrer le nombre de parties a jouer");
long nb=sc.nextLong();
long nbPerdu=0;
long nbGagne=0; 
for(long i = 0; i< nb; i++)
{
 Craps cp = new Craps();
 cp.lancer();
 Score resultat=cp.jeuCraps();
 switch (resultat)
 {
 case GAGNE : nbGagne++; break;
 case PERDU : nbPerdu++; break;
 }
 
}

System.out.println("le pourcentage de parties gagn�es : "+(nbGagne*100)/nb);
System.out.println("le pourcentage de parties perdues ! "+(nbPerdu*100)/nb);
 


}
}



