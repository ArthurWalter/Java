package lancerDes;

public class De {
	
   private final int MAX = 6;  // nombre maximum de faces
 
   private int valFace;  // la valeur courante de la face
 
   //-----------------------------------------------------------------
   //  Constructeur:  valeur face a 1.
   //-----------------------------------------------------------------
   public De()
   {
      valFace = 1;
   }
 
   //-----------------------------------------------------------------
   //  return la valeur face de mani�re al�atoire.
   //-----------------------------------------------------------------
   public int lancer()
   {
      valFace = (int)(Math.random() * MAX) + 1;
 
      return valFace;
   }
 
   //-----------------------------------------------------------------
   //  modifie la face.
   //-----------------------------------------------------------------
   public void setvaleurFace (int value)
   {
      valFace = value;
   }
 
   //-----------------------------------------------------------------
   //  retourne la valeur de Face.
   //-----------------------------------------------------------------
   public int getvaleurFace()
   {
      return valFace;
   }
 
   //-----------------------------------------------------------------
   //  Retourne une chaine.
   //-----------------------------------------------------------------
   public String toString()
   {
      String result = Integer.toString(valFace);
 
      return result;
   }
}


