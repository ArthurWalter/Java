package craps;
import java.util.*;

	class Craps{
	private De d1;
	private De d2;
	
	public Craps(){
	//	d1.valFace = (int) (Math.Random()* d1.MAX)+1;
	//	d2.valFace = (int) (Math.Random()* d2.MAX)+1;
	d1 = new De();
	d2 = new De();
	
	}
	
	public De getD1(){
		return d1;
	}
	
	public De getD2(){
		return d2;
	}
	public void setValFaceD1(De n){
		d1.valFace=n;
	}
	
	public void setValFaceD2(De n){
		d2.valFace=n;
	}
	
	public void lancer(De d1, De d2){
		D1.lancer();
		D2.lancer();
	}
	
	public int Somme(){
		return d1.getValFace()+d2.getValFace();
	}
	
	public String jeuCraps(){
		String score;
		int s1=this.somme();
		int s0 = 0;
		if ((s1=7)||(s1=11))
			score="GAGNE";
		else if ((s1=2)||(s1=3)||(s1=12))
			score="PERDU";
		else{
			do{
				this.lancer();
				s0=this.somme();
			}while((s1!=7)&&(s1!=s0))
			if(s0=7) 
				score="GAGNE";
			else
				score="PERDU";
		}
	return score;
	}
	
	public String afficher(){
		return "lancer de D1 : "+ d1.toString() + "lancer de d2" + d2.toString();
	}
	
	
	
	
	
	
	
}