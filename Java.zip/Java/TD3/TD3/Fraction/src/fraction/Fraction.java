package fraction;

public class Fraction {
	private int num;
	private int den;
	
	

	public Fraction() {
	 this.num=0;
	 this.den=1;
	}

	public Fraction(int n) {
		this.num = n;
		this.den=1;
	}
	
	public Fraction(int n, int d) {
		this.num = n;
		this.den = d;
		if (this.den<0)
		 {
		  this.num=-this.num;
		  this.den=-this.den;
		 }
	}

	public Fraction(Fraction r)
	{
	 num=r.num;
	 den=r.den;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getDen() {
		return den;
	}

	public void setDen(int den) {
		this.den = den;
	}

	public Fraction somme(Fraction r)
	{
		Fraction res=new Fraction();
		res.num= num*r.den+den*r.num;
		res.den=den*r.den;
		return res;
		
	}
	
	public Fraction difference(Fraction r)
	{
	
		return new Fraction(num*r.den-den*r.num, den*r.den);
		 
	}
	
	public Fraction produit(Fraction r)
	{
	
		return new Fraction(num*r.num, den*r.den);
		 
	}
	
	
	public Fraction inverse()
	{
	  try {
	  return new Fraction(den, num);
	  }
	  catch (ArithmeticException e) 
	  
	  {  
          System.out.println("Denominateur nul!");	
		  return new Fraction(); 	
	  }
	}
	

	public Fraction division(Fraction r)
	{
	
		return this.produit(r.inverse());
		 
	}


	public static int pgcd(int a , int b)
	{ // a=Math.abs(a); b= Math.abs(b);
	   if (a==b) return a ;
	   else if (a>b) return pgcd(a-b, b);
	   else return pgcd(a, b-a);
	   
	}

	public Fraction simplifier()
	{
		int p=pgcd(this.num, this.den);
	    return new Fraction(this.num/p, this.den/p);
	}
	public void afficher()
	{
		System.out.println("Fraction : "+this.num+ "/" +this.den);
	}
		
}
	
	
	
	
	
	
	


